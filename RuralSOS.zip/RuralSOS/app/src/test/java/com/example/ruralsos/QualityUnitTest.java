package com.example.ruralsos;

import com.example.ruralsos.quality.QualityUtils;
import org.junit.Test;
import static org.junit.Assert.*;

public class QualityUnitTest {
    @Test public void test_dni_valid() { assertTrue(QualityUtils.dniValido("12345678")); }
    @Test public void test_dni_invalido() { assertFalse(QualityUtils.dniValido("1234")); }
    @Test public void test_correo_valido() { assertTrue(QualityUtils.correoValido("usuario@ruralsos.pe")); }
    @Test public void test_correo_invalido() { assertFalse(QualityUtils.correoValido("usuario@")); }
    @Test public void test_password_minimo() { assertTrue(QualityUtils.passwordValido("123456")); }
    @Test public void test_password_corto() { assertFalse(QualityUtils.passwordValido("123")); }
    @Test public void test_passwords_coinciden() { assertTrue(QualityUtils.passwordsCoinciden("clave123", "clave123")); }
    @Test public void test_passwords_no_coinciden() { assertFalse(QualityUtils.passwordsCoinciden("clave123", "otra123")); }
    @Test public void test_telefono_valido() { assertTrue(QualityUtils.telefonoValido("961072565")); }
    @Test public void test_coordenadas_validas() { assertTrue(QualityUtils.coordenadasValidas(-7.16, -78.51)); }
    @Test public void test_coordenadas_invalidas() { assertFalse(QualityUtils.coordenadasValidas(-100, 200)); }
    @Test public void test_estado_sos_valido() { assertTrue(QualityUtils.estadoSosValido("ENVIADA")); }
    @Test public void test_estado_sos_invalido() { assertFalse(QualityUtils.estadoSosValido("DESCONOCIDO")); }
    @Test public void test_hash_no_guarda_clave_plana() { assertNotEquals("clave123", QualityUtils.hashPassword("clave123")); }
    @Test public void test_hash_es_determinista() { assertEquals(QualityUtils.hashPassword("clave123"), QualityUtils.hashPassword("clave123")); }
}
