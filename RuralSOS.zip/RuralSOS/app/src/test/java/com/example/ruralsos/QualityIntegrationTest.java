package com.example.ruralsos;

import com.example.ruralsos.quality.QualityUtils;
import org.junit.Test;
import static org.junit.Assert.*;

/** Flujos de integración lógicos: combina varias reglas de módulos de RuralSOS. */
public class QualityIntegrationTest {
    @Test public void test_registro_completo_valido() {
        String dni="12345678", correo="Carlos@Correo.com", tel="961072565", p="clave123";
        assertTrue(QualityUtils.dniValido(dni));
        assertTrue(QualityUtils.correoValido(correo));
        assertTrue(QualityUtils.telefonoValido(tel));
        assertTrue(QualityUtils.passwordValido(p));
        assertEquals("carlos@correo.com", QualityUtils.normalizarCorreo(correo));
        assertEquals(64, QualityUtils.hashPassword(p).length());
    }

    @Test public void test_registro_rechaza_datos_invalidos() {
        assertFalse(QualityUtils.dniValido("12A"));
        assertFalse(QualityUtils.correoValido("correo-malo"));
        assertFalse(QualityUtils.passwordValido("123"));
    }

    @Test public void test_flujo_ubicacion_sos() {
        double lat=-7.1617, lon=-78.5128;
        assertTrue(QualityUtils.coordenadasValidas(lat, lon));
        String maps=QualityUtils.enlaceMaps(lat, lon);
        assertTrue(maps.startsWith("https://maps.google.com/?q="));
        assertTrue(maps.contains(String.valueOf(lat)));
        assertTrue(maps.contains(String.valueOf(lon)));
        assertTrue(QualityUtils.estadoSosValido("ENVIADA"));
    }

    @Test public void test_flujo_seguridad_password() {
        String password="RuralSOS2026";
        assertTrue(QualityUtils.passwordValido(password));
        String hash=QualityUtils.hashPassword(password);
        assertNotEquals(password, hash);
        assertEquals(hash, QualityUtils.hashPassword(password));
        assertNotEquals(hash, QualityUtils.hashPassword("RuralSOS2027"));
    }
}
