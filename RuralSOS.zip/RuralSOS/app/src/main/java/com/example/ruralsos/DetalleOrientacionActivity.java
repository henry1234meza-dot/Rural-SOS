package com.example.ruralsos;

import android.annotation.SuppressLint;
import android.os.*;
import android.widget.*;
import android.speech.tts.TextToSpeech;
import java.util.Locale;

public class DetalleOrientacionActivity extends ActividadBase {
    String t, x; TextToSpeech tts;

    @SuppressLint("MissingInflatedId")
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.pantalla_detalle_orientacion);
        t = getIntent().getStringExtra("title");
        x = getIntent().getStringExtra("body");
        String icon = getIntent().getStringExtra("icon");
        ((TextView) findViewById(R.id.txtTitle)).setText(tr(t));
        ((TextView) findViewById(R.id.txtBody)).setText(tr(x));
        ((TextView) findViewById(R.id.txtIcon)).setText(icon == null ? "🩺" : icon);
        findViewById(R.id.btnBack).setOnClickListener(v -> finish());
        findViewById(R.id.btnShareGuide).setOnClickListener(v -> share("RuralSOS - " + tr(t) + "\n\n" + tr(x)));
        tts=new TextToSpeech(this,status->{
            if(status==TextToSpeech.SUCCESS){
                String lang=getSharedPreferences("data",0).getString("language","Quechua Cajamarca");
                Locale locale=lang.equals("English") ? Locale.US : (lang.contains("Quechua") ? new Locale("qu","PE") : new Locale("es","PE"));
                tts.setLanguage(locale);
            }
        });
        findViewById(R.id.btnListenGuide).setOnClickListener(v -> {
            // El audio usa una versión limpia: no pronuncia emojis, marcas, viñetas ni numeración.
            String spoken = cleanForSpeech(tr(t)) + ". " + cleanForSpeech(tr(x));
            tts.speak(spoken, TextToSpeech.QUEUE_FLUSH, null, "guia");
        });
    }
    private String cleanForSpeech(String text) {
        if (text == null) return "";
        return text
                .replace("✅", "")
                .replace("❌", "")
                .replace("☑️", "")
                .replace("✔️", "")
                .replace("✖️", "")
                .replace("🩺", "")
                .replaceAll("(?m)^\\s*\\d+\\.\\s*", "")
                .replaceAll("(?m)^\\s*[•·▪◦-]\\s*", "")
                .replace(":", ".")
                .replaceAll("\\s*\\n+\\s*", ". ")
                .replaceAll("\\.{2,}", ".")
                .replaceAll("\\s+", " ")
                .trim();
    }

    @Override protected void onDestroy(){ if(tts!=null){tts.stop();tts.shutdown();} super.onDestroy(); }
}
