package com.example.ruralsos.model;

public class Usuario {
    public int id;
    public String nombres, apellidos, dni, telefono, correo, passwordHash, fechaRegistro;
    public boolean biometriaActivada;
}
