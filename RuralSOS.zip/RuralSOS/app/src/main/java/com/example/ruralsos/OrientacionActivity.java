package com.example.ruralsos;

import android.os.*;
import android.content.*;

public class OrientacionActivity extends ActividadBase {
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.pantalla_orientacion);
        findViewById(R.id.btnBack).setOnClickListener(v -> finish());
        open(R.id.g1, "🩺", "Primeros auxilios", "✅ QUÉ HACER:\n1. Verifica que el lugar sea seguro.\n2. Revisa si responde y respira.\n3. Llama a emergencias.\n4. Mantén a la persona tranquila y abrigada.\n\n❌ QUÉ NO HACER:\n• No muevas a una persona con golpe fuerte.\n• No des agua si está inconsciente.");
        open(R.id.g2, "❤️", "RCP / Reanimación", "✅ PASOS:\n1. Verifica si responde.\n2. Llama a emergencias.\n3. Coloca las manos en el centro del pecho.\n4. Realiza 30 compresiones fuertes y rápidas.\n5. Da 2 respiraciones si estás capacitado.\n\n❌ NO HACER:\n• No interrumpas las compresiones por mucho tiempo.");
        open(R.id.g3, "🩸", "Hemorragias", "✅ QUÉ HACER:\n1. Presiona la herida con tela limpia.\n2. Mantén presión constante.\n3. Eleva la zona si no hay fractura.\n4. Busca ayuda urgente si el sangrado no para.\n\n❌ NO HACER:\n• No retires objetos incrustados.\n• No uses tierra, café ni remedios caseros.");
        open(R.id.g4, "🦴", "Fracturas", "✅ QUÉ HACER:\n1. Inmoviliza la zona.\n2. Aplica frío envuelto en tela.\n3. Evita movimientos bruscos.\n4. Acude al centro de salud.\n\n❌ NO HACER:\n• No intentes acomodar el hueso.\n• No masajees la zona lesionada.");
        open(R.id.g5, "🔥", "Quemaduras", "✅ QUÉ HACER:\n1. Enfría con agua corriente 10 a 20 minutos.\n2. Retira anillos o ropa ajustada alrededor.\n3. Cubre con gasa limpia.\n\n❌ NO HACER:\n• No uses pasta dental, aceite o mantequilla.\n• No revientes ampollas.");
        open(R.id.g6, "☠️", "Intoxicación", "✅ QUÉ HACER:\n1. Aleja a la persona de la sustancia.\n2. Ventila el ambiente.\n3. Guarda el envase para mostrar al médico.\n4. Llama a emergencias.\n\n❌ NO HACER:\n• No provoques vómito sin indicación médica.");
        open(R.id.g7, "😮‍💨", "Atragantamiento", "✅ QUÉ HACER:\n1. Si tose, deja que siga tosiendo.\n2. Si no respira, realiza maniobra de Heimlich.\n3. Llama a emergencias.\n\n❌ NO HACER:\n• No metas los dedos a ciegas en la boca.");
        open(R.id.g8, "⚡", "Convulsiones", "✅ QUÉ HACER:\n1. Retira objetos cercanos.\n2. Coloca algo suave bajo la cabeza.\n3. Ponlo de lado cuando termine.\n4. Controla el tiempo.\n\n❌ NO HACER:\n• No sujetes a la persona.\n• No pongas objetos en su boca.");
        open(R.id.g9, "🐍", "Picaduras y mordeduras", "✅ QUÉ HACER:\n1. Lava la zona con agua y jabón si es posible.\n2. Mantén a la persona en reposo.\n3. Retira anillos o ropa ajustada.\n4. Acude al centro de salud si hay dolor, hinchazón, fiebre o dificultad para respirar.\n\n❌ NO HACER:\n• No cortes la herida.\n• No succiones veneno.\n• No apliques torniquetes fuertes.\n• No ignores señales de alergia.");
        open(R.id.g10, "🚗", "Accidente de tránsito", "✅ QUÉ HACER:\n1. Asegura la zona.\n2. Llama a emergencias.\n3. No retires casco si sospechas lesión cervical.\n4. Controla sangrados visibles.\n\n❌ NO HACER:\n• No muevas heridos graves salvo peligro inmediato.");
    }

    void open(int id, String icon, String t, String body) {
        findViewById(id).setOnClickListener(v -> {
            Intent i = new Intent(this, DetalleOrientacionActivity.class);
            i.putExtra("icon", icon);
            i.putExtra("title", t);
            i.putExtra("body", body);
            startActivity(i);
        });
    }
}
