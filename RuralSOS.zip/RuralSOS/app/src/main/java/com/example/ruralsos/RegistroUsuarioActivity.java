package com.example.ruralsos;

import android.os.*;
import android.view.WindowManager;
import android.widget.*;
import android.text.method.PasswordTransformationMethod;
import android.text.method.HideReturnsTransformationMethod;
import android.Manifest;
import android.content.pm.PackageManager;
import android.app.AlertDialog;
import android.widget.NumberPicker;
import android.view.Gravity;
import java.util.ArrayList;
import java.util.Calendar;
import android.content.SharedPreferences;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import org.json.JSONObject;

public class RegistroUsuarioActivity extends ActividadBase {
    DatabaseHelper db;
    boolean passVisible = false;
    boolean pass2Visible = false;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.pantalla_registro_usuario);
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
        activarCamposSobreTeclado();
        db = new DatabaseHelper(this);

        Button langButton = findViewById(R.id.btnLanguageRegister);
        actualizarBotonIdioma(langButton);
        langButton.setOnClickListener(v -> mostrarIdiomasRegistro(langButton));
        // Registro 100% offline: DNI, nombres y apellidos se ingresan manualmente.

        EditText birthPicker = findViewById(R.id.edtBirth);
        birthPicker.setFocusable(false);
        birthPicker.setClickable(true);
        birthPicker.setOnClickListener(v -> mostrarSelectorFechaRueda(birthPicker));

        RadioButton allergyYes = findViewById(R.id.rbAllergyYes);
        RadioButton allergyNo = findViewById(R.id.rbAllergyNo);
        EditText allergyDetail = findViewById(R.id.edtAllergy);
        findViewById(R.id.rgAllergy).setOnClickListener(v -> {});
        allergyYes.setOnCheckedChangeListener((button, checked) -> {
            allergyDetail.setEnabled(checked);
            if (!checked) allergyDetail.setText("");
        });


        TextView togglePass = findViewById(R.id.txtToggleRegPass);
        TextView togglePass2 = findViewById(R.id.txtToggleRegPass2);
        EditText regPass = findViewById(R.id.edtPass);
        EditText regPass2 = findViewById(R.id.edtPass2);
        togglePass.setOnClickListener(v -> {
            passVisible = !passVisible;
            regPass.setTransformationMethod(passVisible ? HideReturnsTransformationMethod.getInstance() : PasswordTransformationMethod.getInstance());
            togglePass.setText(passVisible ? "🙈" : "👁");
            regPass.setSelection(regPass.getText().length());
        });
        togglePass2.setOnClickListener(v -> {
            pass2Visible = !pass2Visible;
            regPass2.setTransformationMethod(pass2Visible ? HideReturnsTransformationMethod.getInstance() : PasswordTransformationMethod.getInstance());
            togglePass2.setText(pass2Visible ? "🙈" : "👁");
            regPass2.setSelection(regPass2.getText().length());
        });

        findViewById(R.id.btnVerMasConsentimiento).setOnClickListener(v -> {
            android.content.Intent i = new android.content.Intent(this, ConsentimientoActivity.class);
            i.putExtra("preview_only", true);
            startActivity(i);
        });

        findViewById(R.id.btnRegister).setOnClickListener(v -> {
            EditText n = findViewById(R.id.edtName);
            EditText apPat = findViewById(R.id.edtLastNameFather);
            EditText apMat = findViewById(R.id.edtLastNameMother);
            EditText dni = findViewById(R.id.edtDni);
            EditText birth = findViewById(R.id.edtBirth);
            EditText em = findViewById(R.id.edtEmail);
            EditText ph = findViewById(R.id.edtPhone);
            EditText addr = findViewById(R.id.edtAddress);
            EditText blood = findViewById(R.id.edtBlood);
            EditText allergy = findViewById(R.id.edtAllergy);
            EditText emergency = findViewById(R.id.edtEmergencyContact);
            EditText medicines = findViewById(R.id.edtMedicines);
            EditText conditions = findViewById(R.id.edtConditions);
            EditText p = findViewById(R.id.edtPass);
            EditText p2 = findViewById(R.id.edtPass2);

            String nombres = val(n), apellidoPaterno = val(apPat), apellidoMaterno = val(apMat);
            String name = (nombres + " " + apellidoPaterno + " " + apellidoMaterno).trim().replaceAll("\\s+", " ");
            String document = val(dni), birthDate = val(birth), email = val(em), phone = val(ph);
            String address = val(addr), bloodType = val(blood), allergies = val(allergy), emergencyPhone = val(emergency);
            boolean hasAllergy = ((RadioButton)findViewById(R.id.rbAllergyYes)).isChecked();
            String allergyStored = hasAllergy ? allergies : "NO";
            String medicinesText = val(medicines).isEmpty() ? "Ninguno" : val(medicines);
            String conditionsText = val(conditions).isEmpty() ? "Ninguno" : val(conditions);
            String pass = val(p), pass2 = val(p2);

            if (nombres.isEmpty()) { n.setError(tr("Obligatorio")); toast("Ingresa tus nombres"); return; }
            if (apellidoPaterno.isEmpty()) { apPat.setError(tr("Obligatorio")); toast("Ingresa apellido paterno"); return; }
            if (apellidoMaterno.isEmpty()) { apMat.setError(tr("Obligatorio")); toast("Ingresa apellido materno"); return; }
            if (document.length() != 8) {
                dni.setError(tr("DNI de 8 dígitos"));
                toast("DNI incorrecto");
                return;
            }
            if (birthDate.isEmpty()) {
                birth.setError(tr("Obligatorio"));
                toast("Ingresa fecha de nacimiento");
                return;
            }
            if (!email.contains("@") || !email.contains(".")) {
                em.setError(tr("Correo incorrecto"));
                toast("Correo incorrecto");
                return;
            }
            if (phone.length() < 9) {
                ph.setError(tr("Celular inválido"));
                toast("Ingresa un celular válido");
                return;
            }
            if (address.isEmpty()) {
                addr.setError(tr("Obligatorio"));
                toast("Ingresa dirección o comunidad");
                return;
            }
            if (bloodType.isEmpty()) {
                blood.setError(tr("Obligatorio"));
                toast("Ingresa grupo sanguíneo");
                return;
            }
            if (hasAllergy && allergies.isEmpty()) {
                allergy.setError(tr("Indica la alergia"));
                toast("Escribe a qué es alérgico");
                return;
            }
            if (emergencyPhone.length() < 9) {
                emergency.setError(tr("Contacto inválido"));
                toast("Ingresa contacto SOS principal");
                return;
            }
            if (pass.length() < 6) {
                p.setError(tr("Mínimo 6 caracteres"));
                toast("La contraseña debe tener mínimo 6 caracteres");
                return;
            }
            if (!pass.equals(pass2)) {
                p2.setError(tr("No coincide"));
                toast("Las contraseñas no coinciden");
                return;
            }
            CheckBox consent = findViewById(R.id.cbConsentRegister);
            if (!consent.isChecked()) {
                toast("Debes dar tu consentimiento para crear la cuenta");
                consent.requestFocus();
                return;
            }

            boolean guardado = db.registrarUsuario(name, document, birthDate, email, phone, address, bloodType, allergyStored, emergencyPhone, pass);
            if (guardado) db.actualizarDatosMedicos(email, allergyStored, medicinesText, conditionsText);
            if (!guardado) {
                em.setError(tr("Correo ya registrado"));
                toast("Ese correo ya existe en SQLite local");
                return;
            }

            getSharedPreferences("data", 0).edit()
                    .putString("name", name)
                    .putString("user", name)
                    .putString("dni", document)
                    .putString("birth", birthDate)
                    .putString("email", email)
                    .putString("phone", phone)
                    .putString("address", address)
                    .putString("blood", bloodType)
                    .putString("allergy", allergyStored)
                    .putString("medicines", medicinesText)
                    .putString("conditions", conditionsText)
                    .putString("emergencyContact", emergencyPhone)
                    .putString("pass", pass)
                    .putBoolean("finger", true)
                    .putString("registered_email", email)
                    .putBoolean("consent_" + email.toLowerCase(), true)
                    .putLong("consent_time_" + email.toLowerCase(), System.currentTimeMillis())
                    .apply();

            toast("Cuenta creada. Ahora autoriza los permisos necesarios");
            solicitarPermisosRegistro();
        });

        findViewById(R.id.btnGoLogin).setOnClickListener(v -> go(InicioSesionActivity.class));
    }

    private void actualizarBotonIdioma(Button b) {
        b.setText("🌐  " + getSharedPreferences("data",0).getString("language","Quechua Cajamarca"));
    }

    private void mostrarIdiomasRegistro(Button b) {
        String[] langs={"Quechua Cajamarca","Español","English"};
        String now=getSharedPreferences("data",0).getString("language","Quechua Cajamarca");
        int checked=now.equals("Español")?1:(now.equals("English")?2:0);
        new AlertDialog.Builder(this).setTitle(tr("Seleccionar idioma")).setSingleChoiceItems(langs,checked,(d,w)->{
            getSharedPreferences("data",0).edit().putString("language",langs[w]).apply(); d.dismiss(); recreate();
        }).show();
    }

    private void consultarDniSeguro() {
        EditText dni=findViewById(R.id.edtDni); TextView status=findViewById(R.id.txtDniStatus);
        EditText name=findViewById(R.id.edtName), apPat=findViewById(R.id.edtLastNameFather), apMat=findViewById(R.id.edtLastNameMother);
        String numero=val(dni);
        if(numero.length()!=8){dni.setError(tr("DNI de 8 dígitos")); return;}
        if(!online()){status.setText(tr("Sin Internet. Ingresa nombres y apellidos manualmente.")); name.requestFocus(); return;}
        String endpoint=getSharedPreferences("data",0).getString("dni_endpoint","");
        if(endpoint.trim().isEmpty()){status.setText(tr("Consulta DNI lista para conectar al servidor. Mientras tanto, ingresa nombres manualmente.")); name.requestFocus(); return;}
        status.setText(tr("Consultando DNI..."));
        new Thread(() -> {
            try {
                String sep=endpoint.contains("?")?"&":"?"; URL u=new URL(endpoint+sep+"tipo=dni&numero="+URLEncoder.encode(numero,"UTF-8"));
                HttpURLConnection c=(HttpURLConnection)u.openConnection(); c.setConnectTimeout(7000); c.setReadTimeout(7000); c.setRequestMethod("GET");
                BufferedReader r=new BufferedReader(new InputStreamReader(c.getResponseCode()>=200&&c.getResponseCode()<300?c.getInputStream():c.getErrorStream()));
                StringBuilder sb=new StringBuilder(); String line; while((line=r.readLine())!=null)sb.append(line); r.close();
                JSONObject o=new JSONObject(sb.toString());
                if(o.optBoolean("success",false)){ JSONObject data=o.optJSONObject("data"); if(data==null)data=o;
                    final String nombres=data.optString("nombres", "").trim();
                    final String paterno=data.optString("apellidoPaterno",data.optString("apellido_paterno", "")).trim();
                    final String materno=data.optString("apellidoMaterno",data.optString("apellido_materno", "")).trim();
                    runOnUiThread(()->{
                        name.setText(nombres); apPat.setText(paterno); apMat.setText(materno);
                        if(!nombres.isEmpty()) { name.setEnabled(false); apPat.setEnabled(false); apMat.setEnabled(false); }
                        status.setText(tr("DNI encontrado. Nombres y apellidos completados automáticamente."));
                    });
                } else { final String msg=o.optString("message","DNI no encontrado"); runOnUiThread(()->status.setText(tr(msg)+". "+tr("Puedes continuar manualmente."))); }
            } catch(Exception ex){runOnUiThread(()->status.setText(tr("No se pudo consultar el DNI. Puedes continuar manualmente.")));}
        }).start();
    }

    private void mostrarSelectorFechaRueda(EditText destino) {
        Calendar hoy = Calendar.getInstance();
        Calendar inicial = Calendar.getInstance();
        inicial.add(Calendar.YEAR, -18);

        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.HORIZONTAL);
        box.setGravity(Gravity.CENTER);
        box.setPadding(18, 24, 18, 8);

        NumberPicker dia = new NumberPicker(this);
        NumberPicker mes = new NumberPicker(this);
        NumberPicker anio = new NumberPicker(this);
        dia.setMinValue(1); dia.setMaxValue(31); dia.setValue(inicial.get(Calendar.DAY_OF_MONTH));
        mes.setMinValue(1); mes.setMaxValue(12);
        mes.setDisplayedValues(new String[]{"Ene","Feb","Mar","Abr","May","Jun","Jul","Ago","Sep","Oct","Nov","Dic"});
        mes.setValue(inicial.get(Calendar.MONTH)+1);
        anio.setMinValue(1900); anio.setMaxValue(hoy.get(Calendar.YEAR)); anio.setValue(inicial.get(Calendar.YEAR));

        box.addView(dia, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1));
        box.addView(mes, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1));
        box.addView(anio, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1));

        new AlertDialog.Builder(this)
                .setTitle(tr("Fecha de nacimiento"))
                .setView(box)
                .setNegativeButton(tr("Cancelar"), null)
                .setPositiveButton(tr("Aceptar"), (d, w) -> {
                    Calendar elegida = Calendar.getInstance();
                    int maxDia;
                    Calendar tmp = Calendar.getInstance();
                    tmp.set(anio.getValue(), mes.getValue()-1, 1);
                    maxDia = tmp.getActualMaximum(Calendar.DAY_OF_MONTH);
                    int dd = Math.min(dia.getValue(), maxDia);
                    elegida.set(anio.getValue(), mes.getValue()-1, dd);
                    if (elegida.after(hoy)) { toast("La fecha no puede ser futura"); return; }
                    destino.setText(String.format(java.util.Locale.getDefault(), "%02d/%02d/%04d", dd, mes.getValue(), anio.getValue()));
                }).show();
    }

    private void solicitarPermisosRegistro() {
        if (Build.VERSION.SDK_INT < 23) { irLogin(); return; }
        ArrayList<String> permisos = new ArrayList<>();
        String[] base = {Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.READ_CONTACTS,
                Manifest.permission.SEND_SMS, Manifest.permission.RECEIVE_SMS, Manifest.permission.CAMERA};
        for (String p : base) if (checkSelfPermission(p) != PackageManager.PERMISSION_GRANTED) permisos.add(p);
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            permisos.add(Manifest.permission.POST_NOTIFICATIONS);
        if (permisos.isEmpty()) irLogin();
        else requestPermissions(permisos.toArray(new String[0]), 7001);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == 7001) irLogin();
    }

    private void irLogin() {
        toast("Registro completado. Ahora inicia sesión");
        go(InicioSesionActivity.class);
        finish();
    }

    private String val(EditText editText) {
        return editText.getText().toString().trim();
    }
}
