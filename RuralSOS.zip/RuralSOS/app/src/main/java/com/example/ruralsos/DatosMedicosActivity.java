package com.example.ruralsos;

import android.app.AlertDialog;
import android.os.Bundle;
import android.view.View;
import android.widget.*;

public class DatosMedicosActivity extends ActividadBase {
    DatabaseHelper db;
    String email;
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.pantalla_datos_medicos);
        db = new DatabaseHelper(this);
        email = getSharedPreferences("data",0).getString("email","");
        findViewById(R.id.btnBack).setOnClickListener(v -> finish());
        findViewById(R.id.btnEditMedical).setOnClickListener(v -> editar());
        findViewById(R.id.btnQrMedical).setOnClickListener(v -> go(MedicalQrActivity.class));
        cargar();
    }
    private void cargar() {
        String[] d = db.obtenerDatosMedicos(email);
        if (d == null) { ((TextView)findViewById(R.id.txtMedicalData)).setText(tr("No hay datos médicos registrados.")); return; }
        String alergia = d[3];
        String alergiaTxt = sinAlergia(alergia) ? "❌ NO" : "⚠️ SÍ - " + alergia;
        String texto = "👤  " + d[0] + "\n\n🪪  DNI: " + d[1] + "\n\n🩸  " + tr("Sangre:") + " " + d[2] +
                "\n\n⚠️  " + tr("Alergia:") + " " + tr(alergiaTxt) + "\n\n💊  " + tr("Medicamentos:") + " " + tr(d[4]) +
                "\n\n🩺  " + tr("Antecedentes:") + " " + tr(d[5]) + "\n\n📞  " + tr("Contacto SOS:") + " " + d[6] +
                "\n\n🫀  " + tr("Donante de órganos:") + " " + tr(d.length > 7 ? d[7] : "No especificado");
        ((TextView)findViewById(R.id.txtMedicalData)).setText(texto);
    }
    private boolean sinAlergia(String a) { return a==null || a.trim().isEmpty() || a.equalsIgnoreCase("NO") || a.equalsIgnoreCase("Ninguna"); }
    private void editar() {
        String[] d = db.obtenerDatosMedicos(email); if (d==null) return;
        LinearLayout box = new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setPadding(dp(22),dp(8),dp(22),dp(8));
        CheckBox tiene = new CheckBox(this); tiene.setText(tr("⚠️ Tiene alergia clínica")); tiene.setChecked(!sinAlergia(d[3])); box.addView(tiene);
        EditText alergia = campo(tr("¿A qué es alérgico?"), sinAlergia(d[3])?"":d[3]); alergia.setEnabled(tiene.isChecked()); box.addView(alergia);
        EditText meds = campo(tr("Medicamentos"), d[4]); box.addView(meds);
        EditText ant = campo(tr("Enfermedades / antecedentes"), d[5]); box.addView(ant);
        CheckBox donante = new CheckBox(this); donante.setText(tr("🫀 Soy donante de órganos")); donante.setChecked(d.length > 7 && "Sí".equalsIgnoreCase(d[7])); box.addView(donante);
        tiene.setOnCheckedChangeListener((b,c)->{ alergia.setEnabled(c); if(!c) alergia.setText(""); });
        AlertDialog dialog = new AlertDialog.Builder(this).setTitle(tr("Historia clínica de emergencia")).setView(box).setPositiveButton(tr("Guardar"),null).setNegativeButton(tr("Cancelar"),null).create();
        dialog.setOnShowListener(x -> dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
            String al = alergia.getText().toString().trim();
            if(tiene.isChecked() && al.isEmpty()){ alergia.setError(tr("Indica la alergia")); return; }
            String m=meds.getText().toString().trim(); String a=ant.getText().toString().trim();
            if(m.isEmpty())m="Ninguno"; if(a.isEmpty())a="Ninguno"; if(!tiene.isChecked())al="NO";
            db.actualizarDatosMedicos(email,al,m,a);
            db.actualizarDonanteOrganos(email, donante.isChecked() ? "Sí" : "No");
            getSharedPreferences("data",0).edit().putString("allergy",al).putString("medicines",m).putString("conditions",a).apply();
            cargar(); toast("Datos médicos guardados offline"); dialog.dismiss();
        })); dialog.show();
    }
    private EditText campo(String hint,String value){ EditText e=new EditText(this); e.setHint(hint); e.setText(value); e.setSingleLine(true); e.setTextSize(16); e.setPadding(dp(12),dp(8),dp(12),dp(8)); LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,dp(58)); lp.setMargins(0,0,0,dp(10)); e.setLayoutParams(lp); e.setBackgroundResource(R.drawable.input_profile_pro); return e; }
}
