package com.example.ruralsos;

import android.Manifest;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraManager;
import android.media.AudioAttributes;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.PowerManager;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.provider.Settings;
import android.telephony.SmsMessage;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Recibe un SMS RuralSOS firmado y mantiene vivo el proceso el tiempo suficiente
 * para ejecutar alarma + vibración + linterna incluso en dispositivos Samsung que
 * finalizan agresivamente un BroadcastReceiver cuando onReceive() termina.
 */
public class CriticalSmsReceiver extends BroadcastReceiver {
    // Canal nuevo: Android no permite cambiar sonido/importancia de un canal ya creado.
    public static final String CHANNEL_ID = "ruralsos_critical_v2";

    @Override
    public void onReceive(Context context, Intent intent) {
        if (!"android.provider.Telephony.SMS_RECEIVED".equals(intent.getAction())) return;
        if (!context.getSharedPreferences("data", 0).getBoolean("critical_mode", true)) return;

        Bundle b = intent.getExtras();
        if (b == null) return;
        Object[] pdus = (Object[]) b.get("pdus");
        if (pdus == null || pdus.length == 0) return;

        String format = b.getString("format");
        StringBuilder body = new StringBuilder();
        String origin = "";
        for (Object pdu : pdus) {
            SmsMessage sms = Build.VERSION.SDK_INT >= 23
                    ? SmsMessage.createFromPdu((byte[]) pdu, format)
                    : SmsMessage.createFromPdu((byte[]) pdu);
            if (sms != null) {
                if (origin.isEmpty()) origin = sms.getOriginatingAddress();
                if (sms.getMessageBody() != null) body.append(sms.getMessageBody());
            }
        }

        CriticalAlertProtocol.Parsed parsed = CriticalAlertProtocol.parseAndVerify(context, body.toString());
        if (parsed == null) return; // SMS normal o HMAC distinto: no activar alarma.

        DatabaseHelper db = new DatabaseHelper(context);
        if (db.alertaCriticaYaProcesada(parsed.id)) return;
        db.guardarAlertaCriticaRecibida(parsed.id, origin, parsed.humanMessage, parsed.signature, "HMAC_OK");

        // goAsync() evita que Android mate el proceso antes de terminar el patrón de 7–8 s.
        final PendingResult pending = goAsync();
        final Context app = context.getApplicationContext();
        final String source = origin;
        ExecutorService executor = Executors.newSingleThreadExecutor();
        executor.execute(() -> {
            PowerManager.WakeLock wakeLock = null;
            MediaPlayer player = null;
            try {
                PowerManager pm = (PowerManager) app.getSystemService(Context.POWER_SERVICE);
                if (pm != null) {
                    wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "RuralSOS:CriticalAlert");
                    wakeLock.acquire(12000L);
                }

                createChannel(app);
                notifyCritical(app, parsed, source);
                criticalVibration(app);
                long effectStart = android.os.SystemClock.elapsedRealtime();
                player = startCriticalSound(app);
                criticalFlashBlocking(app);
                // Aunque no haya permiso de cámara o el teléfono no tenga flash,
                // conserva el sonido varios segundos para que la alerta sea perceptible.
                long elapsed = android.os.SystemClock.elapsedRealtime() - effectStart;
                long remaining = 6500L - elapsed;
                if (remaining > 0) {
                    try { Thread.sleep(remaining); } catch (InterruptedException ie) { Thread.currentThread().interrupt(); }
                }
            } catch (Exception ignored) {
                // La notificación/alarma intenta continuar con las funciones disponibles.
            } finally {
                if (player != null) {
                    try { if (player.isPlaying()) player.stop(); } catch (Exception ignored) { }
                    try { player.release(); } catch (Exception ignored) { }
                }
                if (wakeLock != null && wakeLock.isHeld()) {
                    try { wakeLock.release(); } catch (Exception ignored) { }
                }
                try { pending.finish(); } catch (Exception ignored) { }
                executor.shutdown();
            }
        });
    }

    private boolean english(Context c) {
        return "English".equals(c.getSharedPreferences("data", 0).getString("language", "Quechua Cajamarca"));
    }

    private boolean quechua(Context c) {
        return c.getSharedPreferences("data", 0).getString("language", "Quechua Cajamarca").contains("Quechua");
    }

    private String local(Context c, String es, String en, String qu) {
        if (english(c)) return en;
        if (quechua(c)) return qu;
        return es;
    }

    private void createChannel(Context c) {
        if (Build.VERSION.SDK_INT < 26) return;
        NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm == null) return;
        NotificationChannel ch = new NotificationChannel(
                CHANNEL_ID,
                local(c, "Alertas críticas RuralSOS", "Critical RuralSOS alerts", "RuralSOS utqay willakuykuna"),
                NotificationManager.IMPORTANCE_HIGH
        );
        ch.setDescription(local(c, "SOS RuralSOS autenticado: sonido, vibración y aviso visual", "Authenticated RuralSOS SOS: sound, vibration, and visual alert", "RuralSOS SOS chiqapchasqa: uyarina, kuyuy, k'anchay"));
        ch.enableVibration(true);
        ch.setVibrationPattern(new long[]{0, 350, 180, 350, 180, 900});
        ch.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);
        Uri alarm = Settings.System.DEFAULT_ALARM_ALERT_URI;
        if (alarm == null) alarm = Settings.System.DEFAULT_NOTIFICATION_URI;
        AudioAttributes aa = new AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_ALARM)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build();
        ch.setSound(alarm, aa);
        nm.createNotificationChannel(ch);
    }

    private void notifyCritical(Context c, CriticalAlertProtocol.Parsed p, String origin) {
        Intent open = new Intent(c, CriticalAlertActivity.class)
                .putExtra("id_sos", p.id)
                .putExtra("message", p.humanMessage)
                .putExtra("origin", origin)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent pi = PendingIntent.getActivity(
                c,
                p.id.hashCode(),
                open,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );

        Notification.Builder nb = Build.VERSION.SDK_INT >= 26
                ? new Notification.Builder(c, CHANNEL_ID)
                : new Notification.Builder(c);
        nb.setSmallIcon(android.R.drawable.stat_sys_warning)
                .setContentTitle(local(c, "🚨 ALERTA RURALSOS RECIBIDA", "🚨 RURALSOS ALERT RECEIVED", "🚨 RURALSOS WILLAY CHASKISQA"))
                .setContentText(local(c, "Alerta válida · ", "Valid alert · ", "Chiqap willakuy · ") + p.id)
                .setStyle(new Notification.BigTextStyle().bigText(p.humanMessage))
                .setCategory(Notification.CATEGORY_ALARM)
                .setPriority(Notification.PRIORITY_MAX)
                .setVisibility(Notification.VISIBILITY_PUBLIC)
                .setAutoCancel(true)
                .setContentIntent(pi);
        if (Build.VERSION.SDK_INT < 26) {
            nb.setDefaults(Notification.DEFAULT_SOUND | Notification.DEFAULT_VIBRATE | Notification.DEFAULT_LIGHTS);
        }

        NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm != null) nm.notify(p.id.hashCode(), nb.build());
    }

    private void criticalVibration(Context c) {
        try {
            Vibrator v = (Vibrator) c.getSystemService(Context.VIBRATOR_SERVICE);
            if (v == null) return;
            long[] pattern = {0, 350, 180, 350, 180, 350, 300, 1000};
            if (Build.VERSION.SDK_INT >= 26)
                v.vibrate(VibrationEffect.createWaveform(pattern, -1));
            else
                v.vibrate(pattern, -1);
        } catch (Exception ignored) { }
    }

    private MediaPlayer startCriticalSound(Context c) {
        try {
            Uri u = Settings.System.DEFAULT_ALARM_ALERT_URI;
            if (u == null) u = Settings.System.DEFAULT_NOTIFICATION_URI;
            if (u == null) return null;

            MediaPlayer mp = new MediaPlayer();
            if (Build.VERSION.SDK_INT >= 21) {
                mp.setAudioAttributes(new AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_ALARM)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                        .build());
            } else {
                mp.setAudioStreamType(android.media.AudioManager.STREAM_ALARM);
            }
            mp.setDataSource(c, u);
            mp.setLooping(true);
            mp.prepare();
            mp.start();
            return mp;
        } catch (Exception ignored) {
            return null;
        }
    }

    /** Ejecuta ON 300 / OFF 300 / ON 300 / OFF 300 / ON 1000, 3 veces. */
    private void criticalFlashBlocking(Context c) {
        if (!c.getSharedPreferences("data", 0).getBoolean("flash_sos", true)) return;
        if (Build.VERSION.SDK_INT >= 23 && c.checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED)
            return;

        CameraManager cm = null;
        String cameraId = null;
        try {
            cm = (CameraManager) c.getSystemService(Context.CAMERA_SERVICE);
            if (cm == null) return;
            for (String id : cm.getCameraIdList()) {
                Boolean available = cm.getCameraCharacteristics(id).get(CameraCharacteristics.FLASH_INFO_AVAILABLE);
                if (Boolean.TRUE.equals(available)) { cameraId = id; break; }
            }
            if (cameraId == null) return;

            long[] durations = {300, 300, 300, 300, 1000, 300};
            for (int repeat = 0; repeat < 3; repeat++) {
                for (int i = 0; i < durations.length; i++) {
                    boolean on = (i % 2 == 0);
                    try { cm.setTorchMode(cameraId, on); } catch (Exception ignored) { }
                    try { Thread.sleep(durations[i]); } catch (InterruptedException ie) {
                        Thread.currentThread().interrupt();
                        return;
                    }
                }
            }
        } catch (Exception ignored) {
        } finally {
            if (cm != null && cameraId != null) {
                try { cm.setTorchMode(cameraId, false); } catch (Exception ignored) { }
            }
        }
    }
}
