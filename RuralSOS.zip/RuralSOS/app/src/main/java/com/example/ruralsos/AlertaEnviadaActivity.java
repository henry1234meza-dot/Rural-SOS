package com.example.ruralsos;

import android.os.*;

public class AlertaEnviadaActivity extends ActividadBase {
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.pantalla_alerta_enviada);
        findViewById(R.id.btnHome).setOnClickListener(v -> {
            go(PrincipalActivity.class);
            finish();
        });
    }
}
