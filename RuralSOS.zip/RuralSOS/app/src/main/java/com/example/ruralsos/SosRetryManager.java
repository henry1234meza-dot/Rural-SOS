package com.example.ruralsos;

import android.content.*;
import android.content.pm.PackageManager;
import android.Manifest;

import java.util.*;

public class SosRetryManager {
    public static int reintentar(Context ctx) {
        if (android.os.Build.VERSION.SDK_INT >= 23 && ctx.checkSelfPermission(Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED)
            return 0;
        DatabaseHelper db = new DatabaseHelper(ctx);
        int enviados = 0;
        for (String[] p : db.listarSosPendientes()) {
            int id = Integer.parseInt(p[0]);
            db.marcarIntentoPendiente(id);
            long h = db.guardarAlertaSOS(0, new java.text.SimpleDateFormat("dd/MM/yyyy HH:mm", java.util.Locale.getDefault()).format(new java.util.Date()), p[2], p[3], "", p[1], "REINTENTO");
            int ok = SosUtils.enviarATodos(ctx, db, p[1], h);
            if (ok > 0) {
                db.eliminarSosPendiente(id);
                enviados += ok;
            }
        }
        return enviados;
    }
}
