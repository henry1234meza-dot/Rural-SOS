package com.example.ruralsos.model;

public class CentroSalud {
    public int id;
    public String nombre, direccion, telefono, latitud, longitud, tipo;
}
