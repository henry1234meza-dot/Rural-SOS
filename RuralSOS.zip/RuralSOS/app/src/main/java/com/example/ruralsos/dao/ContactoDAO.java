package com.example.ruralsos.dao;

import android.content.Context;
import com.example.ruralsos.DatabaseHelper;
import java.util.ArrayList;

public class ContactoDAO {
    private final DatabaseHelper db;
    public ContactoDAO(Context context) { db = new DatabaseHelper(context); }
    public ArrayList<String[]> listar() { return db.listarContactos(); }
    public long agregar(String nombre, String telefono, String parentesco) { return db.agregarContacto(nombre, telefono, parentesco); }
}
