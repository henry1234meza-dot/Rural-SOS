package com.example.ruralsos.model;

public class Configuracion {
    public int id, usuarioId;
    public String idioma, tema;
    public boolean sonido, vibracion, notificaciones, biometriaActivada;
}
