package com.example.ruralsos;

import android.Manifest;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.os.SystemClock;
import android.view.View;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.TextView;

import java.util.Locale;

/** Pantalla de ubicación con GPS en tiempo real y mapa centrado en el usuario. */
public class UbicacionActivity extends ActividadBase implements LocationListener {
    double lat = -7.1526, lng = -78.5124;
    TextView data, place, offline, status;
    WebView web;
    LocationManager lm;
    boolean mapReady = false;
    boolean hasRealLocation = false;
    double mapLat = Double.NaN, mapLng = Double.NaN;
    long lastMapRefreshMs = 0L;
    static final String MAPS_API_KEY = "AIzaSyAOVYRIgupAurZup5y1PRh8Ismb1A3lLao";

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.pantalla_ubicacion);
        data = findViewById(R.id.txtLocationData);
        place = findViewById(R.id.txtLocationPlace);
        web = findViewById(R.id.locationWebMap);
        offline = findViewById(R.id.locationOffline);
        status = findViewById(R.id.txtGpsStatus);

        findViewById(R.id.btnBack).setOnClickListener(v -> finish());
        findViewById(R.id.btnOpenMaps).setOnClickListener(v -> openMaps());
        findViewById(R.id.btnRoute).setOnClickListener(v -> openMaps());
        findViewById(R.id.btnShareLocation).setOnClickListener(v ->
                share(tr("🚨 RuralSOS - Necesito ayuda. Mi ubicación GPS en tiempo real: ") + googleLink(lat, lng)));

        lm = (LocationManager) getSystemService(LOCATION_SERVICE);
        readLastLocation();
        updateTexts("Preparando GPS...");
        setupMap();
        requestGps();
    }

    void requestGps() {
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION}, 77);
            return;
        }
        startRealtimeGps();
    }

    @Override
    public void onRequestPermissionsResult(int r, String[] p, int[] g) {
        super.onRequestPermissionsResult(r, p, g);
        if (r == 77 && g.length > 0 && g[0] == PackageManager.PERMISSION_GRANTED) {
            startRealtimeGps();
        } else {
            updateTexts("Permiso de ubicación no concedido. Se usa ubicación guardada/offline.");
        }
    }

    void startRealtimeGps() {
        try {
            Location best = getBestLastLocation();
            if (best != null) applyLocation(best, "Última ubicación del celular", false);

            if (lm != null && lm.isProviderEnabled(LocationManager.GPS_PROVIDER))
                lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1500, 1, this);
            if (lm != null && lm.isProviderEnabled(LocationManager.NETWORK_PROVIDER))
                lm.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 1500, 1, this);

            updateTexts("GPS activo: leyendo tu ubicación en tiempo real desde el celular.");
        } catch (SecurityException e) {
            updateTexts("Permiso GPS pendiente.");
        } catch (Exception e) {
            updateTexts("GPS no disponible. Activa ubicación del celular.");
        }
    }

    void readLastLocation() {
        Location best = getBestLastLocation();
        if (best != null) applyLocation(best, "Ubicación guardada del celular", false);
    }

    void applyLocation(Location l, String msg, boolean realtime) {
        if (l == null) return;
        lat = l.getLatitude();
        lng = l.getLongitude();
        hasRealLocation = true;
        getSharedPreferences("data", 0).edit()
                .putString("last_lat", String.valueOf(lat))
                .putString("last_lng", String.valueOf(lng)).apply();
        updateTexts(msg);

        // Actualiza el mapa solo cuando la posición cambia de forma útil. Así el punto
        // permanece centrado sin el parpadeo que producía recargar en cada lectura GPS.
        if (mapReady) refreshMapIfNeeded(realtime);
    }

    @Override
    public void onLocationChanged(Location l) {
        String msg = "GPS tiempo real activo • precisión aprox. " + Math.max(1, (int) l.getAccuracy()) + " m";
        applyLocation(l, msg, true);
    }

    @Override public void onProviderEnabled(String p) { updateTexts("Proveedor activo: " + p); }
    @Override public void onProviderDisabled(String p) { updateTexts("Activa el GPS para mayor precisión."); }
    @Override public void onStatusChanged(String p, int s, Bundle e) { }

    void updateTexts(String msg) {
        if (data != null)
            data.setText(tr(String.format(Locale.US, "Latitud: %.5f   Longitud: %.5f", lat, lng)));
        if (place != null)
            place.setText(tr("📍 Tu ubicación actual del celular") + "\n" + googleLink(lat, lng));
        if (status != null) {
            String network = online() ? "🌐 Internet activo: mapa en vivo." : "📴 Sin internet: modo offline con GPS/local.";
            status.setText(tr(msg) + "\n" + tr(network));
        }
    }

    void setupMap() {
        mapReady = true;
        WebSettings ws = web.getSettings();
        ws.setJavaScriptEnabled(true);
        ws.setDomStorageEnabled(true);
        ws.setLoadWithOverviewMode(false);
        ws.setUseWideViewPort(false);
        ws.setBuiltInZoomControls(false);
        ws.setDisplayZoomControls(false);
        web.setWebViewClient(new WebViewClient() {
            @Override
            public void onReceivedError(WebView v, WebResourceRequest r, WebResourceError e) {
                if (r == null || r.isForMainFrame()) showOffline();
            }
        });
        loadMap();
    }

    void showOffline() {
        if (offline != null) offline.setVisibility(View.VISIBLE);
        if (web != null) web.setVisibility(View.GONE);
    }

    void showOnline() {
        if (offline != null) offline.setVisibility(View.GONE);
        if (web != null) web.setVisibility(View.VISIBLE);
    }

    void refreshMapIfNeeded(boolean realtime) {
        if (!online()) { showOffline(); return; }
        long now = SystemClock.elapsedRealtime();
        float distance = Float.MAX_VALUE;
        if (!Double.isNaN(mapLat) && !Double.isNaN(mapLng)) {
            float[] out = new float[1];
            Location.distanceBetween(mapLat, mapLng, lat, lng, out);
            distance = out[0];
        }
        // Primera ubicación real: siempre centra. Luego solo si se desplazó > 12 m
        // y pasaron unos segundos, evitando saltos continuos del WebView.
        if (Double.isNaN(mapLat) || (distance > 12f && now - lastMapRefreshMs > 4500L) || (realtime && now - lastMapRefreshMs > 12000L)) {
            loadMap();
        }
    }

    void loadMap() {
        if (web == null) return;
        if (!online()) { showOffline(); return; }
        showOnline();
        mapLat = lat;
        mapLng = lng;
        lastMapRefreshMs = SystemClock.elapsedRealtime();

        // PLACE (no VIEW) hace aparecer el marcador rojo en la coordenada exacta.
        // Zoom 19 acerca la calle/manzana para que el usuario identifique mejor dónde está.
        String src = "https://www.google.com/maps/embed/v1/place?key=" + MAPS_API_KEY
                + "&q=" + lat + "," + lng + "&zoom=19&maptype=roadmap";
        String html = "<html><head><meta name='viewport' content='width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no'></head>"
                + "<body style='margin:0;padding:0;overflow:hidden;background:#eefaf5'>"
                + "<iframe width='100%' height='100%' frameborder='0' style='border:0;border-radius:18px' allowfullscreen src='" + src + "'></iframe>"
                + "</body></html>";
        web.loadDataWithBaseURL("https://www.google.com/", html, "text/html", "UTF-8", null);
    }

    void openMaps() {
        try {
            mapsLatLng(lat, lng, tr("Mi ubicación RuralSOS GPS"));
        } catch (Exception e) {
            toast("Google Maps no está instalado. Puedes compartir tu ubicación.");
        }
    }

    @Override
    protected void onDestroy() {
        try { if (lm != null) lm.removeUpdates(this); } catch (Exception ignored) { }
        if (web != null) {
            try { web.stopLoading(); web.destroy(); } catch (Exception ignored) { }
        }
        super.onDestroy();
    }
}
