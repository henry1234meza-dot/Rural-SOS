package com.example.ruralsos;

import android.content.Context;
import java.util.UUID;

/** Protocolo legible + firma HMAC. El bloque #RS1 permite a otra RuralSOS reconocer el SMS. */
public final class CriticalAlertProtocol {
    public static final String MARKER = "\n#RS1|";
    private CriticalAlertProtocol() {}

    public static String buildSignedMessage(Context ctx, String humanMessage) {
        String id = "SOS-" + UUID.randomUUID().toString().substring(0, 8).toUpperCase();
        long ts = System.currentTimeMillis() / 1000L;
        String canonical = humanMessage + "\nID:" + id + "\nTS:" + ts;
        String sig = HmacUtils.sign(ctx, canonical);
        return canonical + MARKER + id + "|" + ts + "|" + sig;
    }

    public static Parsed parseAndVerify(Context ctx, String fullSms) {
        if (fullSms == null) return null;
        int p = fullSms.lastIndexOf(MARKER);
        if (p < 0) return null;
        String canonical = fullSms.substring(0, p);
        String tail = fullSms.substring(p + MARKER.length()).trim();
        String[] x = tail.split("\\|", -1);
        if (x.length != 3) return null;
        String id = x[0], ts = x[1], sig = x[2];
        if (!canonical.endsWith("\nID:" + id + "\nTS:" + ts)) return null;
        if (!HmacUtils.verify(ctx, canonical, sig)) return null;
        String human = canonical.substring(0, canonical.length() - ("\nID:" + id + "\nTS:" + ts).length());
        return new Parsed(id, ts, human, sig);
    }

    public static final class Parsed {
        public final String id, timestamp, humanMessage, signature;
        Parsed(String id, String timestamp, String humanMessage, String signature) {
            this.id=id; this.timestamp=timestamp; this.humanMessage=humanMessage; this.signature=signature;
        }
    }
}
