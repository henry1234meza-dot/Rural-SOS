package com.example.ruralsos;

import android.content.Context;
import android.content.SharedPreferences;
import android.util.Base64;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;

/** Firma y verificación HMAC-SHA256 para alertas RuralSOS. Funciona sin internet. */
public final class HmacUtils {
    private static final String ALG = "HmacSHA256";
    private static final String PREF = "data";
    private static final String KEY = "critical_hmac_key";
    // Solo valor inicial para pruebas. En Configuración debe ponerse el MISMO código en emisor y receptor.
    private static final String DEFAULT_PAIRING_CODE = "RURAL2026";

    private HmacUtils() {}

    public static String getPairingCode(Context ctx) {
        SharedPreferences sp = ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE);
        return sp.getString(KEY, DEFAULT_PAIRING_CODE);
    }

    public static void setPairingCode(Context ctx, String code) {
        String clean = code == null ? "" : code.trim();
        if (clean.length() < 6) throw new IllegalArgumentException("El código debe tener al menos 6 caracteres");
        ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit().putString(KEY, clean).apply();
    }

    public static String sign(Context ctx, String canonical) {
        try {
            Mac mac = Mac.getInstance(ALG);
            mac.init(new SecretKeySpec(getPairingCode(ctx).getBytes(StandardCharsets.UTF_8), ALG));
            byte[] out = mac.doFinal(canonical.getBytes(StandardCharsets.UTF_8));
            // Base64 URL-safe sin saltos: más corto que hexadecimal para SMS.
            return Base64.encodeToString(out, Base64.NO_WRAP | Base64.URL_SAFE | Base64.NO_PADDING);
        } catch (Exception e) {
            throw new IllegalStateException("No se pudo firmar la alerta", e);
        }
    }

    public static boolean verify(Context ctx, String canonical, String receivedSignature) {
        try {
            byte[] a = sign(ctx, canonical).getBytes(StandardCharsets.UTF_8);
            byte[] b = (receivedSignature == null ? "" : receivedSignature.trim()).getBytes(StandardCharsets.UTF_8);
            return MessageDigest.isEqual(a, b);
        } catch (Exception e) {
            return false;
        }
    }
}
