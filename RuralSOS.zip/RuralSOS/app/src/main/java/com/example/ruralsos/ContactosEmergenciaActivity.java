package com.example.ruralsos;

import android.os.*;
import android.app.*;
import android.widget.*;
import android.view.*;

import java.util.*;

import android.content.*;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Color;
import android.net.Uri;
import android.provider.ContactsContract;

public class ContactosEmergenciaActivity extends ActividadBase {
    LinearLayout list;
    ArrayList<String[]> data = new ArrayList<>();
    SharedPreferences sp;
    DatabaseHelper db;
    private static final int REQ_CONTACT_PERMISSION = 210;
    private static final int REQ_PICK_CONTACT = 211;

    protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.pantalla_contactos_emergencia);
        sp = getSharedPreferences("data", 0);
        db = new DatabaseHelper(this);
        list = findViewById(R.id.contactList);
        load();
        render();
        findViewById(R.id.btnBack).setOnClickListener(v -> finish());
        findViewById(R.id.btnAdd).setOnClickListener(v -> showEditor(-1));
        findViewById(R.id.btnImport).setOnClickListener(v -> importarDesdeAgenda());
    }

    void importarDesdeAgenda() {
        if (android.os.Build.VERSION.SDK_INT >= 23 && checkSelfPermission(android.Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{android.Manifest.permission.READ_CONTACTS}, REQ_CONTACT_PERMISSION);
            return;
        }
        abrirAgenda();
    }

    void abrirAgenda() {
        Intent intent = new Intent(Intent.ACTION_PICK, ContactsContract.CommonDataKinds.Phone.CONTENT_URI);
        try {
            startActivityForResult(intent, REQ_PICK_CONTACT);
        } catch (Exception e) {
            toast("No se pudo abrir la agenda del teléfono");
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_CONTACT_PERMISSION) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                abrirAgenda();
            } else {
                toast("Permiso denegado. Puedes agregar el contacto manualmente.");
            }
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent dataIntent) {
        super.onActivityResult(requestCode, resultCode, dataIntent);
        if (requestCode == REQ_PICK_CONTACT && resultCode == RESULT_OK && dataIntent != null) {
            Uri uri = dataIntent.getData();
            Cursor cursor = null;
            try {
                cursor = getContentResolver().query(uri, null, null, null, null);
                if (cursor != null && cursor.moveToFirst()) {
                    String nombre = cursor.getString(cursor.getColumnIndexOrThrow(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME));
                    String telefono = cursor.getString(cursor.getColumnIndexOrThrow(ContactsContract.CommonDataKinds.Phone.NUMBER));
                    telefono = telefono == null ? "" : telefono.replace(" ", "").replace("-", "").replace("(", "").replace(")", "");
                    if (nombre == null || nombre.trim().isEmpty() || telefono.trim().isEmpty()) {
                        toast("El contacto no tiene teléfono válido");
                        return;
                    }
                    db.agregarContacto(nombre.trim(), telefono.trim(), "Contacto SOS");
                    load();
                    render();
                    toast("Contacto importado y guardado en SQLite");
                }
            } catch (Exception e) {
                toast("No se pudo importar el contacto");
            } finally {
                if (cursor != null) cursor.close();
            }
        }
    }

    void load() {
        data.clear();
        data.addAll(db.listarContactos());
    }

    void save() {
        // Los contactos ahora se guardan en SQLite local mediante DatabaseHelper.
    }

    void render() {
        list.removeAllViews();
        for (int i = 0; i < data.size(); i++) {
            final int pos = i;
            String[] c = data.get(i);
            LinearLayout card = new LinearLayout(this);
            card.setOrientation(LinearLayout.VERTICAL);
            card.setPadding(24, 22, 24, 22);
            card.setBackgroundResource(R.drawable.card_contact_pro);
            card.setClickable(true);

            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(Gravity.CENTER_VERTICAL);
            TextView avatar = new TextView(this);
            avatar.setText("👤");
            avatar.setTextSize(32);
            avatar.setGravity(Gravity.CENTER);
            avatar.setBackgroundResource(R.drawable.avatar_circle);
            LinearLayout info = new LinearLayout(this);
            info.setOrientation(LinearLayout.VERTICAL);
            info.setGravity(Gravity.CENTER_VERTICAL);
            info.setPadding(14, 0, 8, 0);
            TextView name = new TextView(this);
            name.setText(c[1]);
            name.setTextSize(19);
            name.setTextColor(getResources().getColor(R.color.text_dark));
            name.setTypeface(null, 1);
            TextView phone = new TextView(this);
            phone.setText("📞 " + c[2]);
            phone.setTextSize(15);
            phone.setTextColor(getResources().getColor(R.color.muted));
            phone.setPadding(0, 4, 0, 0);
            TextView tag = new TextView(this);
            tag.setText(tr("Contacto SOS"));
            tag.setTextSize(12);
            tag.setTextColor(getResources().getColor(R.color.green_dark));
            tag.setPadding(0, 4, 0, 0);
            info.addView(name, new LinearLayout.LayoutParams(-1, -2));
            info.addView(phone, new LinearLayout.LayoutParams(-1, -2));
            info.addView(tag, new LinearLayout.LayoutParams(-1, -2));

            LinearLayout actions = new LinearLayout(this);
            actions.setGravity(Gravity.RIGHT | Gravity.CENTER_VERTICAL);
            actions.setOrientation(LinearLayout.HORIZONTAL);
            Button call = mini("📞", "Llamar");
            Button edit = mini("✏️", "Editar");
            Button del = mini("🗑️", "Eliminar");
            LinearLayout.LayoutParams iconLp = new LinearLayout.LayoutParams(dp(48), dp(48));
            iconLp.setMargins(5, 0, 0, 0);
            actions.addView(call, iconLp);
            LinearLayout.LayoutParams iconLp2 = new LinearLayout.LayoutParams(dp(48), dp(48));
            iconLp2.setMargins(8, 0, 0, 0);
            actions.addView(edit, iconLp2);
            LinearLayout.LayoutParams iconLp3 = new LinearLayout.LayoutParams(dp(48), dp(48));
            iconLp3.setMargins(8, 0, 0, 0);
            actions.addView(del, iconLp3);

            row.addView(avatar, new LinearLayout.LayoutParams(dp(58), dp(58)));
            row.addView(info, new LinearLayout.LayoutParams(0, dp(74), 1));
            row.addView(actions, new LinearLayout.LayoutParams(-2, dp(74)));
            card.addView(row, new LinearLayout.LayoutParams(-1, -2));

            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
            lp.setMargins(0, 0, 0, 16);
            list.addView(card, lp);
            call.setOnClickListener(v -> dial(c[2]));
            edit.setOnClickListener(v -> showEditor(pos));
            del.setOnClickListener(v -> confirmDelete(pos));
            card.setOnClickListener(v -> showOptions(pos));
        }
    }

    Button mini(String icon, String label) {
        Button b = new Button(this);
        b.setText(icon);
        b.setAllCaps(false);
        b.setTextSize(20);
        b.setTextColor(label.equals("Eliminar") ? Color.parseColor("#B91F2E") : Color.parseColor("#66513C"));
        b.setContentDescription(label);
        b.setMinWidth(0);
        b.setMinHeight(0);
        b.setPadding(0, 0, 0, 0);
        b.setBackgroundColor(Color.TRANSPARENT);
        return b;
    }

    int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }

    void confirmDelete(int pos) {
        new AlertDialog.Builder(this)
                .setTitle(tr("Eliminar contacto"))
                .setMessage(tr("¿Deseas eliminar a ") + data.get(pos)[1] + "?")
                .setPositiveButton(tr("Eliminar"), (d, w) -> {
                    db.eliminarContacto(Integer.parseInt(data.get(pos)[0]));
                    load();
                    render();
                    toast("Contacto eliminado");
                })
                .setNegativeButton(tr("Cancelar"), null)
                .show();
    }

    void showOptions(int pos) {
        String[] options = {tr("Llamar"), tr("Editar contacto"), tr("Eliminar contacto"), tr("Enviar alerta de prueba")};
        new AlertDialog.Builder(this).setTitle(data.get(pos)[1]).setItems(options, (d, which) -> {
            if (which == 0) dial(data.get(pos)[2]);
            if (which == 1) showEditor(pos);
            if (which == 2) confirmDelete(pos);
            if (which == 3)
                share("Prueba RuralSOS: este contacto recibirá alertas SOS con ubicación.");
        }).show();
    }

    void showEditor(int pos) {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(false);
        scroll.setClipToPadding(false);
        scroll.setPadding(0, 0, 0, dp(180));
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(28, 8, 28, 0);
        EditText n = new EditText(this);
        n.setHint(tr("Nombre del contacto"));
        EditText p = new EditText(this);
        p.setHint(tr("Teléfono"));
        p.setInputType(3);
        if (pos >= 0) {
            n.setText(data.get(pos)[1]);
            p.setText(data.get(pos)[2]);
        }
        box.addView(n);
        box.addView(p);
        scroll.addView(box);
        AlertDialog dialog = new AlertDialog.Builder(this).setTitle(tr(pos < 0 ? "Agregar contacto SOS" : "Editar contacto")).setView(scroll).setPositiveButton(tr("Guardar"), (d, w) -> {
            String name = n.getText().toString().trim(), phone = p.getText().toString().trim();
            if (name.isEmpty() || phone.isEmpty()) {
                toast("Completa nombre y teléfono");
                return;
            }
            if (pos >= 0) db.actualizarContacto(Integer.parseInt(data.get(pos)[0]), name, phone);
            else db.agregarContacto(name, phone, "Contacto SOS");
            load();
            render();
            toast("Contacto guardado en SQLite");
        }).setNegativeButton(tr("Cancelar"), null).create();
        dialog.setOnShowListener(di -> {
            dialog.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
            n.requestFocus();
        });
        dialog.show();
    }
}
