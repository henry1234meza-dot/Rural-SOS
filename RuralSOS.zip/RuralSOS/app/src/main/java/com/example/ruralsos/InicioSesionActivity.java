package com.example.ruralsos;

import android.os.*;
import android.widget.*;
import android.content.*;
import android.util.Patterns;
import android.app.*;
import android.view.WindowManager;
import android.hardware.biometrics.BiometricPrompt;
import android.hardware.biometrics.BiometricPrompt.AuthenticationCallback;
import android.text.method.PasswordTransformationMethod;
import android.text.method.HideReturnsTransformationMethod;

import java.util.concurrent.*;

public class InicioSesionActivity extends ActividadBase {
    EditText u, p;
    TextView togglePass;
    ScrollView scrollLogin;
    SharedPreferences sp;
    DatabaseHelper db;
    boolean passVisible = false;

    protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.pantalla_inicio_sesion);
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_NOTHING);
        sp = getSharedPreferences("data", 0);
        db = new DatabaseHelper(this);
        u = findViewById(R.id.edtUser);
        p = findViewById(R.id.edtPass);
        scrollLogin = findViewById(R.id.scrollLogin);
        togglePass = findViewById(R.id.txtTogglePass);
        togglePass.setOnClickListener(v -> togglePassword());
        findViewById(R.id.btnLogin).setOnClickListener(v -> login(false));
        findViewById(R.id.btnFingerprint).setOnClickListener(v -> fingerprintLogin());
        findViewById(R.id.btnGoRegister).setOnClickListener(v -> go(RegistroUsuarioActivity.class));
        findViewById(R.id.txtForgot).setOnClickListener(v -> toast("Recuperación lista para integrar. Usa tu cuenta local registrada."));
    }

    void login(boolean biometric) {
        if (biometric) {
            loginConHuellaRegistrada();
            return;
        }
        String email = u.getText().toString().trim();
        String pass = p.getText().toString().trim();
        if (email.isEmpty()) {
            u.setError(tr("Ingresa tu correo"));
            toast("Correo obligatorio");
            return;
        }
        if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            u.setError(tr("Correo incorrecto"));
            toast("Correo incorrecto");
            return;
        }
        if (pass.isEmpty()) {
            p.setError(tr("Ingresa tu contraseña"));
            toast("Contraseña obligatoria");
            return;
        }
        boolean demo = email.equalsIgnoreCase("admin@gmail.com") && pass.equals("123456");
        boolean registered = db.validarLogin(email, pass);
        if (demo || registered) {
            String nombre = "admin";
            if (registered) {
                String[] usuario = db.obtenerUsuarioPorCorreo(email);
                if (usuario != null) {
                    nombre = usuario[0];
                    sp.edit()
                            .putString("name", usuario[0])
                            .putString("dni", usuario[1])
                            .putString("birth", usuario[2])
                            .putString("email", usuario[3])
                            .putString("phone", usuario[4])
                            .putString("address", usuario[5])
                            .putString("blood", usuario[6])
                            .putString("allergy", usuario[7])
                            .putString("emergencyContact", usuario[8])
                            .putString("pass", usuario[9])
                            .apply();
                }
            }
            // La huella queda asociada únicamente a un usuario existente en SQLite.
            // Así nadie puede ingresar con huella si antes no creó una cuenta local.
            if (registered) {
                sp.edit()
                        .putBoolean("finger", true)
                        .putString("registered_email", email)
                        .apply();
                db.actualizarBiometria(email, true);
            }
            sp.edit().putString("user", nombre).putString("email", email).putBoolean("logged_in", true).apply();
            toast("Bienvenido a RuralSOS v1");
            abrirDespuesDeLogin(email);
            finish();
        } else {
            p.setError(tr("Clave incorrecta"));
            toast("Correo o clave incorrecta");
        }
    }

    void abrirDespuesDeLogin(String email) {
        // El consentimiento ya no interrumpe el inicio de sesión.
        // El usuario entra a Inicio y puede configurar las funciones de emergencia desde allí.
        go(PrincipalActivity.class);
    }

    void togglePassword() {
        passVisible = !passVisible;
        if (passVisible) {
            p.setTransformationMethod(HideReturnsTransformationMethod.getInstance());
            togglePass.setText("🙈");
        } else {
            p.setTransformationMethod(PasswordTransformationMethod.getInstance());
            togglePass.setText("👁");
        }
        p.setSelection(p.getText().length());
    }


    void loginConHuellaRegistrada() {
        String correoRegistrado = sp.getString("registered_email", "");
        if (correoRegistrado.isEmpty() || !db.usuarioExiste(correoRegistrado)) {
            toast("Primero debes registrarte para usar huella");
            go(RegistroUsuarioActivity.class);
            return;
        }

        String[] usuario = db.obtenerUsuarioPorCorreo(correoRegistrado);
        if (usuario == null) {
            toast("Usuario local no encontrado. Inicia con correo y clave.");
            return;
        }

        sp.edit()
                .putString("name", usuario[0])
                .putString("user", usuario[0])
                .putString("dni", usuario[1])
                .putString("birth", usuario[2])
                .putString("email", usuario[3])
                .putString("phone", usuario[4])
                .putString("address", usuario[5])
                .putString("blood", usuario[6])
                .putString("allergy", usuario[7])
                .putString("emergencyContact", usuario[8])
                .putString("pass", usuario[9])
                .putBoolean("logged_in", true)
                .apply();

        toast("Huella verificada");
        abrirDespuesDeLogin(correoRegistrado);
        finish();
    }

    void fingerprintLogin() {
        String correoRegistrado = sp.getString("registered_email", "");
        boolean huellaActiva = sp.getBoolean("finger", false);

        if (!huellaActiva || correoRegistrado.isEmpty() || !db.usuarioExiste(correoRegistrado)) {
            toast("Primero debes registrarte e iniciar sesión con tu correo y contraseña");
            go(RegistroUsuarioActivity.class);
            return;
        }

        if (Build.VERSION.SDK_INT >= 28) {
            try {
                Executor ex = Executors.newSingleThreadExecutor();
                BiometricPrompt prompt = new BiometricPrompt.Builder(this).setTitle(tr("RuralSOS v1 Seguro")).setSubtitle(tr("Autenticación con huella")).setDescription(tr("Confirma tu identidad para ingresar")).setNegativeButton(tr("Cancelar"), ex, (d, w) -> runOnUiThread(() -> toast("Acceso cancelado"))).build();
                prompt.authenticate(new android.os.CancellationSignal(), ex, new AuthenticationCallback() {
                    public void onAuthenticationSucceeded(BiometricPrompt.AuthenticationResult r) {
                        runOnUiThread(() -> login(true));
                    }

                    public void onAuthenticationError(int c, CharSequence e) {
                        runOnUiThread(() -> toast("Huella no disponible: " + e));
                    }
                });
            } catch (Exception e) {
                toast("Huella no configurada. Ingresa con clave.");
            }
        } else toast("Huella disponible desde Android 9. Usa correo y clave.");
    }
}
