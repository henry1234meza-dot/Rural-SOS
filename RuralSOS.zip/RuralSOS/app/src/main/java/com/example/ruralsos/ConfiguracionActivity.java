package com.example.ruralsos;

import android.app.*;
import android.content.*;
import android.os.*;
import android.widget.*;
import android.Manifest;
import android.content.pm.PackageManager;

public class ConfiguracionActivity extends ActividadBase {
    SharedPreferences sp;
    DatabaseHelper db;

    protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.pantalla_configuracion);
        sp = getSharedPreferences("data", 0);
        db = new DatabaseHelper(this);

        findViewById(R.id.btnBack).setOnClickListener(v -> finish());
        actualizarIdiomaBoton();
        findViewById(R.id.btnIdioma).setOnClickListener(v -> languageDialog());
        findViewById(R.id.btnSeguridad).setOnClickListener(v -> securityDialog());
        findViewById(R.id.btnOffline).setOnClickListener(v -> panel("Modo sin internet", "La app mantiene contactos, historial y guías de primeros auxilios guardadas localmente. Para mapas reales y centros actualizados se necesita conexión."));
        findViewById(R.id.btnNotificaciones).setOnClickListener(v -> panel("Notificaciones", "Alertas SOS activas con sonido y vibración."));
        findViewById(R.id.btnModoFacil).setOnClickListener(v -> toggle("easy_mode", "Modo fácil"));
        findViewById(R.id.btnLinterna).setOnClickListener(v -> toggle("flash_sos", "Linterna SOS"));
        findViewById(R.id.btnAlertaCritica).setOnClickListener(v -> criticalModeDialog());
        findViewById(R.id.btnClaveHmac).setOnClickListener(v -> pairingCodeDialog());
    }

    void toggle(String key, String nombre) {
        boolean actual=sp.getBoolean(key, key.equals("flash_sos"));
        sp.edit().putBoolean(key,!actual).apply();
        toast(nombre + ((!actual) ? " activado" : " desactivado"));
    }

    void languageDialog() {
        String[] langs = {"Quechua Cajamarca", "Español", "English"};
        String langNow = sp.getString("language", "Quechua Cajamarca");
        int actual = langNow.equals("Español") ? 1 : (langNow.equals("English") ? 2 : 0);
        new AlertDialog.Builder(this)
                .setTitle(tr("Idioma de la aplicación"))
                .setSingleChoiceItems(langs, actual, (d, w) -> {
                    sp.edit().putString("language", langs[w]).apply();
                    db.guardarIdioma(sp.getString("email", ""), langs[w]);
                    d.dismiss();
                    toast("Idioma: " + langs[w]);
                    recreate();
                }).show();
    }

    void actualizarIdiomaBoton() {
        Button btn = findViewById(R.id.btnIdioma);
        if (btn != null) {
            btn.setText(tr("🌐  Idioma") + "\n" + sp.getString("language", "Quechua Cajamarca"));
        }
    }

    void securityDialog() {
        String[] opts = {tr("Activar huella"), tr("Desactivar huella"), tr("Información de acceso local")};
        new AlertDialog.Builder(this).setTitle(tr("Seguridad")).setItems(opts, (d, w) -> {
            if (w == 0) {
                String correoRegistrado = sp.getString("registered_email", "");
                if (correoRegistrado.isEmpty()) {
                    toast("Primero debes registrarte para activar la huella");
                    return;
                }
                sp.edit().putBoolean("finger", true).apply();
                db.actualizarBiometria(correoRegistrado, true);
                toast("Huella activada para tu cuenta registrada");
            } else if (w == 1) {
                sp.edit().putBoolean("finger", false).apply();
                db.actualizarBiometria(sp.getString("registered_email", ""), false);
                toast("Huella desactivada");
            } else {
                panel("Acceso local", "Primero crea una cuenta local en SQLite. Luego podrás ingresar con correo y contraseña o con huella asociada a esa cuenta registrada.\n\nLa huella no permite entrar si no existe un usuario registrado.");
            }
        }).show();
    }

    void panel(String t, String m) {
        new AlertDialog.Builder(this).setTitle(tr(t)).setMessage(tr(m)).setPositiveButton(tr("Entendido"), null).show();
    }
    void criticalModeDialog() {
        boolean active=sp.getBoolean("critical_mode",true);
        String[] opts={tr(active?"Desactivar Modo Alerta Crítica":"Activar Modo Alerta Crítica"),tr("Conceder permisos del receptor"),tr("¿Cómo funciona?")};
        new AlertDialog.Builder(this).setTitle(tr("🚨 Modo Alerta Crítica")).setItems(opts,(d,w)->{
            if(w==0){ sp.edit().putBoolean("critical_mode",!active).apply(); toast("Modo Alerta Crítica " + (!active?"activado":"desactivado")); }
            else if(w==1) requestCriticalPermissions();
            else panel("Modo Alerta Crítica","Si este teléfono recibe un SMS RuralSOS con HMAC válido y comparte el mismo código de vinculación, activa sonido, vibración, flash y una notificación de alta prioridad. No necesita internet.");
        }).show();
    }

    void requestCriticalPermissions(){
        if(Build.VERSION.SDK_INT<23){toast("Permisos listos");return;}
        java.util.ArrayList<String> p=new java.util.ArrayList<>();
        if(checkSelfPermission(Manifest.permission.RECEIVE_SMS)!=PackageManager.PERMISSION_GRANTED)p.add(Manifest.permission.RECEIVE_SMS);
        if(checkSelfPermission(Manifest.permission.CAMERA)!=PackageManager.PERMISSION_GRANTED)p.add(Manifest.permission.CAMERA);
        if(Build.VERSION.SDK_INT>=33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)p.add(Manifest.permission.POST_NOTIFICATIONS);
        if(p.isEmpty())toast("Permisos de alerta crítica listos"); else requestPermissions(p.toArray(new String[0]),901);
    }

    void pairingCodeDialog(){
        final EditText input=new EditText(this); input.setSingleLine(true); input.setHint(tr("Mínimo 6 caracteres"));
        input.setText(HmacUtils.getPairingCode(this)); input.setSelectAllOnFocus(true);
        int pad=(int)(20*getResources().getDisplayMetrics().density);
        android.widget.FrameLayout box=new android.widget.FrameLayout(this); box.setPadding(pad,0,pad,0); box.addView(input);
        new AlertDialog.Builder(this).setTitle(tr("🛡️ Código HMAC compartido"))
                .setMessage(tr("Escribe el mismo código en el RuralSOS emisor y receptor. No lo envíes dentro del SMS de emergencia."))
                .setView(box).setPositiveButton(tr("Guardar"),(d,w)->{
                    try{HmacUtils.setPairingCode(this,input.getText().toString());toast("Código HMAC guardado localmente");}
                    catch(Exception e){toast(e.getMessage());}
                }).setNegativeButton(tr("Cancelar"),null).show();
    }

}
