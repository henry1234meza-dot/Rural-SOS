package com.example.ruralsos;

import android.os.*;
import android.graphics.*;
import android.widget.*;

import com.google.zxing.*;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.qrcode.QRCodeWriter;

public class MedicalQrActivity extends ActividadBase {
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(24), dp(30), dp(24), dp(24));
        TextView t = new TextView(this);
        t.setText(tr("▣ QR MÉDICO OFFLINE"));
        t.setTextSize(24);
        t.setTypeface(null, 1);
        root.addView(t);
        TextView sub = new TextView(this);
        sub.setText(tr("El QR contiene los datos críticos directamente. No abre una página web."));
        sub.setPadding(0, dp(8), 0, dp(18));
        root.addView(sub);
        ImageView iv = new ImageView(this);
        root.addView(iv, new LinearLayout.LayoutParams(-1, dp(340)));
        Button back = new Button(this);
        back.setText(tr("Volver"));
        root.addView(back);
        back.setOnClickListener(v -> finish());
        setContentView(root);
        String email = getSharedPreferences("data", 0).getString("email", "");
        String[] d = new DatabaseHelper(this).obtenerDatosMedicos(email);
        if (d == null) return;
        String data = "RURALSOS|Nombre:" + d[0] + "|DNI:" + d[1] + "|Sangre:" + d[2] + "|Alergia:" + d[3] + "|Medicamentos:" + d[4] + "|Antecedentes:" + d[5] + "|Contacto:" + d[6];
        try {
            BitMatrix m = new QRCodeWriter().encode(data, BarcodeFormat.QR_CODE, 700, 700);
            Bitmap bm = Bitmap.createBitmap(700, 700, Bitmap.Config.RGB_565);
            for (int x = 0; x < 700; x++)
                for (int y = 0; y < 700; y++)
                    bm.setPixel(x, y, m.get(x, y) ? Color.BLACK : Color.WHITE);
            iv.setImageBitmap(bm);
        } catch (Exception e) {
            sub.setText(tr("No se pudo generar QR: ") + e.getMessage());
        }
    }
}
