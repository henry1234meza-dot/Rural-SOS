package com.example.ruralsos;

import android.app.*;
import android.content.*;
import android.os.*;
import android.text.InputType;
import android.widget.*;
import android.net.Uri;
import android.view.ViewOutlineProvider;
import android.graphics.Outline;
import android.view.View;

public class PerfilUsuarioActivity extends ActividadBase {
    private SharedPreferences sp;
    private DatabaseHelper db;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.pantalla_perfil_usuario);
        sp = getSharedPreferences("data", 0);
        db = new DatabaseHelper(this);
        refresh();
        ImageView profileImage = findViewById(R.id.imgProfile);
        profileImage.setOutlineProvider(new ViewOutlineProvider() {
            @Override public void getOutline(View view, Outline outline) {
                outline.setOval(0, 0, view.getWidth(), view.getHeight());
            }
        });
        profileImage.setClipToOutline(true);
        loadProfilePhoto();

        findViewById(R.id.btnBack).setOnClickListener(v -> finish());
        findViewById(R.id.btnSettings).setOnClickListener(v -> go(ConfiguracionActivity.class));
        findViewById(R.id.btnPersonal).setOnClickListener(v -> editProfile());
        findViewById(R.id.btnEditTop).setOnClickListener(v -> editProfile());
        findViewById(R.id.imgProfile).setOnClickListener(v -> chooseProfilePhoto());
        findViewById(R.id.btnContactsProfile).setOnClickListener(v -> go(ContactosEmergenciaActivity.class));
        findViewById(R.id.btnMedicalProfile).setOnClickListener(v -> go(DatosMedicosActivity.class));
        findViewById(R.id.btnSecurityProfile).setOnClickListener(v -> panel("Seguridad", "Tus datos se guardan localmente en el teléfono. RuralSOS no necesita una cuenta en la nube para las funciones de emergencia."));
        findViewById(R.id.btnPermissionsProfile).setOnClickListener(v -> panel("Permisos", "RuralSOS utiliza ubicación para GPS, SMS para alertas y contactos solo cuando decides importarlos."));
        findViewById(R.id.btnConfig).setOnClickListener(v -> go(ConfiguracionActivity.class));
        findViewById(R.id.btnNotif).setOnClickListener(v -> panel("Notificaciones SOS", "✅ Alertas SOS activas\n✅ Vibración y sonido\n✅ Envío de ubicación\n✅ Contactos guardados para modo offline"));
        findViewById(R.id.btnLanguage).setOnClickListener(v -> selectLanguage());
        findViewById(R.id.btnAbout).setOnClickListener(v -> panel("Acerca de RuralSOS", "RuralSOS v1 está orientado a comunidades rurales: SOS, GPS, centros de salud, contactos, quechua cajamarquino y modo offline."));
        findViewById(R.id.btnLogout).setOnClickListener(v -> {
            sp.edit().remove("user").apply();
            go(InicioSesionActivity.class);
            finish();
        });
        findViewById(R.id.navHome).setOnClickListener(v -> go(PrincipalActivity.class));
        findViewById(R.id.navEmergency).setOnClickListener(v -> go(EmergenciaActivity.class));
        findViewById(R.id.navHistory).setOnClickListener(v -> go(HistorialActivity.class));
        findViewById(R.id.navProfile).setOnClickListener(v -> toast("Ya estás en perfil"));
    }

    private void chooseProfilePhoto(){ Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT); i.addCategory(Intent.CATEGORY_OPENABLE); i.setType("image/*"); startActivityForResult(i,501); }
    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){ super.onActivityResult(requestCode,resultCode,data); if(requestCode==501 && resultCode==RESULT_OK && data!=null && data.getData()!=null){ Uri uri=data.getData(); try{getContentResolver().takePersistableUriPermission(uri,Intent.FLAG_GRANT_READ_URI_PERMISSION);}catch(Exception ignored){} sp.edit().putString("profile_photo",uri.toString()).apply(); loadProfilePhoto(); }}
    private void loadProfilePhoto(){ String raw=sp.getString("profile_photo",""); if(!raw.isEmpty()){ try{((ImageView)findViewById(R.id.imgProfile)).setImageURI(Uri.parse(raw));}catch(Exception ignored){} } }

    private void refresh() {
        ((TextView) findViewById(R.id.txtName)).setText(sp.getString("name", sp.getString("user", "admin")));
        ((TextView) findViewById(R.id.txtPhone)).setText("📞 " + sp.getString("phone", "987654321"));
        ((TextView) findViewById(R.id.txtEmail)).setText(sp.getString("address", "Porcón Bajo - Cajamarca"));
        TextView lang = findViewById(R.id.txtLanguageValue);
        lang.setText(sp.getString("language", "Quechua Cajamarca"));
        applyLanguage();
    }

    private void panel(String title, String message) {
        new AlertDialog.Builder(this).setTitle(tr(title)).setMessage(tr(message)).setPositiveButton(tr("Entendido"), null).show();
    }

    private void selectLanguage() {
        String[] langs = {"Quechua Cajamarca", "Español", "English"};
        new AlertDialog.Builder(this)
                .setTitle(tr("Seleccionar idioma"))
                .setSingleChoiceItems(langs, indexOf(langs, sp.getString("language", "Quechua Cajamarca")), (d, which) -> {
                    sp.edit().putString("language", langs[which]).apply();
                    d.dismiss();
                    refresh();
                    if (langs[which].contains("Quechua")) {
                        panel("Quechua Cajamarca activado", "Idioma Quechua Cajamarca activado en las pantallas principales.\n\nYanapay = Ayuda\nUtqaylla = Rápido\nHampina wasi = Centro de salud\nÑuqaq kasqay = Mi ubicación");
                    } else {
                        toast("Idioma actualizado: " + langs[which]);
                    }
                    recreate();
                }).show();
    }

    private int indexOf(String[] array, String value) {
        for (int i = 0; i < array.length; i++) if (array[i].equals(value)) return i;
        return 0;
    }

    private void editProfile() {
        ScrollView scroll = new ScrollView(this);
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(22), dp(8), dp(22), dp(8));
        scroll.addView(box);

        TextView note = new TextView(this);
        note.setText(tr("Completa los campos obligatorios para que tu alerta SOS tenga información útil."));
        note.setTextSize(14);
        note.setPadding(0, 0, 0, dp(10));
        box.addView(note);

        EditText name = input("Nombres y apellidos *", sp.getString("name", sp.getString("user", "admin")), InputType.TYPE_CLASS_TEXT);
        EditText dni = input("DNI *", sp.getString("dni", ""), InputType.TYPE_CLASS_NUMBER);
        EditText birth = input("Fecha de nacimiento *", sp.getString("birth", ""), InputType.TYPE_CLASS_TEXT);
        EditText phone = input("Celular *", sp.getString("phone", "987654321"), InputType.TYPE_CLASS_PHONE);
        EditText email = input("Correo electrónico *", sp.getString("email", "admin@gmail.com"), InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS);
        EditText address = input("Dirección / comunidad *", sp.getString("address", ""), InputType.TYPE_CLASS_TEXT);
        EditText blood = input("Grupo sanguíneo *", sp.getString("blood", ""), InputType.TYPE_CLASS_TEXT);
        EditText allergy = input("Alergias / enfermedades *", sp.getString("allergy", "Ninguna"), InputType.TYPE_CLASS_TEXT);
        EditText emergency = input("Contacto principal SOS *", sp.getString("emergencyContact", ""), InputType.TYPE_CLASS_PHONE);

        box.addView(name);
        box.addView(dni);
        box.addView(birth);
        box.addView(phone);
        box.addView(email);
        box.addView(address);
        box.addView(blood);
        box.addView(allergy);
        box.addView(emergency);

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle(tr("Editar información personal"))
                .setView(scroll)
                .setPositiveButton(tr("Guardar"), null)
                .setNegativeButton(tr("Cancelar"), null)
                .create();

        dialog.setOnShowListener(d -> dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
            String correo = email.getText().toString().trim();
            String celular = phone.getText().toString().trim();
            if (name.getText().toString().trim().isEmpty()) {
                name.setError(tr("Obligatorio"));
                return;
            }
            if (dni.getText().toString().trim().length() != 8) {
                dni.setError(tr("DNI de 8 dígitos"));
                return;
            }
            if (birth.getText().toString().trim().isEmpty()) {
                birth.setError(tr("Obligatorio"));
                return;
            }
            if (celular.length() < 9) {
                phone.setError(tr("Celular inválido"));
                return;
            }
            if (!correo.contains("@") || !correo.contains(".")) {
                email.setError(tr("Correo incorrecto"));
                toast("Correo incorrecto");
                return;
            }
            if (address.getText().toString().trim().isEmpty()) {
                address.setError(tr("Obligatorio"));
                return;
            }
            if (blood.getText().toString().trim().isEmpty()) {
                blood.setError(tr("Obligatorio"));
                return;
            }
            if (allergy.getText().toString().trim().isEmpty()) {
                allergy.setError(tr("Obligatorio"));
                return;
            }
            if (emergency.getText().toString().trim().length() < 9) {
                emergency.setError(tr("Contacto inválido"));
                return;
            }

            String correoActual = sp.getString("email", correo);
            db.actualizarUsuario(correoActual,
                    name.getText().toString().trim(),
                    dni.getText().toString().trim(),
                    birth.getText().toString().trim(),
                    correo,
                    celular,
                    address.getText().toString().trim(),
                    blood.getText().toString().trim(),
                    allergy.getText().toString().trim(),
                    emergency.getText().toString().trim());

            sp.edit()
                    .putString("name", name.getText().toString().trim())
                    .putString("user", name.getText().toString().trim())
                    .putString("dni", dni.getText().toString().trim())
                    .putString("birth", birth.getText().toString().trim())
                    .putString("phone", celular)
                    .putString("email", correo)
                    .putString("address", address.getText().toString().trim())
                    .putString("blood", blood.getText().toString().trim())
                    .putString("allergy", allergy.getText().toString().trim())
                    .putString("emergencyContact", emergency.getText().toString().trim())
                    .apply();
            refresh();
            toast("Perfil actualizado en SQLite");
            dialog.dismiss();
        }));
        dialog.show();
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
    }

    private EditText input(String hint, String value, int type) {
        EditText e = new EditText(this);
        e.setHint(hint);
        e.setText(value);
        e.setSingleLine(true);
        e.setInputType(type);
        e.setTextSize(16);
        e.setPadding(dp(12), dp(8), dp(12), dp(8));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(58));
        lp.setMargins(0, 0, 0, dp(10));
        e.setLayoutParams(lp);
        e.setBackgroundResource(R.drawable.input_profile_pro);
        return e;
    }
}
