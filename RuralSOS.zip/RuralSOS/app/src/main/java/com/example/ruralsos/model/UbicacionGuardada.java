package com.example.ruralsos.model;

public class UbicacionGuardada {
    public int id, usuarioId;
    public String nombre, latitud, longitud, descripcion, fecha;
}
