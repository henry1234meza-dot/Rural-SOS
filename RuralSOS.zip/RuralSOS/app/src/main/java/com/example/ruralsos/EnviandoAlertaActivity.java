package com.example.ruralsos;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationManager;
import android.location.LocationListener;
import android.os.*;
import android.telephony.SmsManager;
import android.media.ToneGenerator;
import android.media.AudioManager;
import android.os.Vibrator;
import android.widget.*;

import java.text.*;
import java.util.*;

public class EnviandoAlertaActivity extends ActividadBase {
    DatabaseHelper db;
    Handler handler = new Handler();
    boolean cancelled = false;
    private static final int REQ_SOS_PERMISSIONS = 310;

    Runnable sendTask = () -> {
        if (cancelled) return;
        obtenerUbicacionActualYEnviar();
    };

    protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.pantalla_enviando_alerta);
        db = new DatabaseHelper(this);

        Button cancel = findViewById(R.id.btnCancel);
        cancel.setOnClickListener(v -> {
            cancelled = true;
            handler.removeCallbacks(sendTask);
            toast("Alerta SOS cancelada");
            go(PrincipalActivity.class);
            finish();
        });

        verificarPermisosYEnviar();
    }

    private void verificarPermisosYEnviar() {
        if (Build.VERSION.SDK_INT >= 23) {
            ArrayList<String> permisos = new ArrayList<>();
            if (checkSelfPermission(Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
                permisos.add(Manifest.permission.SEND_SMS);
            }
            if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                permisos.add(Manifest.permission.ACCESS_FINE_LOCATION);
            }
            if (!permisos.isEmpty()) {
                requestPermissions(permisos.toArray(new String[0]), REQ_SOS_PERMISSIONS);
                return;
            }
        }
        handler.postDelayed(() -> obtenerUbicacionActualYEnviar(), 500);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_SOS_PERMISSIONS) {
            boolean smsOk = true;
            for (int i = 0; i < permissions.length; i++) {
                if (Manifest.permission.SEND_SMS.equals(permissions[i]) && grantResults[i] != PackageManager.PERMISSION_GRANTED) {
                    smsOk = false;
                }
            }
            if (!smsOk) {
                guardarHistorial("No enviada", "Permiso SMS denegado. No se pudo enviar la alerta.", "", "");
                toast("Activa el permiso SMS para enviar alertas a tus contactos");
                go(PrincipalActivity.class);
                finish();
            } else {
                handler.postDelayed(() -> obtenerUbicacionActualYEnviar(), 400);
            }
        }
    }

    private void obtenerUbicacionActualYEnviar() {
        final boolean[] enviado = {false};
        try {
            if (Build.VERSION.SDK_INT >= 23 && checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                enviarAlertaSOS("", ""); return;
            }
            LocationManager lm = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
            if (lm == null) { enviarAlertaSOS("", ""); return; }
            LocationListener listener = new LocationListener() {
                @Override public void onLocationChanged(Location l) {
                    if (enviado[0] || l == null) return; enviado[0] = true;
                    try { lm.removeUpdates(this); } catch (Exception ignored) {}
                    enviarAlertaSOS(String.valueOf(l.getLatitude()), String.valueOf(l.getLongitude()));
                }
                @Override public void onProviderEnabled(String p) {}
                @Override public void onProviderDisabled(String p) {}
                @Override public void onStatusChanged(String p, int s, Bundle e) {}
            };
            boolean requested=false;
            if (lm.isProviderEnabled(LocationManager.GPS_PROVIDER)) { lm.requestLocationUpdates(LocationManager.GPS_PROVIDER,0,0,listener); requested=true; }
            if (lm.isProviderEnabled(LocationManager.NETWORK_PROVIDER)) { lm.requestLocationUpdates(LocationManager.NETWORK_PROVIDER,0,0,listener); requested=true; }
            if (!requested) { enviarAlertaSOS("", ""); return; }
            handler.postDelayed(() -> {
                if (!enviado[0]) { enviado[0]=true; try { lm.removeUpdates(listener); } catch(Exception ignored) {}
                    String[] u=obtenerUltimaUbicacion(); enviarAlertaSOS(u[0],u[1]); }
            }, 4500);
        } catch (Exception e) { enviarAlertaSOS("", ""); }
    }

    private void enviarAlertaSOS(String latActual, String lonActual) {
        String lat = latActual == null ? "" : latActual;
        String lon = lonActual == null ? "" : lonActual;
        String fecha = new SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault()).format(new Date());

        ArrayList<String[]> contactos = db.listarContactos();
        if (contactos.isEmpty()) {
            guardarHistorial(fecha, "Alerta SOS generada, pero no hay contactos registrados.", lat, lon);
            toast("No hay contactos SOS registrados");
            go(AlertaEnviadaActivity.class);
            finish();
            return;
        }

        android.content.SharedPreferences sp = getSharedPreferences("data", 0);
        String correo = sp.getString("email", "");
        String[] med = db.obtenerDatosMedicos(correo);
        String nombre = med != null ? med[0] : sp.getString("name", "Usuario RuralSOS");
        String dni = med != null ? med[1] : sp.getString("dni", "");
        String sangre = med != null ? med[2] : sp.getString("blood", "No registrado");
        String alergia = med != null ? med[3] : sp.getString("allergy", "NO");
        String medicamentos = med != null ? med[4] : sp.getString("medicines", "Ninguno");
        String antecedentes = med != null ? med[5] : sp.getString("conditions", "Ninguno");
        if (!lat.isEmpty() && !lon.isEmpty()) db.guardarUltimaUbicacion(correo, lat, lon);
        else { String[] ultima=db.obtenerUltimaUbicacionGuardada(correo); lat=ultima[0]; lon=ultima[1]; }
        String coord = (!lat.isEmpty() && !lon.isEmpty()) ? lat + "," + lon : "No disponible";
        String mapa = (!lat.isEmpty() && !lon.isEmpty()) ? "https://maps.google.com/?q=" + lat + "," + lon : "No disponible";
        String alergiaTexto = (alergia == null || alergia.trim().isEmpty() || alergia.equalsIgnoreCase("NO") || alergia.equalsIgnoreCase("Ninguna")) ? "NO" : "SI - " + alergia;
        // Todo lo crítico viaja dentro del SMS: no hace falta internet para leerlo.
        String mensajeHumano = "SOS RURALSOS - NECESITO AYUDA\n" +
                "Nombre: " + nombre + "\n" +
                "DNI: " + dni + "\n" +
                "Sangre: " + sangre + "\n" +
                "Alergia: " + alergiaTexto + "\n" +
                "Medicamentos: " + medicamentos + "\n" +
                "Antecedentes: " + antecedentes + "\n" +
                "UBICACION: " + mapa + "\n" +
                "GPS: " + coord;
        // La alerta se firma offline con HMAC-SHA256. Otra RuralSOS con el mismo código puede validarla.
        String mensaje = CriticalAlertProtocol.buildSignedMessage(this, mensajeHumano);

        long historialId = db.guardarAlertaSOS(db.obtenerUsuarioIdPorCorreo(correo), fecha, lat, lon, "", mensaje, "PROCESANDO");
        int enviados = SosUtils.enviarATodos(this, db, mensaje, historialId);
        if(enviados==0) db.guardarSosPendiente(mensaje,lat,lon);

        String resumen = enviados > 0
                ? "Alerta SOS enviada por SMS a " + enviados + " contacto(s)."
                : "No se pudo enviar SMS. Revisa permiso, saldo o señal móvil.";

        // Un envío SOS debe generar UNA sola fila en el historial.
        // La fila creada como PROCESANDO se actualiza al resultado final,
        // en lugar de insertar una segunda fila ENVIADA.
        String estadoFinal = enviados > 0 ? "ENVIADA" : "FALLIDA";
        String mensajeHistorial = resumen + "\n\n" + mensajeHumano;
        db.actualizarAlertaSOS(historialId, mensajeHistorial, estadoFinal, lat, lon);

        // El teléfono EMISOR no enciende la linterna. La confirmación es sonora/visual.
        getSharedPreferences("data", 0).edit().putString("last_alert", fecha + " - " + resumen).apply();
        confirmacionSonora();
        toast(enviados > 0 ? "Alerta enviada" : resumen);
        go(AlertaEnviadaActivity.class);
        finish();
    }

    private String[] obtenerUltimaUbicacion() {
        String[] res = {"", ""};
        try {
            if (Build.VERSION.SDK_INT >= 23 && checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                return res;
            }
            LocationManager lm = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
            Location loc = null;
            if (lm != null) {
                if (lm.isProviderEnabled(LocationManager.GPS_PROVIDER)) loc = lm.getLastKnownLocation(LocationManager.GPS_PROVIDER);
                if (loc == null && lm.isProviderEnabled(LocationManager.NETWORK_PROVIDER)) loc = lm.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);
            }
            if (loc != null) {
                res[0] = String.valueOf(loc.getLatitude());
                res[1] = String.valueOf(loc.getLongitude());
            }
        } catch (Exception ignored) { }
        return res;
    }

    private void guardarHistorial(String fecha, String mensaje, String lat, String lon) {
        if (db == null) db = new DatabaseHelper(this);
        db.guardarAlertaSOS(fecha, lat, lon, mensaje);
    }


    private void confirmacionSonora() {
        try {
            ToneGenerator tone = new ToneGenerator(AudioManager.STREAM_NOTIFICATION, 90);
            tone.startTone(ToneGenerator.TONE_PROP_ACK, 500);
            new Handler().postDelayed(tone::release, 700);
            Vibrator vib = (Vibrator) getSystemService(VIBRATOR_SERVICE);
            if (vib != null) {
                if (Build.VERSION.SDK_INT >= 26) vib.vibrate(android.os.VibrationEffect.createOneShot(450, android.os.VibrationEffect.DEFAULT_AMPLITUDE));
                else vib.vibrate(450);
            }
        } catch (Exception ignored) {}
    }

    protected void onDestroy() {
        super.onDestroy();
        handler.removeCallbacks(sendTask);
    }
}
