package com.example.ruralsos;

import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.*;
import android.text.method.LinkMovementMethod;
import android.view.*;
import android.widget.*;
import java.util.*;

public class HistorialActivity extends ActividadBase {
    DatabaseHelper db;
    LinearLayout contenedor;
    ArrayList<String[]> historial = new ArrayList<>();
    Set<Integer> abiertos = new HashSet<>();

    protected void onCreate(Bundle b) {
        super.onCreate(b); setContentView(R.layout.pantalla_historial); db=new DatabaseHelper(this);
        contenedor=findViewById(R.id.historyContainer); mostrarHistorial();
        findViewById(R.id.btnBack).setOnClickListener(v->finish());
        findViewById(R.id.navHome).setOnClickListener(v->go(PrincipalActivity.class));
        findViewById(R.id.navEmergency).setOnClickListener(v->go(EmergenciaActivity.class));
        findViewById(R.id.navHistory).setOnClickListener(v->toast("Ya estás en historial"));
        findViewById(R.id.navProfile).setOnClickListener(v->go(PerfilUsuarioActivity.class));
        View limpiar = findViewById(R.id.btnLimpiarHistorial);
        if (limpiar != null) limpiar.setVisibility(View.GONE);
    }
    int dp(int n){return (int)(n*getResources().getDisplayMetrics().density+.5f);}
    GradientDrawable bg(int color,int stroke){GradientDrawable g=new GradientDrawable();g.setColor(color);g.setCornerRadius(dp(18));g.setStroke(dp(1),stroke);return g;}
    TextView tv(String t,int size){TextView x=new TextView(this);x.setText(tr(t));x.setTextSize(size);x.setTextColor(Color.rgb(30,42,39));x.setPadding(dp(4),dp(3),dp(4),dp(3));return x;}
    private void mostrarHistorial(){historial=db.listarHistorialSOS(); render();}
    private void render(){
        contenedor.removeAllViews();
        if(historial.isEmpty()){TextView e=tv("🕘 Sin alertas recientes\n📍 RuralSOS listo para emergencia",15);e.setPadding(dp(16),dp(18),dp(16),dp(18));contenedor.addView(e);return;}
        for(int i=0;i<historial.size();i++) agregarTarjeta(i,historial.get(i));
    }
    private void agregarTarjeta(final int pos,String[] h){
        LinearLayout card=new LinearLayout(this);card.setOrientation(LinearLayout.VERTICAL);card.setPadding(dp(14),dp(10),dp(10),dp(12));card.setBackground(bg(Color.WHITE,Color.rgb(216,232,225)));card.setElevation(dp(2));
        LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,-2);cp.setMargins(0,0,0,dp(10));contenedor.addView(card,cp);
        LinearLayout head=new LinearLayout(this);head.setGravity(Gravity.CENTER_VERTICAL);card.addView(head,new LinearLayout.LayoutParams(-1,-2));
        String estado=h[4]==null?"":h[4]; TextView title=tv("🕘 "+h[0]+"   •   "+estado,14);title.setTypeface(null,Typeface.BOLD);head.addView(title,new LinearLayout.LayoutParams(0,-2,1));
        Button plus=new Button(this);plus.setText(abiertos.contains(pos)?"−":"+");plus.setTextSize(22);plus.setTextColor(Color.WHITE);plus.setMinWidth(0);plus.setMinHeight(0);plus.setPadding(0,0,0,0);plus.setBackground(bg(Color.rgb(10,151,104),Color.rgb(10,151,104)));head.addView(plus,new LinearLayout.LayoutParams(dp(42),dp(42)));
        String lat=h[2]==null?"":h[2], lon=h[3]==null?"":h[3];
        String resumen=(lat.isEmpty()?"📍 Ubicación pendiente":"📍 Ubicación registrada")+"\nAlerta SOS";
        TextView body=tv(resumen,14);card.addView(body);
        if(abiertos.contains(pos)){
            String msg=h[1]==null?"Alerta SOS":h[1];
            TextView det=tv("\n"+msg,14);det.setAutoLinkMask(android.text.util.Linkify.WEB_URLS);det.setMovementMethod(LinkMovementMethod.getInstance());card.addView(det);
            if(!lat.isEmpty()&&!lon.isEmpty()){
                TextView map=tv("\n📍 Abrir ubicación en Google Maps",14);map.setTextColor(Color.rgb(0,112,76));map.setTypeface(null,Typeface.BOLD);map.setOnClickListener(v->mapsLatLng(Double.parseDouble(lat),Double.parseDouble(lon),"Ubicación SOS"));card.addView(map);
            }
        }
        plus.setOnClickListener(v->{if(abiertos.contains(pos))abiertos.remove(pos);else abiertos.add(pos);render();});
    }
}
