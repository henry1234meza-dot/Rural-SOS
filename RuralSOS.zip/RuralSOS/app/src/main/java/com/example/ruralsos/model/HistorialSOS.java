package com.example.ruralsos.model;

public class HistorialSOS {
    public int id, usuarioId;
    public String fecha, hora, latitud, longitud, direccion, mensaje, estado;
}
