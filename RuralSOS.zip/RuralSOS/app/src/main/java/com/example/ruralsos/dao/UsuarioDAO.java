package com.example.ruralsos.dao;

import android.content.Context;
import com.example.ruralsos.DatabaseHelper;

public class UsuarioDAO {
    private final DatabaseHelper db;
    public UsuarioDAO(Context context) { db = new DatabaseHelper(context); }
    public boolean existe(String correo) { return db.usuarioExiste(correo); }
    public int obtenerId(String correo) { return db.obtenerUsuarioIdPorCorreo(correo); }
}
