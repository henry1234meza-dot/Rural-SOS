package com.example.ruralsos.quality;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Locale;
import java.util.regex.Pattern;

/** Reglas puras y comprobables usadas por las pruebas de calidad de RuralSOS. */
public final class QualityUtils {
    private static final Pattern EMAIL = Pattern.compile("^[A-Z0-9._%+-]+@[A-Z0-9.-]+\\.[A-Z]{2,}$", Pattern.CASE_INSENSITIVE);
    private QualityUtils() {}

    public static boolean dniValido(String dni) { return dni != null && dni.matches("\\d{8}"); }
    public static boolean correoValido(String correo) { return correo != null && EMAIL.matcher(correo.trim()).matches(); }
    public static boolean passwordValido(String password) { return password != null && password.length() >= 6; }
    public static boolean passwordsCoinciden(String a, String b) { return a != null && a.equals(b); }
    public static boolean telefonoValido(String telefono) { return telefono != null && telefono.replaceAll("[ +()-]", "").matches("\\d{9,15}"); }
    public static String normalizarCorreo(String correo) { return correo == null ? "" : correo.trim().toLowerCase(Locale.ROOT); }
    public static boolean coordenadasValidas(double lat, double lon) { return lat >= -90 && lat <= 90 && lon >= -180 && lon <= 180; }
    public static String enlaceMaps(double lat, double lon) { return "https://maps.google.com/?q=" + lat + "," + lon; }
    public static boolean estadoSosValido(String estado) {
        return "PENDIENTE".equals(estado) || "ENVIANDO".equals(estado) || "ENVIADA".equals(estado) || "FALLIDO".equals(estado) || "RECIBIDA".equals(estado);
    }
    public static String hashPassword(String password) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] bytes = digest.digest(("RuralSOS_V1_" + password).getBytes(StandardCharsets.UTF_8));
            StringBuilder sb = new StringBuilder();
            for (byte b : bytes) sb.append(String.format("%02x", b));
            return sb.toString();
        } catch (Exception e) { throw new IllegalStateException(e); }
    }
}
