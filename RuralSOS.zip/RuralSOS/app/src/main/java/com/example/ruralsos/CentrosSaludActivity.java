package com.example.ruralsos;

import android.Manifest;
import android.os.*;
import android.widget.*;
import android.view.*;
import android.webkit.*;
import android.text.*;

import java.util.*;

import android.net.*;
import android.content.pm.PackageManager;
import android.graphics.Typeface;
import android.location.*;

import androidx.core.app.ActivityCompat;

public class CentrosSaludActivity extends ActividadBase implements LocationListener {
    LinearLayout list;
    EditText search;
    WebView map;
    TextView offline, titleNearby, txtMapStatus;
    double lat = -7.1526, lng = -78.5124;
    LocationManager lm;
    String currentQuery = "";
    static final double CAJAMARCA_LAT = -7.1617;
    static final double CAJAMARCA_LNG = -78.5128;
    ArrayList<Center> centers = new ArrayList<>();

    static class Center {
        String name, address, state, query, phone, type;
        double clat, clng;

        Center(String n, String a, String s, String q, String p, String t, double la, double ln) {
            name = n;
            address = a;
            state = s;
            query = q;
            phone = p;
            type = t;
            clat = la;
            clng = ln;
        }
    }

    protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.pantalla_centros_salud);

        // ActividadBase local offline actualizada para Cajamarca (zona urbana y rural).
        // Se reordena automáticamente por distancia usando tu GPS. Si el emulador da una ubicación lejana,
        // la app usa el centro de Cajamarca como referencia para no mostrar resultados equivocados.
        centers.add(new Center("Hospital Regional Docente Cajamarca", "Jr. Larry Jhonson 800, Cajamarca", "24 horas", "Hospital Regional Docente Cajamarca", "076599040", "Hospital", -7.1710, -78.5006));
        centers.add(new Center("Hospital II Cajamarca - EsSalud", "Av. Mario Urteaga s/n, Cajamarca", "24 horas", "Hospital II Cajamarca EsSalud Avenida Mario Urteaga", "076362557", "Hospital", -7.1540, -78.5180));
        centers.add(new Center("Hospital Simón Bolívar", "Av. Mario Urteaga 500, Cajamarca", "24 horas", "Hospital Simón Bolívar Cajamarca", "976488520", "Hospital", -7.1531, -78.5176));
        centers.add(new Center("Centro de Salud Magna Vallejo", "Magna Vallejo, Cajamarca", "Atención primaria", "Centro de Salud Magna Vallejo Cajamarca", "105", "Centro", -7.1604, -78.5088));
        centers.add(new Center("Centro de Salud Pachacútec", "Pachacútec, Cajamarca", "Atención primaria", "Centro de Salud Pachacutec Cajamarca", "105", "Centro", -7.1642, -78.5205));
        centers.add(new Center("Centro de Salud Micaela Bastidas", "Micaela Bastidas, Cajamarca", "Atención primaria", "Centro de Salud Micaela Bastidas Cajamarca", "105", "Centro", -7.1495, -78.5094));
        centers.add(new Center("Centro de Salud La Tulpuna", "La Tulpuna, Cajamarca", "Atención primaria", "Centro de Salud La Tulpuna Cajamarca", "105", "Centro", -7.1458, -78.5241));
        centers.add(new Center("Puesto de Salud San Martín", "Jr. San Martín, Cajamarca", "Atención primaria", "Puesto de Salud San Martín Cajamarca", "105", "Posta", -7.1566, -78.5164));
        centers.add(new Center("Clínica Limatambo Cajamarca SAC", "Jr. Puno 265, Cajamarca", "24 horas", "Clínica Limatambo Cajamarca Jr Puno 265", "076364241", "Clínica", -7.1571, -78.5169));
        centers.add(new Center("Clínica San Francisco de Asís", "Jr. Miguel Grau 851, Cajamarca", "7:00 a. m. a 10:00 p. m.", "Clínica San Francisco de Asís Cajamarca", "076362050", "Clínica", -7.1582, -78.5160));
        centers.add(new Center("Clínica Belén", "Garcilazo de la Vega 401, Cajamarca", "24 horas", "Clínica Belén Garcilazo de la Vega Cajamarca", "076432184", "Clínica", -7.1612, -78.5133));
        centers.add(new Center("Clínica San Lorenzo SRL", "Av. San Martín de Porres 546, Cajamarca", "8:00 a. m. a 8:00 p. m.", "Clínica San Lorenzo Cajamarca Avenida San Martín de Porres", "076340201", "Clínica", -7.1685, -78.5076));
        centers.add(new Center("Centro de Salud Baños del Inca", "Baños del Inca, Cajamarca", "Atención diaria", "Centro de Salud Baños del Inca Cajamarca", "105", "Centro", -7.1630, -78.4639));
        centers.add(new Center("Puesto de Salud Otuzco", "Otuzco, Baños del Inca", "Atención primaria", "Puesto de Salud Otuzco Baños del Inca Cajamarca", "105", "Posta", -7.1618, -78.4523));
        centers.add(new Center("Centro de Salud Llacanora", "Llacanora, Cajamarca", "Atención primaria", "Centro de Salud Llacanora Cajamarca", "105", "Centro", -7.1931, -78.4250));
        centers.add(new Center("Centro de Salud Jesús", "Jesús, Cajamarca", "Atención primaria", "Centro de Salud Jesús Cajamarca", "105", "Centro", -7.2488, -78.3820));
        centers.add(new Center("Centro de Salud Namora", "Namora, Cajamarca", "Atención primaria", "Centro de Salud Namora Cajamarca", "105", "Centro", -7.2047, -78.3242));
        centers.add(new Center("Centro de Salud Matara", "Matara, Cajamarca", "Atención primaria", "Centro de Salud Matara Cajamarca", "105", "Centro", -7.2562, -78.2631));
        centers.add(new Center("Centro de Salud La Encañada", "La Encañada, Cajamarca", "Atención primaria", "Centro de Salud La Encañada Cajamarca", "105", "Centro", -7.0834, -78.3405));
        centers.add(new Center("Centro de Salud Chetilla", "Chetilla, Cajamarca", "Atención primaria", "Centro de Salud Chetilla Cajamarca", "105", "Centro", -7.1468, -78.6722));
        centers.add(new Center("Centro de Salud Magdalena", "Magdalena, Cajamarca", "Atención primaria", "Centro de Salud Magdalena Cajamarca", "105", "Centro", -7.2505, -78.6560));
        centers.add(new Center("Centro de Salud San Juan", "San Juan, Cajamarca", "Atención primaria", "Centro de Salud San Juan Cajamarca", "105", "Centro", -7.2923, -78.4970));
        centers.add(new Center("Centro de Salud Asunción", "Asunción, Cajamarca", "Atención primaria", "Centro de Salud Asunción Cajamarca", "105", "Centro", -7.3250, -78.5182));
        centers.add(new Center("Centro de Salud Cospán", "Cospán, Cajamarca", "Atención primaria rural", "Centro de Salud Cospán Cajamarca", "105", "Centro", -7.4267, -78.5428));

        lm = (LocationManager) getSystemService(LOCATION_SERVICE);
        Location l = getBestLastLocation();
        if (l != null) {
            lat = l.getLatitude();
            lng = l.getLongitude();
        }
        if (outsideCajamarca(lat, lng)) {
            lat = CAJAMARCA_LAT;
            lng = CAJAMARCA_LNG;
        }

        list = findViewById(R.id.centersList);
        search = findViewById(R.id.searchHealth);
        map = findViewById(R.id.mapWeb);
        offline = findViewById(R.id.offlineMap);
        titleNearby = findViewById(R.id.titleNearby);
        txtMapStatus = findViewById(R.id.txtMapStatus);

        findViewById(R.id.btnBack).setOnClickListener(v -> finish());
        findViewById(R.id.btnOpenMaps).setOnClickListener(v -> maps(searchTextForMaps()));
        findViewById(R.id.btnRefreshGps).setOnClickListener(v -> {
            toast("Actualizando ubicación GPS...");
            requestGps();
            loadMap();
            render(currentQuery);
        });
        findViewById(R.id.navHome).setOnClickListener(v -> go(PrincipalActivity.class));
        findViewById(R.id.navEmergency).setOnClickListener(v -> go(EmergenciaActivity.class));
        findViewById(R.id.navHistory).setOnClickListener(v -> go(HistorialActivity.class));
        findViewById(R.id.navProfile).setOnClickListener(v -> go(PerfilUsuarioActivity.class));

        setupMap();
        render("");
        requestGps();

        search.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence s, int st, int c, int a) {
            }

            public void onTextChanged(CharSequence s, int st, int before, int count) {
                currentQuery = s.toString();
                render(currentQuery);
            }

            public void afterTextChanged(Editable e) {
            }
        });
    }

    private boolean outsideCajamarca(double lat, double lng) {
        return false;
    }

    void requestGps() {
        if (Build.VERSION.SDK_INT >= 23 && (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED)) {
            requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION}, 88);
            return;
        }
        startGps();
    }

    public void onRequestPermissionsResult(int r, String[] p, int[] g) {
        super.onRequestPermissionsResult(r, p, g);
        if (r == 88 && g.length > 0 && g[0] == PackageManager.PERMISSION_GRANTED) startGps();
        else toast("Permite GPS para ordenar centros cercanos en tiempo real.");
    }

    void startGps() {
        try {
            Location best = getBestLastLocation();
            if (best != null) {
                lat = best.getLatitude();
                lng = best.getLongitude();
            }
            if (outsideCajamarca(lat, lng)) {
                lat = CAJAMARCA_LAT;
                lng = CAJAMARCA_LNG;
                toast("GPS fuera de Cajamarca. Usando Cajamarca como referencia.");
            }
            if (lm.isProviderEnabled(LocationManager.GPS_PROVIDER))
                if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                    // TODO: Consider calling
                    //    ActivityCompat#requestPermissions
                    // here to request the missing permissions, and then overriding
                    //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
                    //                                          int[] grantResults)
                    // to handle the case where the user grants the permission. See the documentation
                    // for ActivityCompat#requestPermissions for more details.
                    return;
                }lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 2000, 1, this);
            if (lm.isProviderEnabled(LocationManager.NETWORK_PROVIDER))
                lm.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 2000, 1, this);
            render(currentQuery);
            // El mapa no se recarga automáticamente con cada lectura GPS.
        } catch (Exception e) {
            toast("Activa GPS para ver cercanos reales.");
        }
    }

    public void onLocationChanged(Location l) {
        double newLat = l.getLatitude();
        double newLng = l.getLongitude();
        if (!outsideCajamarca(newLat, newLng)) {
            lat = newLat;
            lng = newLng;
        }
        render(currentQuery);
        // Solo actualizamos distancias/listado; mantener el WebView evita parpadeos.
    }

    public void onProviderEnabled(String p) {
        startGps();
    }

    public void onProviderDisabled(String p) {
        toast("Activa ubicación/GPS para ordenar por cercanía.");
    }

    public void onStatusChanged(String p, int s, Bundle e) {
    }

    void setupMap() {
        WebSettings ws = map.getSettings();
        ws.setJavaScriptEnabled(true);
        ws.setDomStorageEnabled(true);
        ws.setLoadWithOverviewMode(true);
        ws.setUseWideViewPort(true);
        ws.setBuiltInZoomControls(false);
        ws.setDisplayZoomControls(false);
        map.setWebViewClient(new WebViewClient() {
            public void onPageFinished(WebView v, String url) {
                showOnline();
            }

            public void onReceivedError(WebView v, WebResourceRequest r, WebResourceError e) {
                showOffline();
            }
        });
        loadMap();
    }

    String searchTextForMaps() {
        String q = currentQuery.trim();
        if (q.length() < 2) q = "hospitales postas clinicas centros de salud";
        return q + " Cajamarca Perú cerca de " + lat + "," + lng;
    }

    void showOffline() {
        offline.setVisibility(View.VISIBLE);
        map.setVisibility(View.GONE);
    }

    void showOnline() {
        offline.setVisibility(View.GONE);
        map.setVisibility(View.VISIBLE);
    }

    void loadMap() {
        if (txtMapStatus != null) txtMapStatus.setText(String.format(java.util.Locale.US, "● %.5f, %.5f", lat, lng));
        if (!online()) {
            offline.setText(tr(String.format(java.util.Locale.US, "📍 Tu ubicación GPS\n%.6f, %.6f\n\nEl mapa visual se mostrará cuando exista Internet.", lat, lng)));
            showOffline();
            return;
        }
        showOnline();
        // Mapa rectangular estable. Solo se recarga al entrar o cuando el usuario pulsa actualizar.
        double dLat = 0.018, dLng = 0.025;
        String bbox = (lng-dLng) + "," + (lat-dLat) + "," + (lng+dLng) + "," + (lat+dLat);
        String src = "https://www.openstreetmap.org/export/embed.html?bbox=" + Uri.encode(bbox) +
                "&layer=mapnik&marker=" + lat + "%2C" + lng;
        String html = "<html><head><meta name='viewport' content='width=device-width,initial-scale=1.0'></head>" +
                "<body style='margin:0;padding:0;overflow:hidden;background:#eefaf5'>" +
                "<iframe width='100%' height='100%' frameborder='0' src='" + src + "'></iframe></body></html>";
        map.loadDataWithBaseURL("https://www.openstreetmap.org", html, "text/html", "UTF-8", null);
    }

    void render(String q) {
        list.removeAllViews();
        String query = q.toLowerCase().trim();
        ArrayList<Center> filtered = new ArrayList<>();
        for (Center c : centers) {
            String text = (c.name + " " + c.address + " " + c.query + " " + c.type).toLowerCase();
            if (query.length() > 0 && !text.contains(query)) continue;
            filtered.add(c);
        }
        Collections.sort(filtered, (a, b) -> Double.compare(distKm(a), distKm(b)));
        titleNearby.setText(tr("Centros guardados • ordenados por cercanía"));
        for (Center c : filtered) addCenter(c);
        addGoogleSearchCard();
        if (filtered.size() == 0) {
            TextView empty = new TextView(this);
            empty.setText(tr("No se encontró en la lista local. Pulsa 'Buscar en Google Maps' para ver resultados reales cercanos."));
            empty.setTextColor(getResources().getColor(R.color.muted));
            empty.setTextSize(15);
            empty.setGravity(Gravity.CENTER);
            empty.setPadding(22, 30, 22, 30);
            empty.setBackgroundResource(R.drawable.card_white);
            list.addView(empty, new LinearLayout.LayoutParams(-1, -2));
        }
    }

    void addCenter(Center c) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(20, 20, 20, 20);
        card.setBackgroundResource(R.drawable.bg_card_clean);
        card.setElevation(3);
        card.setClickable(true);

        TextView title = new TextView(this);
        title.setText(iconFor(c.type) + "  " + c.name);
        title.setTextSize(19);
        title.setTextColor(getResources().getColor(R.color.text_dark));
        title.setTypeface(null, Typeface.BOLD);

        TextView sub = new TextView(this);
        sub.setText(tr(String.format(java.util.Locale.US, "%s\n📍 A %.1f km aprox.  •  %s\n☎ %s", c.address, distKm(c), c.state, c.phone)));
        sub.setTextSize(15);
        sub.setTextColor(getResources().getColor(R.color.muted));
        sub.setPadding(0, 8, 0, 18);

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER);
        TextView call = actionIcon("☎", "LLAMAR");
        TextView route = actionIcon("⌖", "VER");
        TextView share = actionIcon("➤", "ENVIAR");
        call.setTextColor(getResources().getColor(R.color.white));
        call.setBackgroundResource(R.drawable.bg_green_button);
        row.addView(call);
        row.addView(route);
        row.addView(share);

        card.addView(title);
        card.addView(sub);
        card.addView(row);

        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(0, 0, 0, 16);
        list.addView(card, lp);

        card.setOnClickListener(v -> maps(c.query));
        route.setOnClickListener(v -> maps(c.query + " desde " + lat + "," + lng));
        call.setOnClickListener(v -> dial(c.phone));
        share.setOnClickListener(v -> share("🏥 " + c.name + "\n" + c.address + "\nDistancia aprox: " + String.format(java.util.Locale.US, "%.1f km", distKm(c)) + "\nEstado: " + c.state + "\nMi ubicación: https://maps.google.com/?q=" + lat + "," + lng));
    }

    /** Calcula la distancia en kilómetros entre la ubicación actual y el centro.
     *  Funciona completamente offline usando las coordenadas GPS.
     */
    double distKm(Center c) {
        if (c == null) return Double.MAX_VALUE;
        float[] result = new float[1];
        Location.distanceBetween(lat, lng, c.clat, c.clng, result);
        return result[0] / 1000.0;
    }

    String iconFor(String type) {
        if (type.equalsIgnoreCase("Hospital")) return "🏥";
        if (type.equalsIgnoreCase("Clínica")) return "⚕️";
        if (type.equalsIgnoreCase("Posta")) return "🚑";
        return "🏥";
    }

    TextView actionIcon(String emoji, String label) {
        TextView button = new TextView(this);
        button.setText(emoji + "  " + tr(label));
        button.setTextSize(15);
        button.setTextColor(getResources().getColor(R.color.text_dark));
        button.setGravity(Gravity.CENTER);
        button.setTypeface(null, Typeface.BOLD);
        button.setBackgroundResource(R.drawable.bg_gray_button);
        button.setClickable(true);
        button.setPadding(8, 10, 8, 10);

        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(0, 58, 1);
        params.setMargins(6, 0, 6, 0);
        button.setLayoutParams(params);
        return button;
    }

    void addGoogleSearchCard() {
        TextView t = new TextView(this);
        t.setText(tr("🌐 Buscar más centros de salud de Cajamarca en Google Maps"));
        t.setGravity(Gravity.CENTER);
        t.setTextSize(15);
        t.setTypeface(null, Typeface.BOLD);
        t.setTextColor(getResources().getColor(R.color.white));
        t.setPadding(18, 20, 18, 20);
        t.setBackgroundResource(R.drawable.btn_blue);
        t.setOnClickListener(v -> maps(searchTextForMaps()));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(0, 0, 0, 18);
        list.addView(t, lp);
    }

    protected void onDestroy() {
        super.onDestroy();
        try {
            lm.removeUpdates(this);
        } catch (Exception e) {
        }
    }
}
