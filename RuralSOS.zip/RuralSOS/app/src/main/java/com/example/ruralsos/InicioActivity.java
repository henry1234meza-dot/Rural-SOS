package com.example.ruralsos;

import android.os.*;
import android.content.SharedPreferences;

public class InicioActivity extends ActividadBase {
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.pantalla_inicio);
        new Handler().postDelayed(() -> {
            SharedPreferences sp = getSharedPreferences("data", 0);
            // Sesión persistente: si ya inició sesión, no vuelve a pedir correo/clave.
            if (sp.getBoolean("logged_in", false) && !sp.getString("email", "").isEmpty()) {
                go(PrincipalActivity.class);
            } else {
                go(BienvenidaActivity.class);
            }
            finish();
        }, 650);
    }
}
