package com.example.ruralsos.model;

public class ContactoSOS {
    public int id, usuarioId;
    public String nombre, telefono, parentesco;
    public boolean esImportado;
}
