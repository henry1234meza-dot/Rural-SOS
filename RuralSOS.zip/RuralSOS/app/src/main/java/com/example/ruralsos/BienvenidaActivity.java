package com.example.ruralsos;

import android.os.*;

public class BienvenidaActivity extends ActividadBase {
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.pantalla_bienvenida);
        findViewById(R.id.btnStart).setOnClickListener(v -> {
            go(InicioSesionActivity.class);
            finish();
        });
    }
}
