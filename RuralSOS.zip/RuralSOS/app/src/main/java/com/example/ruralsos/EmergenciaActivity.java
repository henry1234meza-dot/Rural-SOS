package com.example.ruralsos;

import android.os.Bundle;

public class EmergenciaActivity extends ActividadBase {
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.pantalla_emergencia);
        // Una sola pulsación, sin deslizar ni mantener presionado.
        findViewById(R.id.btnSendAlert).setOnClickListener(v -> go(EnviandoAlertaActivity.class));
        findViewById(R.id.navHome).setOnClickListener(v -> go(PrincipalActivity.class));
        findViewById(R.id.navEmergency).setOnClickListener(v -> toast("Ya estás en SOS"));
        findViewById(R.id.navHistory).setOnClickListener(v -> go(HistorialActivity.class));
        findViewById(R.id.navProfile).setOnClickListener(v -> go(PerfilUsuarioActivity.class));
    }
}
