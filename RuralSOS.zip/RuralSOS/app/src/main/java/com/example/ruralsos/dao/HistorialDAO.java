package com.example.ruralsos.dao;

import android.content.Context;
import com.example.ruralsos.DatabaseHelper;
import java.util.ArrayList;

public class HistorialDAO {
    private final DatabaseHelper db;
    public HistorialDAO(Context context) { db = new DatabaseHelper(context); }
    public ArrayList<String[]> listar() { return db.listarHistorialSOS(); }
}
