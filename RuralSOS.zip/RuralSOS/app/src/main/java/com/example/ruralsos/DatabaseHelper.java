package com.example.ruralsos;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.security.MessageDigest;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

public class DatabaseHelper extends SQLiteOpenHelper {
    public static final String DB_NAME = "ruralsos_v1.db";
    public static final int DB_VERSION = 6;

    public DatabaseHelper(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onConfigure(SQLiteDatabase db) {
        super.onConfigure(db);
        db.setForeignKeyConstraintsEnabled(true);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        crearTablas(db);
        insertarDatosIniciales(db);
    }

    private void crearTablas(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE IF NOT EXISTS usuarios (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "nombres TEXT NOT NULL," +
                "apellidos TEXT," +
                "nombre TEXT," +
                "dni TEXT," +
                "fecha_nacimiento TEXT," +
                "correo TEXT UNIQUE NOT NULL," +
                "telefono TEXT," +
                "direccion TEXT," +
                "grupo_sanguineo TEXT," +
                "alergias TEXT," +
                "medicamentos TEXT DEFAULT 'Ninguno'," +
                "antecedentes TEXT DEFAULT 'Ninguno'," +
                "donante_organos TEXT DEFAULT 'No especificado'," +
                "contacto_emergencia TEXT," +
                "password_hash TEXT NOT NULL," +
                "password TEXT," +
                "fecha_registro TEXT DEFAULT CURRENT_TIMESTAMP," +
                "biometria_activada INTEGER DEFAULT 0," +
                "activo INTEGER DEFAULT 1" +
                ")");

        db.execSQL("CREATE TABLE IF NOT EXISTS contactos_sos (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "usuario_id INTEGER," +
                "nombre TEXT NOT NULL," +
                "telefono TEXT NOT NULL," +
                "parentesco TEXT DEFAULT 'Contacto SOS'," +
                "es_importado INTEGER DEFAULT 0," +
                "creado_en TEXT DEFAULT CURRENT_TIMESTAMP," +
                "FOREIGN KEY(usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE" +
                ")");

        db.execSQL("CREATE TABLE IF NOT EXISTS historial_sos (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "usuario_id INTEGER," +
                "fecha TEXT," +
                "hora TEXT," +
                "fecha_hora TEXT NOT NULL," +
                "latitud TEXT," +
                "longitud TEXT," +
                "direccion TEXT," +
                "mensaje TEXT NOT NULL," +
                "estado TEXT DEFAULT 'ENVIADA'," +
                "FOREIGN KEY(usuario_id) REFERENCES usuarios(id) ON DELETE SET NULL" +
                ")");

        db.execSQL("CREATE TABLE IF NOT EXISTS centros_salud (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "nombre TEXT NOT NULL," +
                "direccion TEXT," +
                "telefono TEXT," +
                "latitud TEXT," +
                "longitud TEXT," +
                "tipo TEXT DEFAULT 'Centro de salud'" +
                ")");

        db.execSQL("CREATE TABLE IF NOT EXISTS configuracion (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "usuario_id INTEGER UNIQUE," +
                "idioma TEXT DEFAULT 'Quechua Cajamarca'," +
                "tema TEXT DEFAULT 'Claro'," +
                "sonido INTEGER DEFAULT 1," +
                "vibracion INTEGER DEFAULT 1," +
                "notificaciones INTEGER DEFAULT 1," +
                "biometria_activada INTEGER DEFAULT 0," +
                "actualizado_en TEXT DEFAULT CURRENT_TIMESTAMP," +
                "FOREIGN KEY(usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE" +
                ")");

        db.execSQL("CREATE TABLE IF NOT EXISTS ubicaciones_guardadas (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "usuario_id INTEGER," +
                "nombre TEXT NOT NULL," +
                "latitud TEXT," +
                "longitud TEXT," +
                "descripcion TEXT," +
                "fecha TEXT DEFAULT CURRENT_TIMESTAMP," +
                "FOREIGN KEY(usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE" +
                ")");

        db.execSQL("CREATE TABLE IF NOT EXISTS sos_pendientes (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "mensaje TEXT NOT NULL," +
                "latitud TEXT," +
                "longitud TEXT," +
                "creado_en TEXT DEFAULT CURRENT_TIMESTAMP," +
                "intentos INTEGER DEFAULT 0" +
                ")");

        db.execSQL("CREATE TABLE IF NOT EXISTS detalle_envio_sos (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "historial_id INTEGER," +
                "contacto TEXT," +
                "telefono TEXT," +
                "estado TEXT," +
                "fecha TEXT DEFAULT CURRENT_TIMESTAMP" +
                ")");

        db.execSQL("CREATE TABLE IF NOT EXISTS alertas_criticas_recibidas (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "sos_id TEXT UNIQUE NOT NULL," +
                "origen TEXT," +
                "mensaje TEXT NOT NULL," +
                "firma_hmac TEXT," +
                "validacion TEXT," +
                "recibido_en TEXT DEFAULT CURRENT_TIMESTAMP" +
                ")");
    }

    private void migrarDesdeVersionAnterior(SQLiteDatabase db) {
        try {
            Cursor c = db.rawQuery("SELECT id,nombre,telefono,parentesco FROM contactos", null);
            while (c.moveToNext()) {
                ContentValues v = new ContentValues();
                v.put("nombre", c.getString(1));
                v.put("telefono", c.getString(2));
                v.put("parentesco", c.getString(3));
                db.insert("contactos_sos", null, v);
            }
            c.close();
        } catch (Exception ignored) { }
    }

    private void insertarDatosIniciales(SQLiteDatabase db) {
        if (contar(db, "contactos_sos") == 0) {
            insertarContactoInicial(db, "Mamá", "987654321", "Familiar");
            insertarContactoInicial(db, "Papá", "976543210", "Familiar");
            insertarContactoInicial(db, "Hermano", "912345678", "Familiar");
        }
        if (contar(db, "centros_salud") == 0) {
            insertarCentroInicial(db, "Centro de Salud Cajamarca", "Ruta cercana", "", "", "", "Centro de salud");
            insertarCentroInicial(db, "Posta Médica Rural", "Comunidad cercana", "", "", "", "Posta médica");
        }
    }

    private long contar(SQLiteDatabase db, String tabla) {
        long total = 0;
        Cursor c = db.rawQuery("SELECT COUNT(*) FROM " + tabla, null);
        if (c.moveToFirst()) total = c.getLong(0);
        c.close();
        return total;
    }

    private void insertarContactoInicial(SQLiteDatabase db, String nombre, String telefono, String parentesco) {
        ContentValues v = new ContentValues();
        v.put("nombre", nombre);
        v.put("telefono", telefono);
        v.put("parentesco", parentesco);
        db.insert("contactos_sos", null, v);
    }

    private void insertarCentroInicial(SQLiteDatabase db, String nombre, String direccion, String telefono, String lat, String lon, String tipo) {
        ContentValues v = new ContentValues();
        v.put("nombre", nombre);
        v.put("direccion", direccion);
        v.put("telefono", telefono);
        v.put("latitud", lat);
        v.put("longitud", lon);
        v.put("tipo", tipo);
        db.insert("centros_salud", null, v);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        if (oldVersion < 3) {
            try { db.execSQL("ALTER TABLE usuarios ADD COLUMN medicamentos TEXT DEFAULT 'Ninguno'"); } catch (Exception ignored) {}
            try { db.execSQL("ALTER TABLE usuarios ADD COLUMN antecedentes TEXT DEFAULT 'Ninguno'"); } catch (Exception ignored) {}
        }
        if (oldVersion < 6) {
            try { db.execSQL("ALTER TABLE usuarios ADD COLUMN donante_organos TEXT DEFAULT 'No especificado'"); } catch (Exception ignored) {}
            try { db.execSQL("UPDATE configuracion SET idioma='Quechua Cajamarca' WHERE idioma IS NULL OR idioma=''"); } catch (Exception ignored) {}
        }
        crearTablas(db);
        migrarDesdeVersionAnterior(db);
        insertarDatosIniciales(db);
    }

    private String ahora() {
        return new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(new Date());
    }

    private String soloFecha(String fechaHora) {
        if (fechaHora == null) return "";
        return fechaHora.length() >= 10 ? fechaHora.substring(0, 10) : fechaHora;
    }

    private String soloHora(String fechaHora) {
        if (fechaHora == null) return "";
        return fechaHora.length() >= 16 ? fechaHora.substring(11, 16) : "";
    }

    private String hashPassword(String password) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] bytes = digest.digest(("RuralSOS_V1_" + password).getBytes("UTF-8"));
            StringBuilder sb = new StringBuilder();
            for (byte b : bytes) sb.append(String.format("%02x", b));
            return sb.toString();
        } catch (Exception e) {
            return password;
        }
    }

    public boolean registrarUsuario(String nombre, String dni, String fechaNacimiento, String correo,
                                    String telefono, String direccion, String grupoSanguineo,
                                    String alergias, String contactoEmergencia, String password) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues v = new ContentValues();
        v.put("nombres", nombre);
        v.put("apellidos", "");
        v.put("nombre", nombre);
        v.put("dni", dni);
        v.put("fecha_nacimiento", fechaNacimiento);
        v.put("correo", correo.toLowerCase(Locale.ROOT));
        v.put("telefono", telefono);
        v.put("direccion", direccion);
        v.put("grupo_sanguineo", grupoSanguineo);
        v.put("alergias", alergias);
        v.put("contacto_emergencia", contactoEmergencia);
        v.put("password_hash", hashPassword(password));
        v.put("password", password);
        v.put("fecha_registro", ahora());
        v.put("biometria_activada", 1);
        long id = db.insert("usuarios", null, v);
        if (id == -1) return false;
        crearConfiguracionSiNoExiste((int) id, "Quechua Cajamarca");
        return true;
    }

    public boolean validarLogin(String correo, String password) {
        SQLiteDatabase db = getReadableDatabase();
        Cursor c = db.rawQuery("SELECT id FROM usuarios WHERE lower(correo)=lower(?) AND (password_hash=? OR password=?) AND activo=1 LIMIT 1",
                new String[]{correo, hashPassword(password), password});
        boolean ok = c.moveToFirst();
        c.close();
        return ok;
    }

    public boolean usuarioExiste(String correo) {
        SQLiteDatabase db = getReadableDatabase();
        Cursor c = db.rawQuery("SELECT id FROM usuarios WHERE lower(correo)=lower(?) AND activo=1 LIMIT 1", new String[]{correo});
        boolean existe = c.moveToFirst();
        c.close();
        return existe;
    }

    public int obtenerUsuarioIdPorCorreo(String correo) {
        SQLiteDatabase db = getReadableDatabase();
        Cursor c = db.rawQuery("SELECT id FROM usuarios WHERE lower(correo)=lower(?) LIMIT 1", new String[]{correo});
        int id = 0;
        if (c.moveToFirst()) id = c.getInt(0);
        c.close();
        return id;
    }

    public String[] obtenerUsuarioPorCorreo(String correo) {
        SQLiteDatabase db = getReadableDatabase();
        Cursor c = db.rawQuery("SELECT nombres,dni,fecha_nacimiento,correo,telefono,direccion,grupo_sanguineo,alergias,contacto_emergencia,password FROM usuarios WHERE lower(correo)=lower(?) LIMIT 1", new String[]{correo});
        if (!c.moveToFirst()) {
            c.close();
            return null;
        }
        String[] u = new String[10];
        for (int i = 0; i < 10; i++) u[i] = c.getString(i) == null ? "" : c.getString(i);
        c.close();
        return u;
    }

    public boolean actualizarUsuario(String correoActual, String nombre, String dni, String fechaNacimiento,
                                     String correoNuevo, String telefono, String direccion, String grupoSanguineo,
                                     String alergias, String contactoEmergencia) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues v = new ContentValues();
        v.put("nombres", nombre);
        v.put("nombre", nombre);
        v.put("dni", dni);
        v.put("fecha_nacimiento", fechaNacimiento);
        v.put("correo", correoNuevo.toLowerCase(Locale.ROOT));
        v.put("telefono", telefono);
        v.put("direccion", direccion);
        v.put("grupo_sanguineo", grupoSanguineo);
        v.put("alergias", alergias);
        v.put("contacto_emergencia", contactoEmergencia);
        return db.update("usuarios", v, "lower(correo)=lower(?)", new String[]{correoActual}) > 0;
    }

    public void actualizarDatosMedicos(String correo, String alergias, String medicamentos, String antecedentes) {
        ContentValues v = new ContentValues();
        v.put("alergias", alergias);
        v.put("medicamentos", medicamentos);
        v.put("antecedentes", antecedentes);
        getWritableDatabase().update("usuarios", v, "lower(correo)=lower(?)", new String[]{correo});
    }

    public String[] obtenerDatosMedicos(String correo) {
        Cursor c = getReadableDatabase().rawQuery("SELECT nombres,dni,grupo_sanguineo,alergias,medicamentos,antecedentes,contacto_emergencia,donante_organos FROM usuarios WHERE lower(correo)=lower(?) LIMIT 1", new String[]{correo});
        if (!c.moveToFirst()) { c.close(); return null; }
        String[] r = new String[8];
        for (int i=0;i<8;i++) r[i] = c.getString(i)==null ? "" : c.getString(i);
        c.close();
        return r;
    }

    public void actualizarDonanteOrganos(String correo, String valor) {
        ContentValues v = new ContentValues();
        v.put("donante_organos", valor == null || valor.isEmpty() ? "No especificado" : valor);
        getWritableDatabase().update("usuarios", v, "lower(correo)=lower(?)", new String[]{correo});
    }

    public void actualizarBiometria(String correo, boolean activo) {
        int usuarioId = obtenerUsuarioIdPorCorreo(correo);
        if (usuarioId == 0) return;
        ContentValues u = new ContentValues();
        u.put("biometria_activada", activo ? 1 : 0);
        getWritableDatabase().update("usuarios", u, "id=?", new String[]{String.valueOf(usuarioId)});
        ContentValues c = new ContentValues();
        c.put("biometria_activada", activo ? 1 : 0);
        c.put("actualizado_en", ahora());
        getWritableDatabase().update("configuracion", c, "usuario_id=?", new String[]{String.valueOf(usuarioId)});
    }

    public ArrayList<String[]> listarContactos() {
        ArrayList<String[]> lista = new ArrayList<>();
        SQLiteDatabase db = getReadableDatabase();
        Cursor c = db.rawQuery("SELECT id,nombre,telefono,parentesco FROM contactos_sos ORDER BY id DESC", null);
        while (c.moveToNext()) {
            lista.add(new String[]{String.valueOf(c.getInt(0)), c.getString(1), c.getString(2), c.getString(3)});
        }
        c.close();
        return lista;
    }

    public long agregarContacto(String nombre, String telefono, String parentesco) {
        return agregarContacto(nombre, telefono, parentesco, 0, 0);
    }

    public long agregarContacto(String nombre, String telefono, String parentesco, int usuarioId, int esImportado) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues v = new ContentValues();
        if (usuarioId > 0) v.put("usuario_id", usuarioId);
        v.put("nombre", nombre);
        v.put("telefono", telefono);
        v.put("parentesco", parentesco == null || parentesco.isEmpty() ? "Contacto SOS" : parentesco);
        v.put("es_importado", esImportado);
        return db.insert("contactos_sos", null, v);
    }

    public boolean actualizarContacto(int id, String nombre, String telefono) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues v = new ContentValues();
        v.put("nombre", nombre);
        v.put("telefono", telefono);
        return db.update("contactos_sos", v, "id=?", new String[]{String.valueOf(id)}) > 0;
    }

    public boolean eliminarContacto(int id) {
        SQLiteDatabase db = getWritableDatabase();
        return db.delete("contactos_sos", "id=?", new String[]{String.valueOf(id)}) > 0;
    }

    public long guardarAlertaSOS(String fechaHora, String latitud, String longitud, String mensaje) {
        return guardarAlertaSOS(0, fechaHora, latitud, longitud, "", mensaje, "ENVIADA");
    }

    public long guardarAlertaSOS(int usuarioId, String fechaHora, String latitud, String longitud, String direccion, String mensaje, String estado) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues v = new ContentValues();
        if (usuarioId > 0) v.put("usuario_id", usuarioId);
        v.put("fecha", soloFecha(fechaHora));
        v.put("hora", soloHora(fechaHora));
        v.put("fecha_hora", fechaHora);
        v.put("latitud", latitud);
        v.put("longitud", longitud);
        v.put("direccion", direccion);
        v.put("mensaje", mensaje);
        v.put("estado", estado == null || estado.isEmpty() ? "ENVIADA" : estado);
        return db.insert("historial_sos", null, v);
    }

    public boolean actualizarAlertaSOS(long historialId, String mensaje, String estado, String latitud, String longitud) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues v = new ContentValues();
        if (mensaje != null) v.put("mensaje", mensaje);
        if (estado != null && !estado.isEmpty()) v.put("estado", estado);
        if (latitud != null) v.put("latitud", latitud);
        if (longitud != null) v.put("longitud", longitud);
        return db.update("historial_sos", v, "id=?", new String[]{String.valueOf(historialId)}) > 0;
    }

    public ArrayList<String[]> listarHistorialSOS() {
        ArrayList<String[]> lista = new ArrayList<>();
        SQLiteDatabase db = getReadableDatabase();
        Cursor c = db.rawQuery("SELECT fecha_hora,mensaje,latitud,longitud,estado FROM historial_sos ORDER BY id DESC", null);
        while (c.moveToNext()) {
            lista.add(new String[]{c.getString(0), c.getString(1), c.getString(2), c.getString(3), c.getString(4)});
        }
        c.close();
        return lista;
    }

    public void limpiarHistorialSOS() {
        getWritableDatabase().delete("historial_sos", null, null);
    }

    public ArrayList<String[]> listarCentrosSalud() {
        ArrayList<String[]> lista = new ArrayList<>();
        Cursor c = getReadableDatabase().rawQuery("SELECT id,nombre,direccion,telefono,latitud,longitud,tipo FROM centros_salud ORDER BY nombre", null);
        while (c.moveToNext()) {
            lista.add(new String[]{String.valueOf(c.getInt(0)), c.getString(1), c.getString(2), c.getString(3), c.getString(4), c.getString(5), c.getString(6)});
        }
        c.close();
        return lista;
    }

    public long guardarUbicacion(int usuarioId, String nombre, String latitud, String longitud, String descripcion) {
        ContentValues v = new ContentValues();
        if (usuarioId > 0) v.put("usuario_id", usuarioId);
        v.put("nombre", nombre);
        v.put("latitud", latitud);
        v.put("longitud", longitud);
        v.put("descripcion", descripcion);
        v.put("fecha", ahora());
        return getWritableDatabase().insert("ubicaciones_guardadas", null, v);
    }

    public ArrayList<String[]> listarUbicacionesGuardadas(int usuarioId) {
        ArrayList<String[]> lista = new ArrayList<>();
        Cursor c;
        if (usuarioId > 0) {
            c = getReadableDatabase().rawQuery("SELECT id,nombre,latitud,longitud,descripcion,fecha FROM ubicaciones_guardadas WHERE usuario_id=? ORDER BY id DESC", new String[]{String.valueOf(usuarioId)});
        } else {
            c = getReadableDatabase().rawQuery("SELECT id,nombre,latitud,longitud,descripcion,fecha FROM ubicaciones_guardadas ORDER BY id DESC", null);
        }
        while (c.moveToNext()) {
            lista.add(new String[]{String.valueOf(c.getInt(0)), c.getString(1), c.getString(2), c.getString(3), c.getString(4), c.getString(5)});
        }
        c.close();
        return lista;
    }

    public long guardarSosPendiente(String mensaje, String lat, String lon) {
        ContentValues v = new ContentValues();
        v.put("mensaje", mensaje); v.put("latitud", lat); v.put("longitud", lon);
        return getWritableDatabase().insert("sos_pendientes", null, v);
    }

    public ArrayList<String[]> listarSosPendientes() {
        ArrayList<String[]> r = new ArrayList<>();
        Cursor c = getReadableDatabase().rawQuery("SELECT id,mensaje,latitud,longitud,intentos FROM sos_pendientes ORDER BY id", null);
        while(c.moveToNext()) r.add(new String[]{String.valueOf(c.getInt(0)),c.getString(1),c.getString(2),c.getString(3),String.valueOf(c.getInt(4))});
        c.close(); return r;
    }

    public void marcarIntentoPendiente(int id) { getWritableDatabase().execSQL("UPDATE sos_pendientes SET intentos=intentos+1 WHERE id=?", new Object[]{id}); }
    public void eliminarSosPendiente(int id) { getWritableDatabase().delete("sos_pendientes","id=?",new String[]{String.valueOf(id)}); }

    public long guardarDetalleEnvio(long historialId, String contacto, String telefono, String estado) {
        ContentValues v=new ContentValues(); v.put("historial_id",historialId); v.put("contacto",contacto); v.put("telefono",telefono); v.put("estado",estado);
        return getWritableDatabase().insert("detalle_envio_sos",null,v);
    }

    public void guardarUltimaUbicacion(String correo, String lat, String lon) {
        int uid=obtenerUsuarioIdPorCorreo(correo);
        guardarUbicacion(uid,"ULTIMA_GPS",lat,lon,"Última ubicación conocida");
    }

    public String[] obtenerUltimaUbicacionGuardada(String correo) {
        int uid=obtenerUsuarioIdPorCorreo(correo);
        Cursor c=getReadableDatabase().rawQuery(uid>0 ? "SELECT latitud,longitud FROM ubicaciones_guardadas WHERE usuario_id=? AND nombre='ULTIMA_GPS' ORDER BY id DESC LIMIT 1" : "SELECT latitud,longitud FROM ubicaciones_guardadas WHERE nombre='ULTIMA_GPS' ORDER BY id DESC LIMIT 1", uid>0?new String[]{String.valueOf(uid)}:null);
        String[] r={"",""}; if(c.moveToFirst()){r[0]=c.getString(0);r[1]=c.getString(1);} c.close(); return r;
    }

    public void crearConfiguracionSiNoExiste(int usuarioId, String idioma) {
        if (usuarioId <= 0) return;
        SQLiteDatabase db = getWritableDatabase();
        Cursor c = db.rawQuery("SELECT id FROM configuracion WHERE usuario_id=? LIMIT 1", new String[]{String.valueOf(usuarioId)});
        boolean existe = c.moveToFirst();
        c.close();
        if (!existe) {
            ContentValues v = new ContentValues();
            v.put("usuario_id", usuarioId);
            v.put("idioma", idioma == null || idioma.isEmpty() ? "Quechua Cajamarca" : idioma);
            db.insert("configuracion", null, v);
        }
    }

    public void guardarIdioma(String correo, String idioma) {
        int usuarioId = obtenerUsuarioIdPorCorreo(correo == null ? "" : correo);
        if (usuarioId <= 0) return;
        crearConfiguracionSiNoExiste(usuarioId, idioma);
        ContentValues v = new ContentValues();
        v.put("idioma", idioma);
        v.put("actualizado_en", ahora());
        getWritableDatabase().update("configuracion", v, "usuario_id=?", new String[]{String.valueOf(usuarioId)});
    }

    public String obtenerIdioma(String correo) {
        int usuarioId = obtenerUsuarioIdPorCorreo(correo == null ? "" : correo);
        if (usuarioId <= 0) return "Quechua Cajamarca";
        Cursor c = getReadableDatabase().rawQuery("SELECT idioma FROM configuracion WHERE usuario_id=? LIMIT 1", new String[]{String.valueOf(usuarioId)});
        String idioma = "Quechua Cajamarca";
        if (c.moveToFirst() && c.getString(0) != null) idioma = c.getString(0);
        c.close();
        return idioma;
    }
    public boolean alertaCriticaYaProcesada(String sosId) {
        Cursor c = getReadableDatabase().rawQuery("SELECT id FROM alertas_criticas_recibidas WHERE sos_id=? LIMIT 1", new String[]{sosId});
        boolean existe = c.moveToFirst(); c.close(); return existe;
    }

    public long guardarAlertaCriticaRecibida(String sosId, String origen, String mensaje, String firma, String validacion) {
        ContentValues v = new ContentValues();
        v.put("sos_id", sosId); v.put("origen", origen); v.put("mensaje", mensaje);
        v.put("firma_hmac", firma); v.put("validacion", validacion);
        return getWritableDatabase().insert("alertas_criticas_recibidas", null, v);
    }

}
