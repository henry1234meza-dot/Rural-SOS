package com.example.ruralsos;

import android.app.AlertDialog;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Button;
import android.view.View;
import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Build;
import java.util.ArrayList;

public class PrincipalActivity extends ActividadBase {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.pantalla_principal);
        new Thread(() -> SosRetryManager.reintentar(this)).start();

        String user = getSharedPreferences("data", 0).getString("user", "admin");
        TextView txtWelcome = findViewById(R.id.txtWelcome);
        txtWelcome.setText(tr("Hola, ") + user);

        setupMainButtons();
        setupBottomNavigation();
        setupTopBar();
        setupEmergencyConfiguration();
        ensureCriticalReceiverPermissions();
    }

    private void setupEmergencyConfiguration() {
        android.content.SharedPreferences sp = getSharedPreferences("data", 0);
        String email = sp.getString("email", "").toLowerCase();
        boolean accepted = sp.getBoolean("consent_" + email, false);
        View card = findViewById(R.id.cardEmergencySetup);
        card.setVisibility(accepted ? View.GONE : View.VISIBLE);
        findViewById(R.id.btnSetupNow).setOnClickListener(v -> go(ConsentimientoActivity.class));
        findViewById(R.id.btnSetupLater).setOnClickListener(v -> card.setVisibility(View.GONE));
    }

    private void setupMainButtons() {
        // Botón SOS principal: al hacer clic abre la pantalla de emergencia.
        findViewById(R.id.btnSOS).setOnClickListener(v -> go(EnviandoAlertaActivity.class));
        findViewById(R.id.btnLocation).setOnClickListener(v -> go(UbicacionActivity.class));
        findViewById(R.id.btnContacts).setOnClickListener(v -> go(ContactosEmergenciaActivity.class));
        findViewById(R.id.btnHealth).setOnClickListener(v -> go(CentrosSaludActivity.class));
        findViewById(R.id.btnMedicalData).setOnClickListener(v -> go(DatosMedicosActivity.class));
        findViewById(R.id.btnGuide).setOnClickListener(v -> go(OrientacionActivity.class));
        if(getSharedPreferences("data",0).getBoolean("easy_mode",false)){
            Button sos=findViewById(R.id.btnSOS); sos.setText(tr("🆘\nAYUDA")); sos.setTextSize(42);
            ((Button)findViewById(R.id.btnLocation)).setText(tr("📍\nUBICACIÓN"));
            ((Button)findViewById(R.id.btnContacts)).setText(tr("📞\nCONTACTOS"));
            ((Button)findViewById(R.id.btnHealth)).setText(tr("🏥\nSALUD"));
            ((Button)findViewById(R.id.btnGuide)).setText(tr("❤️\nAUXILIOS"));
        }
    }

    private void setupBottomNavigation() {
        findViewById(R.id.navHome).setOnClickListener(v -> toast("Ya estás en inicio"));
        findViewById(R.id.navEmergency).setOnClickListener(v -> go(EmergenciaActivity.class));
        findViewById(R.id.navHistory).setOnClickListener(v -> go(HistorialActivity.class));
        findViewById(R.id.btnProfile).setOnClickListener(v -> go(PerfilUsuarioActivity.class));
    }

    private void setupTopBar() {
        findViewById(R.id.btnMenu).setOnClickListener(v -> openSmartMenu());
        findViewById(R.id.btnNotify).setOnClickListener(v -> showNotifications());
    }

    private void openSmartMenu() {
        String[] opciones = {
                tr("🚨 Activar SOS"),
                tr("📍 Mi ubicación GPS"),
                tr("🏥 Centros de salud cercanos"),
                tr("📘 Primeros auxilios"),
                tr("🌐 Idioma / Quechua"),
                tr("⚙️ Configuración"),
                tr("🚪 Cerrar sesión")
        };

        new AlertDialog.Builder(this)
                .setTitle(tr("RuralSOS v1"))
                .setItems(opciones, (dialog, which) -> {
                    switch (which) {
                        case 0:
                            go(EnviandoAlertaActivity.class);
                            break;
                        case 1:
                            go(UbicacionActivity.class);
                            break;
                        case 2:
                            go(CentrosSaludActivity.class);
                            break;
                        case 3:
                            go(OrientacionActivity.class);
                            break;
                        case 4:
                        case 5:
                            go(ConfiguracionActivity.class);
                            break;
                        case 6:
                            getSharedPreferences("data", 0).edit().putBoolean("logged_in", false).remove("user").apply();
                            go(InicioSesionActivity.class);
                            finish();
                            break;
                    }
                })
                .setNegativeButton(tr("Cerrar"), null)
                .show();
    }

    private void showNotifications() {
        new AlertDialog.Builder(this)
                .setTitle(tr("Notificaciones RuralSOS v1"))
                .setMessage(tr("✅ GPS listo\n\n✅ Modo offline activo\n\n✅ Quechua disponible\n\nNo tienes alertas nuevas."))
                .setPositiveButton(tr("Entendido"), null)
                .show();
    }
    /**
     * En instalaciones existentes la app podía tener SEND_SMS pero no RECEIVE_SMS.
     * Eso hacía que el SMS llegara a Mensajes, pero RuralSOS no pudiera activar
     * sonido/linterna. Se solicita una sola vez por versión cuando falta un permiso.
     */
    private void ensureCriticalReceiverPermissions() {
        if (Build.VERSION.SDK_INT < 23) return;
        android.content.SharedPreferences sp = getSharedPreferences("data", 0);
        if (!sp.getBoolean("critical_mode", true)) return;
        ArrayList<String> missing = new ArrayList<>();
        if (checkSelfPermission(Manifest.permission.RECEIVE_SMS) != PackageManager.PERMISSION_GRANTED)
            missing.add(Manifest.permission.RECEIVE_SMS);
        if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED)
            missing.add(Manifest.permission.CAMERA);
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            missing.add(Manifest.permission.POST_NOTIFICATIONS);
        if (!missing.isEmpty() && !sp.getBoolean("critical_permissions_prompted_v6", false)) {
            sp.edit().putBoolean("critical_permissions_prompted_v6", true).apply();
            requestPermissions(missing.toArray(new String[0]), 906);
        }
    }


}

