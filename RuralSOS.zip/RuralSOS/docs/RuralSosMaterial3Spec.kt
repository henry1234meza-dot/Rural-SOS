package com.example.ruralsos.ui

/**
 * Especificación de migración visual solicitada por el profesor.
 * La app productiva sigue usando Java/XML mientras se migra de forma incremental.
 * Objetivo: Jetpack Compose + Material Design 3 conservando la identidad cromática RuralSOS.
 */
object RuralSosMaterial3Spec {
    const val DESIGN_SYSTEM = "Material Design 3"
    const val UI_TOOLKIT = "Jetpack Compose"
    const val STRATEGY = "Migración incremental sin reemplazar la lógica offline existente"
}
