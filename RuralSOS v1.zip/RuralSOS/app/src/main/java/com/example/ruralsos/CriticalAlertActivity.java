package com.example.ruralsos;

import android.os.Bundle;
import android.widget.TextView;
import android.text.util.Linkify;
import android.text.method.LinkMovementMethod;

public class CriticalAlertActivity extends ActividadBase {
    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.pantalla_alerta_critica);
        String id=getIntent().getStringExtra("id_sos");
        String origin=getIntent().getStringExtra("origin");
        String msg=getIntent().getStringExtra("message");
        ((TextView)findViewById(R.id.txtCriticalId)).setText(tr("🛡️ Firma HMAC válida") + " · " + (id==null?"SOS":id));
        ((TextView)findViewById(R.id.txtCriticalOrigin)).setText(tr("📱 Origen:") + " " + (origin==null?tr("No disponible"):origin));
        TextView criticalMessage=(TextView)findViewById(R.id.txtCriticalMessage);
        criticalMessage.setText(msg==null?"Alerta RuralSOS":msg);
        Linkify.addLinks(criticalMessage, Linkify.WEB_URLS);
        criticalMessage.setMovementMethod(LinkMovementMethod.getInstance());
        findViewById(R.id.btnCriticalClose).setOnClickListener(v->finish());
        findViewById(R.id.btnCriticalHome).setOnClickListener(v->{go(PrincipalActivity.class);finish();});
    }
}
