package com.example.ruralsos;

import android.Manifest;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Build;

import androidx.core.app.NotificationCompat;
import androidx.work.BackoffPolicy;
import androidx.work.ExistingWorkPolicy;
import androidx.work.OneTimeWorkRequest;
import androidx.work.WorkManager;

import java.util.concurrent.TimeUnit;

public class SosRetryManager {
    private static final String UNIQUE_WORK = "ruralsos_sos_pending_retry";

    /**
     * Reintenta todos los SOS almacenados en SQLite.
     * synchronized evita dos reintentos simultáneos desde Activity/Worker.
     */
    public static synchronized int reintentar(Context ctx) {
        if (Build.VERSION.SDK_INT >= 23
                && ctx.checkSelfPermission(Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
            return 0;
        }

        DatabaseHelper db = new DatabaseHelper(ctx);
        int enviados = 0;

        // Si todavía no volvió la cobertura celular, dejamos intacta la cola.
        if (!SosUtils.hayServicioMovil(ctx)) {
            return 0;
        }

        for (String[] p : db.listarSosPendientes()) {
            int id = Integer.parseInt(p[0]);
            db.marcarIntentoPendiente(id);

            long h = db.guardarAlertaSOS(
                    0,
                    new java.text.SimpleDateFormat("dd/MM/yyyy HH:mm", java.util.Locale.getDefault())
                            .format(new java.util.Date()),
                    p[2], p[3], "", p[1], "REINTENTO"
            );

            int ok = SosUtils.enviarATodos(ctx, db, p[1], h);
            if (ok > 0) {
                db.eliminarSosPendiente(id);
                enviados += ok;
            }
        }

        if (enviados > 0) {
            notificarEnvioAutomatico(ctx, enviados);
        }
        return enviados;
    }

    public static boolean hayPendientes(Context ctx) {
        try {
            return !new DatabaseHelper(ctx).listarSosPendientes().isEmpty();
        } catch (Exception e) {
            return false;
        }
    }

    /**
     * Deja una tarea persistente en Android. Si no hay señal, WorkManager
     * vuelve a intentar con backoff incluso si RuralSOS queda en segundo plano.
     */
    public static void programarReintento(Context ctx) {
        OneTimeWorkRequest work = new OneTimeWorkRequest.Builder(SosRetryWorker.class)
                .setBackoffCriteria(BackoffPolicy.LINEAR, 10, TimeUnit.SECONDS)
                .build();

        WorkManager.getInstance(ctx.getApplicationContext())
                .enqueueUniqueWork(UNIQUE_WORK, ExistingWorkPolicy.REPLACE, work);
    }

    /**
     * Cuando detectamos que volvió una red/señal, lanzamos un intento inmediato.
     */
    public static void reintentarAhoraAsync(Context ctx) {
        Context app = ctx.getApplicationContext();
        new Thread(() -> {
            int enviados = reintentar(app);
            if (enviados == 0 && hayPendientes(app)) {
                programarReintento(app);
            }
        }).start();
    }

    private static void notificarEnvioAutomatico(Context ctx, int enviados) {
        try {
            if (Build.VERSION.SDK_INT >= 33
                    && ctx.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                return;
            }

            NotificationManager nm =
                    (NotificationManager) ctx.getSystemService(Context.NOTIFICATION_SERVICE);
            if (nm == null) return;

            String channel = "ruralsos_retry";
            if (Build.VERSION.SDK_INT >= 26) {
                NotificationChannel nc = new NotificationChannel(
                        channel,
                        "Reenvío automático SOS",
                        NotificationManager.IMPORTANCE_HIGH
                );
                nm.createNotificationChannel(nc);
            }

            NotificationCompat.Builder b = new NotificationCompat.Builder(ctx, channel)
                    .setSmallIcon(android.R.drawable.ic_dialog_info)
                    .setContentTitle("RuralSOS")
                    .setContentText("SOS pendiente enviado automáticamente a " + enviados + " contacto(s).")
                    .setPriority(NotificationCompat.PRIORITY_HIGH)
                    .setAutoCancel(true);

            nm.notify(1818, b.build());
        } catch (Exception ignored) {}
    }
}
