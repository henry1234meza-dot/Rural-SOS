package com.example.ruralsos;

import android.app.*;
import android.content.*;
import android.graphics.text.LineBreaker;
import android.location.*;
import android.graphics.Rect;
import android.net.*;
import android.os.*;
import android.view.*;
import android.widget.*;
import java.util.*;

public class ActividadBase extends Activity {
    // Conserva el texto base (en español) de cada vista durante la vida de la Activity.
    // Esto evita que al cambiar Quechua -> Español -> English se vuelva a traducir
    // sobre un texto ya traducido y queden frases mezcladas.
    private final Map<TextView,String> sourceTextByView = new WeakHashMap<>();
    private final Map<TextView,String> renderedTextByView = new WeakHashMap<>();
    private final Map<EditText,String> sourceHintByView = new WeakHashMap<>();
    private final Map<EditText,String> renderedHintByView = new WeakHashMap<>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prepararTecladoVisible();
        if (Build.VERSION.SDK_INT >= 21) {
            getWindow().setStatusBarColor(android.graphics.Color.parseColor("#087A34"));
            getWindow().setNavigationBarColor(android.graphics.Color.parseColor("#F4FFFB"));
        }
    }



    void prepararTecladoVisible() {
        try {
            getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
        } catch (Exception ignored) {}
    }

    void activarCamposSobreTeclado() {
        try {
            View root = getWindow().getDecorView().getRootView();
            configurarScrolls(root);
            configurarEditTexts(root);
            observarTeclado(root);
        } catch (Exception ignored) {}
    }

    void configurarScrolls(View v) {
        if (v == null) return;
        if (v instanceof ScrollView) {
            ScrollView sv = (ScrollView) v;
            sv.setFillViewport(false);
            sv.setClipToPadding(false);
            int minBottom = dp(240);
            if (sv.getPaddingBottom() < minBottom) {
                sv.setPadding(sv.getPaddingLeft(), sv.getPaddingTop(), sv.getPaddingRight(), minBottom);
            }
        }
        if (v instanceof ViewGroup) {
            ViewGroup g = (ViewGroup) v;
            for (int i = 0; i < g.getChildCount(); i++) configurarScrolls(g.getChildAt(i));
        }
    }

    void configurarEditTexts(View v) {
        if (v == null) return;
        if (v instanceof EditText) {
            EditText edit = (EditText) v;
            edit.setOnFocusChangeListener((view, hasFocus) -> {
                if (hasFocus) subirCampoVisible(view);
            });
            edit.setOnClickListener(view -> subirCampoVisible(view));
        }
        if (v instanceof ViewGroup) {
            ViewGroup g = (ViewGroup) v;
            for (int i = 0; i < g.getChildCount(); i++) configurarEditTexts(g.getChildAt(i));
        }
    }

    void subirCampoVisible(View campo) {
        try {
            campo.postDelayed(() -> {
                ScrollView sv = buscarScrollPadre(campo);
                if (sv == null) return;
                int[] locCampo = new int[2];
                int[] locScroll = new int[2];
                campo.getLocationOnScreen(locCampo);
                sv.getLocationOnScreen(locScroll);
                int yDentroScroll = locCampo[1] - locScroll[1] + sv.getScrollY();
                int destino = Math.max(0, yDentroScroll - dp(120));
                sv.smoothScrollTo(0, destino);
            }, 250);
        } catch (Exception ignored) {}
    }

    ScrollView buscarScrollPadre(View v) {
        ViewParent p = v.getParent();
        while (p instanceof View) {
            if (p instanceof ScrollView) return (ScrollView) p;
            p = p.getParent();
        }
        return null;
    }

    void observarTeclado(View root) {
        if (root == null) return;
        root.getViewTreeObserver().addOnGlobalLayoutListener(() -> {
            try {
                Rect r = new Rect();
                root.getWindowVisibleDisplayFrame(r);
                int altoPantalla = root.getRootView().getHeight();
                int altoTeclado = altoPantalla - r.bottom;
                View actual = getCurrentFocus();
                if (altoTeclado > altoPantalla * 0.15 && actual instanceof EditText) {
                    subirCampoVisible(actual);
                }
            } catch (Exception ignored) {}
        });
    }

    void go(Class<?> c){startActivity(new Intent(this,c));}
    void toast(String s){Toast.makeText(this, tr(s), Toast.LENGTH_SHORT).show();}
    void dial(String n){startActivity(new Intent(Intent.ACTION_DIAL, Uri.parse("tel:"+n)));}
    void maps(String q){startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q="+Uri.encode(q))));}
    void mapsLatLng(double lat,double lng,String label){startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("geo:"+lat+","+lng+"?q="+lat+","+lng+"("+Uri.encode(label)+")")));}
    void share(String msg){Intent i=new Intent(Intent.ACTION_SEND);i.setType("text/plain");i.putExtra(Intent.EXTRA_TEXT,msg);startActivity(Intent.createChooser(i,tr("Compartir")));}
    boolean online(){try{android.net.ConnectivityManager cm=(android.net.ConnectivityManager)getSystemService(CONNECTIVITY_SERVICE);android.net.NetworkInfo ni=cm.getActiveNetworkInfo();return ni!=null&&ni.isConnected();}catch(Exception e){return false;}}
    int dp(int v){return (int)(v*getResources().getDisplayMetrics().density+0.5f);} 
    String googleLink(double lat,double lng){return "https://maps.google.com/?q="+lat+","+lng;}
    Location getBestLastLocation(){try{LocationManager lm=(LocationManager)getSystemService(LOCATION_SERVICE);Location best=null;for(String p:lm.getProviders(true)){Location l=lm.getLastKnownLocation(p);if(l!=null&&(best==null||l.getAccuracy()<best.getAccuracy()||l.getTime()>best.getTime()))best=l;}return best;}catch(SecurityException se){return null;}catch(Exception e){return null;}}

    @Override public void setContentView(int layoutResID){super.setContentView(layoutResID);prepararTecladoVisible();protegerBarraInferior();applyLanguage();applyResponsive();}
    @Override public void setContentView(View view){super.setContentView(view);prepararTecladoVisible();protegerBarraInferior();applyLanguage();applyResponsive();}
    @Override public void setContentView(View view, ViewGroup.LayoutParams params){super.setContentView(view,params);prepararTecladoVisible();protegerBarraInferior();applyLanguage();applyResponsive();}

    /** Ajustes generales para pantallas angostas, fuentes grandes y diferentes densidades Android. */
    void applyResponsive(){
        try{
            View root=findViewById(android.R.id.content);
            if(root==null)return;
            int widthDp=getResources().getConfiguration().screenWidthDp;
            float fontScale=getResources().getConfiguration().fontScale;
            adaptResponsive(root,widthDp,fontScale);
        }catch(Exception ignored){}
    }

    void adaptResponsive(View v,int widthDp,float fontScale){
        if(v==null)return;
        if(v instanceof TextView){
            TextView tv=(TextView)v;
            if(Build.VERSION.SDK_INT>=23){
                try{tv.setBreakStrategy(LineBreaker.BREAK_STRATEGY_HIGH_QUALITY);tv.setHyphenationFrequency(android.text.Layout.HYPHENATION_FREQUENCY_NORMAL);}catch(Exception ignored){}
            }
            // En equipos muy angostos evita que títulos grandes corten palabras.
            if(widthDp>0 && widthDp<360){
                float sp=tv.getTextSize()/getResources().getDisplayMetrics().scaledDensity;
                if(sp>=20f) tv.setTextSize(android.util.TypedValue.COMPLEX_UNIT_SP,Math.max(16f,sp*0.92f));
            }
            // Botones de texto: con fuente ampliada pueden crecer verticalmente en vez de recortarse.
            if(v instanceof Button && fontScale>1.10f){
                ViewGroup.LayoutParams lp=v.getLayoutParams();
                if(lp!=null && lp.height>0 && lp.height<=dp(120)){
                    v.setMinimumHeight(lp.height);
                    lp.height=ViewGroup.LayoutParams.WRAP_CONTENT;
                    v.setLayoutParams(lp);
                }
            }
        }
        if(v instanceof ViewGroup){
            ViewGroup g=(ViewGroup)v;
            for(int i=0;i<g.getChildCount();i++)adaptResponsive(g.getChildAt(i),widthDp,fontScale);
        }
    }

    // Evita que Inicio / SOS / Historial / Perfil queden debajo de la barra de navegación de Android.
    void protegerBarraInferior(){
        try{
            final View content=findViewById(android.R.id.content);
            if(content==null)return;
            final int baseBottom=content.getPaddingBottom();
            content.setOnApplyWindowInsetsListener((v,insets)->{
                int bottom=0;
                if(Build.VERSION.SDK_INT>=30) bottom=insets.getInsets(WindowInsets.Type.navigationBars()).bottom;
                else bottom=insets.getSystemWindowInsetBottom();
                v.setPadding(v.getPaddingLeft(),v.getPaddingTop(),v.getPaddingRight(),baseBottom+bottom);
                return insets;
            });
            content.requestApplyInsets();
        }catch(Exception ignored){}
    }
    @Override protected void onResume(){super.onResume();applyLanguage(); new Handler(Looper.getMainLooper()).postDelayed(this::applyLanguage, 120);}

    boolean isQuechua(){return getSharedPreferences("data",0).getString("language","Quechua Cajamarca").contains("Quechua");}
    boolean isEnglish(){return getSharedPreferences("data",0).getString("language","Quechua Cajamarca").equals("English");}

    void applyLanguage(){
        try{View root=getWindow().getDecorView().getRootView();applyToView(root);}catch(Exception ignored){}
    }
    void applyToView(View v){
        if(v==null)return;
        if(v instanceof TextView){
            TextView tv=(TextView)v;
            String current=tv.getText()==null?"":tv.getText().toString();
            String source=sourceTextByView.get(tv);
            String lastRendered=renderedTextByView.get(tv);

            // Primera vez: el XML está escrito en español. Si el texto fue cambiado
            // dinámicamente antes de este pase, lo normalizamos una sola vez.
            // Si otro método cambió el texto después del último render, actualizamos
            // también su fuente canónica para no perder datos dinámicos (nombre, GPS, etc.).
            if(source==null || lastRendered==null || !current.equals(lastRendered)){
                source=translateSpanish(current);
                sourceTextByView.put(tv,source);
            }
            String out=translateFromSpanish(source);
            if(!out.equals(current)) tv.setText(out);
            renderedTextByView.put(tv,out);

            if(v instanceof EditText){
                EditText edit=(EditText)v;
                String currentHint=edit.getHint()==null?"":edit.getHint().toString();
                String sourceHint=sourceHintByView.get(edit);
                String lastHint=renderedHintByView.get(edit);
                if(sourceHint==null || lastHint==null || !currentHint.equals(lastHint)){
                    sourceHint=translateSpanish(currentHint);
                    sourceHintByView.put(edit,sourceHint);
                }
                String hintOut=translateFromSpanish(sourceHint);
                if(!hintOut.equals(currentHint)) edit.setHint(hintOut);
                renderedHintByView.put(edit,hintOut);
            }
        }
        if(v instanceof ViewGroup){ViewGroup g=(ViewGroup)v; for(int i=0;i<g.getChildCount();i++)applyToView(g.getChildAt(i));}
    }

    String translateFromSpanish(String base){
        if(base==null)return "";
        if(isQuechua())return translateQuechua(base);
        if(isEnglish())return translateEnglish(base);
        return base;
    }

    String tr(String s){
        if(s==null)return "";
        // Primero normaliza cualquier texto que haya quedado en Quechua o Inglés a Español.
        // Así cambiar de idioma varias veces nunca deja una mezcla de idiomas en pantalla.
        String base=translateSpanish(s);
        return translateFromSpanish(base);
    }

    String translateQuechua(String s){
        if(s==null)return "";
        String raw=s;
        Map<String,String> m=new HashMap<>();
        m.put("Emergencia, ubicación y ayuda rápida","Utqay yanapay, maypi kashkayki, yanapay");
        m.put("Emergencia, ubicación y ayuda rápida para comunidades rurales.","Ĉakra llaqtakunapaq utqay yanapay, maypi kashkayki, yanapay.");
        m.put("🛡️  Configura RuralSOS para emergencias","🛡️  Utqay yanapaypaq RuralSOS-ta wakichiy");
        m.put("Configura las funciones necesarias para que una alerta SOS pueda usar ubicación, contactos y notificaciones cuando corresponda.","SOS willakuy maypi kashkaykita, rimanakuykunata, willakuykunata llamkachinanpaq wakichiy.");
        m.put("📍\nMi ubicación","📍\nMaypi kashkay"); m.put("🏥\nCentros de salud","🏥\nHampina wasikuna");
        m.put("🩺  Datos médicos / Historia clínica","🩺  Hampi willakuy / hampi yuyay qillqa");
        m.put("🔊 Escuchar guía","🔊 Yachachiyta uyariy");
        m.put("←   Emergencia SOS","←   SOS utqay yanapay");
        m.put("Se enviará nombre, ubicación, URL del mapa e historia clínica por SMS.","Shutiyki, maypi kashkayki, mapa URL, hampi willakuy SMSwan kaĉachishka kanqa.");
        m.put("🩺 La historia clínica crítica se incluye automáticamente en la alerta.","🩺 Ancha allin hampi willakuy SOS willakuypi kikillan ĉurakan.");
        m.put("Guardado en el teléfono, sin Internet","Celularpi waqayĉashka, internet mana kaptinpis");
        m.put("⌕  Buscar en el historial...","⌕  Yuyay qillqapi maskay...");
        m.put("🛡 Información guardada en tu teléfono. Se incluirá en la alerta SOS para ayudar al personal de salud.","🛡 Willakuy celularniykipi waqayĉashka. Hampiqkunata yanapanapaq SOS willakuypi ĉurakanqa.");
        m.put("✓ Estos datos se envían por SMS junto con el nombre, GPS y URL de Google Maps.","✓ Kay willakuykuna shutiykiwan, GPSwan, Google Maps URLwan SMSpi kaĉakan.");
        m.put("Ingresa con tu correo y contraseña local","Correo, pakashka rimaywan yaykuy");
        m.put("  acceso local seguro  ","  kay celularpi mana manĉay yaykuy  ");
        m.put("Entrar con huella digital","Rukana yupaywan yaykuy");
        m.put("🔐  Seguridad\nHuella activada + bloqueo por intentos","🔐  Waqayĉay\nRukana yupay llamkan + pantaykunamanta wichqay");
        m.put("📴  Modo sin internet\nContactos, historial y guías locales","📴  Internet mana kaptin\nRimanakuykuna, yuyay qillqa, kay celularpi yachachiykuna");
        m.put("👵  Modo fácil\nIconos y botones grandes","👵  Mana sasa modo\nHatun iconokuna, ñitinakuna");
        m.put("🔦  Linterna SOS\nSeñal visual al activar emergencia","🔦  SOS linterna\nUtqay yanapayta hapichiptin achki señal");
        m.put("🛡️  Código HMAC\nVincular emisor y receptor sin internet","🛡️  HMAC código\nInternet mana kaptin kaĉaqta ĉaskiqwan tinkuchiy");
        m.put("🔔  Notificaciones\nSonido, vibración y alerta SOS","🔔  Willakuykuna\nUyarina, kuyuy, SOS willakuy");
        m.put("Crear cuenta RuralSOS","RuralSOS yupayta ruway");
        m.put("Datos obligatorios para activar tu perfil de emergencia","Utqay yanapay rikch'ayniykita hapichinapaq munashka willakuykuna");
        m.put("Información personal","Kikin willakuy");
        m.put("Consultar DNI","DNI-ta maskay");
        m.put("Con Internet puedes completar nombres automáticamente. Sin Internet, escríbelos manualmente.","Internet kaptin shutikuna kikillan hunt'akan. Internet mana kaptin makiykiwan qillqay.");
        m.put("Nombres *","Shutikuna *");
        m.put("Apellido paterno *","Tayta apillidu *");
        m.put("Apellido materno *","Mama apillidu *");
        m.put("Contacto y seguridad","Rimanakuy hinallataq waqaychay");
        m.put("Correo electrónico *","Correo electrónico *");
        m.put("Dirección / comunidad *","Maypi tiyanki / llaqta *");
        m.put("Datos médicos básicos","Hampi willakuykuna");
        m.put("Ingresa el nombre del contacto SOS principal","Hatun SOS rimanakuypa sutinta qillqay");
        m.put("Número del contacto principal *","Hatun SOS rimanakuypa yupaynin *");
        m.put("Nombre del contacto principal *","Hatun SOS rimanakuypa sutin *");
        m.put("Contacto principal SOS","Hatun SOS rimanakuy");
        m.put("¿Desea donar órganos? *","¿Órganokunata donayta munankichu? *");
        m.put("DNI encontrado. Nombres y apellidos completados automáticamente.","DNI tarishka. Shutikuna apillidukuna kikillan hunt'ashka.");
        m.put("Ingresa tus nombres","Shutikunata qillqay");
        m.put("Ingresa apellido paterno","Tayta apilliduta qillqay");
        m.put("Ingresa apellido materno","Mama apilliduta qillqay");
        m.put("Fecha de nacimiento *  Toca para seleccionar","Nasishka puncha *  Akllanapaq ñitiy");
        m.put("Número de celular *","Celular yupay *");
        m.put("🔐 Consentimiento y permisos","🔐 Chaskiy, permisukuna");
        m.put("RuralSOS solicitará ubicación, contactos, SMS, cámara y notificaciones para las funciones de emergencia. Android te permitirá aceptar o rechazar cada permiso.","Utqay yanapaypaq RuralSOS maypi kashkaykita, rimanakuykunata, SMS-ta, kamerata, willakuykunata mañanqa. Androidpi sapa permisuta ari utaq mana niyta puydinki.");
        m.put("Doy mi consentimiento para que RuralSOS solicite los permisos necesarios para las funciones SOS. *","RuralSOS SOS llamkanankunapaq munashka permisukunata mañananpaq ari nini. *");
        m.put("📡  Información disponible sin Internet.","📡  Internet mana kaptinpis willakuy kan.");
        m.put("Buscar centro de salud...","Hampina wasita maskay...");
        m.put("🗺️  Mapa en tiempo real","🗺️  Kunan pachapi mapa");
        m.put("● Tu ubicación","● Maypi kashkayki");
        m.put("📍 Ubicación GPS disponible\nMapa visual requiere Internet","📍 GPS maypi kashkayki kan\nMapata rikunapaq internet munakan");
        // Traducciones adicionales para que Perfil, Configuración y consentimiento no queden en español.
        // Quechua Norteño de Cajamarca (Anan Qichwa): textos visibles que antes quedaban en castellano.
        m.put("Ayuda sin internet","Internet mana kaptinpis yanapay");
        m.put("Señal móvil disponible","Celular señal kan");
        m.put("GPS activo","GPS llamkan");
        m.put("Funciona sin Internet mediante SMS","Internet mana kaptinpis SMSwan llamkan");
        m.put("Puedes enviar alertas SOS por SMS, aunque no haya Internet.","Internet mana kaptinpis SOS willakuyta SMSwan kaĉachiyta puydinki.");
        m.put("●  Señal móvil disponible\n●  GPS activo\n●  Sin Internet: SMS disponible","●  Celular señal kan\n●  GPS llamkan\n●  Internet mana kaptin: SMS kan");
        m.put("●  ▥  Señal móvil disponible\n●  ◎  GPS activo\n●  ◉  Funciona sin internet","●  ▥  Celular señal kan\n●  ◎  GPS llamkan\n●  ◉  Internet mana kaptinpis llamkan");
        m.put("¿Necesitas ayuda?","¿Yanapayta munanki?");
        m.put("Semáforo del sistema","Sistema semáforo");
        m.put("Internet: Sin conexión","Internet: mana tinkisqachu");
        m.put("Internet: Limitado","Internet: pisillam");
        m.put("Internet: Conectado","Internet: tinkisqa");
        m.put("Red móvil: Permiso pendiente","Celular red: permiso suyaykan");
        m.put("Red móvil: Sin señal","Celular red: mana señal kanchu");
        m.put("Red móvil: Con señal","Celular red: señal kan");
        m.put("Satélite: Detección no compatible","Satélite: kay celular mana qhawanchu");
        m.put("Satélite: No disponible","Satélite: mana kanchu");
        m.put("Satélite: Permiso pendiente","Satélite: permiso suyaykan");
        m.put("Satélite: No conectado","Satélite: mana tinkisqachu");
        m.put("Satélite: Conectado","Satélite: tinkisqa");
        m.put("Satélite: Verificando","Satélite: qhawachkan");
        m.put("Red móvil: Datos full","Celular red: allin datos");
        m.put("Red móvil: Datos limitados","Celular red: pisillam datos");
        m.put("Red móvil: Sin red","Celular red: mana red kanchu");
        m.put("GPS: Activo","GPS: llamkan");
        m.put("GPS: Permiso pendiente","GPS: permiso suyaykan");
        m.put("GPS: Desactivado","GPS: wañuchishka");
        m.put("Modo offline SOS: Listo","SOS offline modo: listo");
        m.put("Modo offline SOS: Faltan contactos SOS","SOS offline modo: contactos faltan");
        m.put("Modo offline SOS: Permiso SMS faltante","SOS offline modo: SMS permiso faltan");
        m.put("Verde = estable, naranja = limitado, rojo = desactivado o sin servicio.","Q'omer = allin, q'illu-anaranjado = pisi, puka = mana serviciu kanchu.");
        m.put("Presiona una vez para solicitar ayuda","Yanapay mañanapaq shuk kutilla ñitiy");
        m.put("Toca un dibujo para recibir ayuda.","Yanapay ĉaskinapaq shuk dibujuta ñitiy.");
        m.put("PRIMEROS AUXILIOS","ÑAWPAQ YANAPAY");
        m.put("RCP","RCP"); m.put("SANGRADO","YAWAR SHUĈUY"); m.put("FRACTURA","TULLU PAKIY");
        m.put("QUEMADURA","RUPHAY"); m.put("INTOXICACIÓN","MIYUY");
        m.put("ATRAGANTAMIENTO","MILLPUYPI HARKASQA"); m.put("CONVULSIÓN","KATKATAY");
        m.put("PICADURA","KANISQA"); m.put("ACCIDENTE","ACCIDENTE");
        m.put("Escuchar guía","Yachachiyta uyariy");
        m.put("QUÉ HACER:","IMA RURANA:"); m.put("QUÉ NO HACER:","IMA MANA RURANA:");
        m.put("Verifica que el lugar sea seguro.","Ĉay lugar mana manĉaypaq kaqta rikay.");
        m.put("Revisa si responde y respira.","Kutichishunĉu, samashunĉu rikay.");
        m.put("Llama a emergencias.","Utqay yanapayman qayay.");
        m.put("Mantén a la persona tranquila y abrigada.","Runata hawka, qataypa ĉuray.");
        m.put("No muevas a una persona con golpe fuerte.","Sinĉi maqasqa runata ama kuyuchiychu.");
        m.put("No des agua si está inconsciente.","Yuyaynin mana kaptin yakuta ama qoychu.");
        m.put("Centros de salud cercanos","Qaylla hampina wasikuna");
        m.put("Centros guardados • ordenados por cercanía","Waqayĉasqa hampina wasikuna • qayllaman ĉurasqa");
        m.put("Lista guardada en el teléfono","Celularpi waqayĉasqa lista");
        m.put("Historial de emergencias","Utqay yanapay yuyay qillqa");
        m.put("Limpiar historial","Yuyay qillqata pichay");
        m.put("Datos médicos básicos","Hampi willakuykuna");
        m.put("Ingresa el nombre del contacto SOS principal","Hatun SOS rimanakuypa sutinta qillqay");
        m.put("Número del contacto principal *","Hatun SOS rimanakuypa yupaynin *");
        m.put("Nombre del contacto principal *","Hatun SOS rimanakuypa sutin *");
        m.put("Contacto principal SOS","Hatun SOS rimanakuy");
        m.put("¿Desea donar órganos? *","¿Órganokunata donayta munankichu? *");
        m.put("Historia clínica de emergencia","Utqay hampi willakuy");
        m.put("Editar / completar historia clínica","Hampi willakuyta allichay / huntachiy");
        m.put("Datos de emergencia","Utqay yanapay willakuykuna");
        m.put("Donar órganos","Kurku kaqninkunata qoy");
        m.put("Sí","Ari"); m.put("No","Mana"); m.put("Más tarde","Qipaman");
        m.put("Comenzar","Qallariy"); m.put("Bienvenido","Allin shamushka");
        m.put("Crear cuenta nueva","Mushuq cuenta ruray");
        m.put("Crear cuenta RuralSOS","RuralSOS cuenta ruray");
        m.put("Nombres","Shutikuna"); m.put("Apellidos","Ayllu shutikuna");
        m.put("Nombres y apellidos *","Shutikuna, ayllu shutikuna *");
        m.put("Fecha de nacimiento","Nasishka puncha"); m.put("Fecha de nacimiento *","Nasishka puncha *");
        m.put("Dirección / comunidad *","Maypi tiyanki / comunidad *");
        m.put("Celular *","Celular *"); m.put("DNI de 8 dígitos","8 yupayniyuq DNI");
        m.put("Consultar DNI","DNI-ta maskay"); m.put("Consultando DNI...","DNI-ta maskaykan...");
        m.put("Nombres encontrados","Shutikuna tarishka");
        m.put("No se pudo consultar el DNI. Ingresa tus datos manualmente.","DNI-ta mana maskayta puydirkanchu. Willakuynikita makiwan qillqay.");
        m.put("Configuración","Wakichiy"); m.put("Opciones preparadas para uso rural, emergencia y accesibilidad.","Ĉakra llaqtakunapi, utqay yanapaypi, llapan runakunapaq wakichishka.");
        m.put("Personaliza RuralSOS v1","RuralSOS v1-ta munashkaykiman wakichiy");
        m.put("Acerca de RuralSOS","RuralSOSmanta"); m.put("Versión, términos y más","Versión, kamachikuna, aswanpis");
        m.put("Estado de permisos del sistema","Sistema permisunkunapa kaynin");
        m.put("Configurar ahora","Kunan wakichiy");
        m.put("Mi perfil","Ñuqaq rikch'ay"); m.put("Información personal","Kikin willakuy");
        m.put("Datos básicos y dirección","Suti willakuykunawan maypi tiyan"); m.put("Contactos SOS","SOS rimanakuykuna");
        m.put("Familia y contactos de emergencia","Aylluwan utqay rimanakuykuna"); m.put("Datos médicos","Hampi willakuykuna");
        m.put("Historia y condiciones de salud","Hampi willakuywan qhali kay"); m.put("Configuración","Wakichiy");
        m.put("Preferencias de la aplicación","Aplicación munasqaykikuna"); m.put("Notificaciones","Willakuykuna");
        m.put("Alertas y recordatorios","Willakuykunawan yuyachiykuna"); m.put("Idioma","Simi");
        m.put("Español / Quechua","Español / Qichwa"); m.put("Seguridad","Waqaychay");
        m.put("Bloqueo y privacidad","Wichq'aywan sapalla kay"); m.put("Permisos","Saqiykuna");
        m.put("Estado de permisos del sistema","Sistema saqiykunap kaynin"); m.put("Editar","Allichay");
        m.put("Continuar","Qatiy"); m.put("Siguiente","Qatiq"); m.put("Aceptar y continuar","Chaskiy hinaspa qatiy");
        m.put("Permisos que solicita RuralSOS","RuralSOS mañakusqan saqiykuna"); m.put("Tu consentimiento","Qampa chaskisqayki");
        m.put("Tu consentimiento ha sido registrado.","Chaskisqayki waqaychasqañam."); m.put("¡Gracias!","Sulpayki!");
        m.put("Ubicación","Maypi kasqay"); m.put("Contactos","Rimanakuykuna"); m.put("Cámara","Kamera");
        m.put("Ver política de privacidad","Sapalla kay kamachiyta rikuy"); m.put("Debes aceptar el consentimiento para continuar","Qatinaykipaq chaskiyta ari niyki tiyan");
        // Navegación principal
        m.put("Inicio","Qallariy"); m.put("SOS","SOS"); m.put("Historial","Yuyay qillqa"); m.put("Perfil","Rikch'ay");
        m.put("Mi perfil","Ñuqaq rikch'ay"); m.put("Cerrar sesión","Lloqsiy");
        m.put("Información personal","Kikin willakuy"); m.put("Configuración de cuenta","Yupay wakichiy");
        m.put("Notificaciones SOS","SOS willakuykuna"); m.put("Acerca de RuralSOS","RuralSOSmanta");
                // Inicio
        m.put("RuralSOS 5.0","RuralSOS 5.0");
        m.put("Hola, admin • ¿Qué necesitas ahora?","Imaynalla, admin • Imata munanki kunan?");
        m.put("Emergencias, ubicación, salud y familia segura.","Utqay yanapay, maypi kasqayki, hampiy hinallataq ayllu waqaychay.");
        m.put("🚨  BOTÓN SOS\nPresiona en caso de emergencia","🚨  SOS ÑIT'INA\nUtqay yanapaypaq ñit'iy");
        m.put("📍\nMi ubicación\nGPS tiempo real","📍\nMaypi kasqay\nGPS kunan pacha");
        m.put("👥\nContactos\nSOS familiar","👥\nRimanakuykuna\nAyllu SOS");
        m.put("🏥\nCentros de salud\nRuta cercana","🏥\nHampina wasikuna\nÑan aswan qaylla");
        m.put("📘\nOrientación\nPrimeros auxilios","📘\nYanapakuq yachachiy\nÑawpaq yanapay");
                m.put("🩺\nCarnet médico","🩺\nHampi qillqa");
        m.put("☎️\nNúmeros SOS","☎️\nSOS yupaykuna");
        m.put("👨‍👩‍👧\nFamilia segura","👨‍👩‍👧\nAyllu waqaychasqa");
        m.put("🌧️\nAlertas clima","🌧️\nPacha willakuy");
                // Login
        m.put("Seguridad rural inteligente","Yuyayniyuq llaqta seguridad");
        m.put("Bienvenido","Allin hamusqa");
        m.put("Ingresa con tu correo, clave o huella digital","Correo, pakasqa rimay utaq ruk'ana yupaywan yaykuy");
        m.put("Correo electrónico","Correo electrónico"); m.put("Contraseña","Pakasqa rimay");
        m.put("¿Olvidaste tu contraseña?","¿Pakasqa rimayta qunqarqankichu?");
        m.put("Ingresar seguro","Mana manchaywan yaykuy"); m.put("acceso rápido","utqay yaykuy");
        m.put("🔐  Entrar con huella","🔐  Ruk'anawan yaykuy");
        m.put("G  Continuar con Google","G  Googlewan qatipay");
        m.put("Crear cuenta nueva","Musuq yupayta ruway");
        // Registro
        m.put("Crear cuenta RuralSOS","RuralSOS yupayta ruway");
        m.put("Datos obligatorios para activar tu perfil de emergencia","Utqay yanapaypaq kikin willakuykuna hunt'ay");
        m.put("Información personal","Kikin willakuy"); m.put("Contacto y seguridad","Rimanakuy hinallataq seguridad");
        m.put("Datos médicos básicos","Sasa mana hampi willakuy");
        m.put("* Campos obligatorios. Tus datos se guardan localmente para funcionar sin internet.","* Hunt'ana willakuykuna. Willakuyniyki kay celularpi waqaychasqa kanqa mana internet kaptinpas.");
        m.put("Crear cuenta segura","Mana manchaywan yupayta ruway");
        m.put("¿Ya tienes cuenta? Inicia sesión","¿Yupayniyki kanchu? Yaykuy");
        // Ubicación y salud
        m.put("Mi ubicación","Maypi kasqay"); m.put("Tu ubicación actual","Kunan maypi kasqayki");
        m.put("Latitud: -7.1526   Longitud: -78.5124","Latitud: -7.1526   Longitud: -78.5124");
        m.put("📍 Cajamarca, Perú","📍 Cajamarca, Perú");
        m.put("GPS preparando ubicación en tiempo real...","GPS kunan maypi kasqaykita maskachkan...");
        m.put("📤 Compartir ubicación","📤 Maypi kasqayta apachiy");
        m.put("🧭 Abrir ruta en Google Maps","🧭 Google Maps ñanta kichay");
        m.put("🗺️\nMapa offline disponible\nActiva internet para ver Google Maps en tiempo real","🗺️\nMapa mana internetwan kachkan\nGoogle Maps kunan pacha rikunaykipaq internettam hap'ichiy");
        m.put("Centros de salud","Hampina wasikuna"); m.put("Cercanos a tu ubicación","Maypi kasqaykiman qaylla");
        m.put("🔎 Buscar posta, centro u hospital","🔎 Posta, hampina wasi utaq hospital maskay");
        // Contactos
        m.put("Contactos SOS","SOS rimanakuykuna");
        m.put("Agrega contactos de confianza. Cada tarjeta permite llamar, editar o eliminar.","Iñiy rimanakuykunata yapay. Sapa tarjetapi waqyay, allichay utaq qulluy atinki.");
        m.put("📲  Importar desde agenda","📲  Agendamanta apamuy");
        m.put("🔒 Consejo: registra mínimo 2 contactos para mayor seguridad.","🔒 Yuyachiy: iskay rimanakuyta churay aswan seguridadpaq.");
        m.put("Contacto SOS","SOS rimanakuy"); m.put("Llamar","Waqyay"); m.put("Editar","Allichay"); m.put("Eliminar","Qulluy");
        // Guías
        m.put("Primeros auxilios","Ñawpaq yanapay");
        m.put("Guía rápida de emergencia","Utqay yanapay yachachiy");
        m.put("Selecciona una situación. Cada panel muestra pasos claros, qué hacer, qué evitar y cuándo pedir ayuda profesional.","Imapas kaqtin akllay. Sapa panelmi rikuchin imayna rurana, imata mana rurana, hinallataq hayk'aq hampiqta mañana.");
        m.put("Compartir guía","Yachachiyta apachiy");
        m.put("Detalle","Sut'ichasqa");

        m.put("🩺  Primeros auxilios\nEvaluación inicial, seguridad y llamada de emergencia","🩺  Ñawpaq yanapay\nÑawpaq qhawariy, seguridad hinallataq utqay waqyay");
        m.put("❤️  RCP / Reanimación\nCompresiones, respiración y ayuda inmediata","❤️  RCP / Kawsachiy\nÑit'iy, samay hinallataq utqay yanapay");
        m.put("🩸  Hemorragias\nControlar sangrado sin poner en riesgo al paciente","🩸  Yawar puriy\nYawarta hark'ay mana unquqta waqllispalla");
        m.put("🦴  Fracturas\nInmovilizar, proteger y trasladar con cuidado","🦴  Tullu p'akiy\nMana kuyuchiy, waqaychay, allinta apay");
        m.put("🔥  Quemaduras\nEnfriar, cubrir y evitar remedios caseros","🔥  Ruphachisqa\nChiriyachiy, qatay, wasipi hampikunata ama churaychu");
        m.put("☠️  Intoxicación\nSustancias peligrosas, gases o alimentos","☠️  Miyuchasqa\nMana allin sustancia, gas utaq mikhuy");
        m.put("😮‍💨  Atragantamiento\nTos efectiva y maniobra de Heimlich","😮‍💨  Simipi hark'asqa\nAllin ch'uyay hinallataq Heimlich");
        m.put("⚡  Convulsiones\nProteger, controlar tiempo y no sujetar","⚡  Convulsiones\nWaqaychay, pachata yupay, ama hap'iychu");
        m.put("🐍  Picaduras y mordeduras\nAbejas, serpientes, insectos y alergias","🐍  K'anisqa hinallataq t'ipsisqa\nAñaskuna, mach'aqway, kurukuna, alergia");
        m.put("🚗  Accidente de tránsito\nZona segura, sangrados y traslado responsable","🚗  Ñan accidente\nAllin k'iti, yawar puriy, responsable apay");
        // Emergencia
        m.put("Emergencia","Utqay yanapay"); m.put("¿Necesitas ayuda?","¿Yanapayta munankichu?");
        m.put("DESLIZA HACIA ARRIBA PARA ACTIVAR","HANAQMAN LLUCHKACHIY HAP'ICHINAPAQ");
        m.put("ⓘ  Se enviará tu ubicación y notificación a tus contactos de emergencia.","ⓘ  Maypi kasqayki hinallataq willakuy SOS rimanakuykunaman apachisqa kanqa.");
        m.put("Enviando alerta...","Willakuyta apachichkan...");
        m.put("Tu información se está compartiendo","Willakuyniyki apachisqa kachkan");
        m.put("✅  Obteniendo ubicación\n✅  Enviando alerta a contactos\n✅  Notificando servicios de emergencia","✅  Maypi kasqayta hap'ichkan\n✅  Rimanakuykunaman willakuyta apachichkan\n✅  Utqay yanapaykunaman willachkan");
        m.put("Cancelar","Saqiy");
        m.put("¡Alerta enviada!","¡Willakuy apachisqa!"); m.put("Tus contactos han sido notificados.","Rimanakuykuna willasqa kachkan.");
        m.put("Tu ubicación fue compartida correctamente.","Maypi kasqayki allinta apachisqa."); m.put("Volver al inicio","Qallariyman kutiy");
        // Perfil y configuración
        m.put("🔐 Seguridad con huella habilitada","🔐 Ruk'ana seguridad hap'ichisqa");
        m.put("🌐  Idioma: Español                               ›","🌐  Simi: Español                               ›");
        m.put("🌐  Idioma: Quechua Cajamarca                 ›","🌐  Simi: Qichwa Cajamarca                 ›");
        m.put("Seleccionar idioma","Simita akllay"); m.put("Idioma de la aplicación","Aplicación simin");
        m.put("Español","Español"); m.put("Quechua Cajamarca","Qichwa Cajamarca");
        m.put("Editar información personal","Kikin willakuyta allichay");
        m.put("Completa los campos obligatorios para que tu alerta SOS tenga información útil.","SOS willakuyniyki allin kananpaq hunt'ana willakuykunata junt'ay.");
        m.put("Nombres y apellidos *","Sutikuna apillidu *"); m.put("DNI *","DNI *");
        m.put("Fecha de nacimiento *","Paqarisqa p'unchay *"); m.put("Celular *","Celular *");
        m.put("Dirección / comunidad *","Wasiyki / ayllu *"); m.put("Grupo sanguíneo *","Yawar rikch'ay *");
        m.put("Alergias / enfermedades *","Alergias / unquykuna *"); m.put("Contacto principal SOS *","Hatun SOS rimanakuy *");
        m.put("Guardar","Waqaychay"); m.put("Obligatorio","Hunt'anapaq");
        m.put("DNI de 8 dígitos","DNI 8 yupayniyuq"); m.put("Celular inválido","Celular mana allinchu");
        m.put("Correo incorrecto","Correo mana allinchu"); m.put("Contacto inválido","Rimanakuy mana allinchu");
        m.put("Perfil actualizado correctamente","Rikch'ay allinta musuqchasqa");
        m.put("Configuración","Wakichiy"); m.put("Personaliza RuralSOS para uso rural, emergencia y accesibilidad.","RuralSOS-ta llaqta, utqay yanapay hinallataq llapa runapaq wakichiy.");
        m.put("🌐 Idioma","🌐 Simi"); m.put("🔐 Seguridad","🔐 Seguridad"); m.put("♿ Accesibilidad","♿ Llapa runapaq");
        m.put("📴 Modo sin internet","📴 Mana internetwan"); m.put("🔔 Notificaciones","🔔 Willakuykuna");
        m.put("Entendido","Hamutarqani");
        // Otros módulos
        m.put("☎️ Números de emergencia","☎️ Utqay yanapay yupaykuna");
        m.put("Llama rápido incluso con internet lento o sin datos.","Utqay waqyay, internet pisilla kaptinpas mana datos kaptinpas.");
        m.put("👨‍👩‍👧 Familia segura","👨‍👩‍👧 Ayllu waqaychasqa");
        m.put("🌧️ Alertas climáticas","🌧️ Pacha willakuykuna");
        String out=m.get(raw);
        if(out!=null)return out;
        // prefijos dinámicos y reemplazos parciales
        if(raw.startsWith("Hola,")) return raw.replace("Hola,","Imaynalla,").replace("¿Qué necesitas ahora?","Imata munanki kunan?");
        if(raw.startsWith("🌐  Idioma:")) return raw.replace("Idioma:","Simi:").replace("Quechua Cajamarca","Qichwa Cajamarca");
        out=raw;
        String[][] rep={
            {"Contactos","Rimanakuykuna"},{"Centros de salud","Hampina wasikuna"},{"Mi ubicación","Maypi kasqay"},{"Orientación","Yanapakuq yachachiy"},{"Primeros auxilios","Ñawpaq yanapay"},
            {"Llamar:","Waqyay:"},{"Ruta","Ñan"},{"Compartir","Apachiy"},{"Buscar","Maskay"},{"Abierto","Kichasqa"},{"Emergencia","Utqay yanapay"},
            {"Configuración","Wakichiy"},{"Idioma","Simi"},{"Seguridad","Seguridad"},{"Notificaciones","Willakuykuna"},{"Cancelar","Saqiy"},{"Guardar","Waqaychay"},{"Mantén presionado","Ñit'ispa hap'iy"},{"3 segundos","kimsa segundu"},
            {"Cerrar sesión","Lloqsiy"},{"Información personal","Kikin willakuy"},{"Perfil","Rikch'ay"},{"Historial","Yuyay qillqa"},{"Inicio","Qallariy"},
            {"Correo incorrecto","Correo mana allinchu"},{"Contraseña","Pakasqa rimay"},{"Correo electrónico","Correo electrónico"},
            {"QUÉ HACER","IMA RURANA"},{"QUÉ NO HACER","IMA MANA RURANA"},{"PASOS","RURANAKUNA"},
            {"Verifica","Qhawariy"},{"Llama a emergencias","Utqay yanapayman waqyay"},{"Llama","Waqyay"},{"Mantén","Hap'iy"},
            {"persona","runa"},{"personas","runakuna"},{"responde","kutichin"},{"respira","saman"},{"respiración","samay"},
            {"ayuda","yanapay"},{"emergencia","utqay yanapay"},{"emergencias","utqay yanapaykuna"},{"seguro","mana manchay"},
            {"Presiona","Ñit'iy"},{"herida","k'irisqa"},{"sangrado","yawar puriy"},{"fractura","tullu p'akiy"},
            {"zona","k'iti"},{"agua","yaku"},{"médica","hampi"},{"médico","hampiq"},{"centro de salud","hampina wasi"},
            {"No ","Ama "},{"no ","ama "},{"con ","wan "},{"sin ","mana "},{"si ","sichus "}
        };
        out=replacePairsSafely(out,rep);
        return out;
    }


    String translateSpanish(String s){
        if(s==null)return "";
        String raw=s;
        Map<String,String> m=new HashMap<>();
        // Reverso Inglés -> Español. Es indispensable al cambiar de English a Español/Quechua
        // sin reiniciar la aplicación.
        String[][] englishBack={
            {"Home","Inicio"},{"History","Historial"},{"Profile","Perfil"},{"My profile","Mi perfil"},{"Log out","Cerrar sesión"},
            {"Personal information","Información personal"},{"Settings","Configuración"},{"Language","Idioma"},{"Notifications","Notificaciones"},{"Security","Seguridad"},
            {"Welcome","Bienvenido"},{"Password","Contraseña"},{"Secure login","Ingresar seguro"},{"Create new account","Crear cuenta nueva"},
            {"Create RuralSOS account","Crear cuenta RuralSOS"},{"Required information to activate your emergency profile","Datos obligatorios para activar tu perfil de emergencia"},
            {"First names *","Nombres *"},{"Father's surname *","Apellido paterno *"},{"Mother's surname *","Apellido materno *"},
            {"Date of birth *  Tap to select","Fecha de nacimiento *  Toca para seleccionar"},{"Contact and security","Contacto y seguridad"},{"Email *","Correo electrónico *"},
            {"Mobile number *","Número de celular *"},{"Address / community *","Dirección / comunidad *"},{"Basic medical information","Datos médicos básicos"},
            {"My location","Mi ubicación"},{"Health centers","Centros de salud"},{"Nearby health centers","Centros de salud cercanos"},{"First aid","Primeros auxilios"},{"SOS contacts","Contactos SOS"},
            {"Quick emergency guide","Guía rápida de emergencia"},{"Tap an icon to get help.","Toca un dibujo para recibir ayuda."},{"Share guide","Compartir guía"},{"Listen to guide","Escuchar guía"},
            {"Offline help","Ayuda sin internet"},{"Works without Internet via SMS","Funciona sin Internet mediante SMS"},{"System traffic light","Semáforo del sistema"},{"Internet: No connection","Internet: Sin conexión"},{"Internet: Limited","Internet: Limitado"},{"Internet: Connected","Internet: Conectado"},{"Mobile network: Permission pending","Red móvil: Permiso pendiente"},{"Mobile network: No signal","Red móvil: Sin señal"},{"Mobile network: Signal available","Red móvil: Con señal"},{"Satellite: Detection not supported","Satélite: Detección no compatible"},{"Satellite: Unavailable","Satélite: No disponible"},{"Satellite: Permission pending","Satélite: Permiso pendiente"},{"Satellite: Not connected","Satélite: No conectado"},{"Satellite: Connected","Satélite: Conectado"},{"Satellite: Checking","Satélite: Verificando"},{"Mobile network: Full data","Red móvil: Datos full"},{"Mobile network: Limited data","Red móvil: Datos limitados"},{"Mobile network: No network","Red móvil: Sin red"},{"GPS: Active","GPS: Activo"},{"GPS: Permission pending","GPS: Permiso pendiente"},{"GPS: Disabled","GPS: Desactivado"},{"SOS offline mode: Ready","Modo offline SOS: Listo"},{"SOS offline mode: SOS contacts missing","Modo offline SOS: Faltan contactos SOS"},{"SOS offline mode: SMS permission missing","Modo offline SOS: Permiso SMS faltante"},{"Green = stable, orange = limited, red = disabled or no service.","Verde = estable, naranja = limitado, rojo = desactivado o sin servicio."},{"Do you need help?","¿Necesitas ayuda?"},{"◉ Test","◉ Probar"},{"Call","Llamar"},{"Edit","Editar"},{"Delete","Eliminar"},{"Add","Agregar"},
            {"BLEEDING","SANGRADO"},{"BURN","QUEMADURA"},{"FRACTURE","FRACTURA"},{"CHOKING","ATRAGANTAMIENTO"},{"SEIZURE","CONVULSIÓN"},{"POISONING","INTOXICACIÓN"},{"BITE / STING","PICADURA"},{"ACCIDENT","ACCIDENTE"},
            {"Alert sent","Alerta enviada"},{"Alert sent!","¡Alerta enviada!"},{"Your contacts have been notified.","Tus contactos han sido notificados."},
            {"Emergency history","Historial de emergencias"},{"Your current location","Tu ubicación actual"},{"Share location","Compartir ubicación"}
        };
        for(String[] p:englishBack) if(raw.equals(p[0])) return p[1];
        if(raw.startsWith("Hello,")) return raw.replaceFirst("Hello,", "Hola,");
        // Reverso Quechua -> Español para que al volver a Español no queden textos en Quechua
        m.put("Qallariy","Inicio");
        m.put("Yuyay qillqa","Historial");
        m.put("Rikch'ay","Perfil");
        m.put("Ñuqaq rikch'ay","Mi perfil");
        m.put("Lloqsiy","Cerrar sesión");
        m.put("Kikin willakuy","Información personal");
        m.put("Yupay wakichiy","Configuración de cuenta");
        m.put("SOS willakuykuna","Notificaciones SOS");
        m.put("RuralSOSmanta","Acerca de RuralSOS");
        m.put("Imaynalla, admin • Imata munanki kunan?","Hola, admin • ¿Qué necesitas ahora?");
        m.put("Utqay yanapay, maypi kasqayki, hampiy hinallataq ayllu waqaychay.","Emergencias, ubicación, salud y familia segura.");
        m.put("🚨  SOS ÑIT'INA\nUtqay yanapaypaq ñit'iy","🚨  BOTÓN SOS\nPresiona en caso de emergencia");
        m.put("📍\nMaypi kasqay\nGPS kunan pacha","📍\nMi ubicación\nGPS tiempo real");
        m.put("👥\nRimanakuykuna\nAyllu SOS","👥\nContactos\nSOS familiar");
        m.put("🏥\nHampina wasikuna\nÑan aswan qaylla","🏥\nCentros de salud\nRuta cercana");
        m.put("📘\nYanapakuq yachachiy\nÑawpaq yanapay","📘\nOrientación\nPrimeros auxilios");
        m.put("🩺\nHampi qillqa","🩺\nCarnet médico");
        m.put("☎️\nSOS yupaykuna","☎️\nNúmeros SOS");
        m.put("👨‍👩‍👧\nAyllu waqaychasqa","👨‍👩‍👧\nFamilia segura");
        m.put("🌧️\nPacha willakuy","🌧️\nAlertas clima");
        m.put("Yuyayniyuq llaqta seguridad","Seguridad rural inteligente");
        m.put("Allin hamusqa","Bienvenido");
        m.put("Correo, pakasqa rimay utaq ruk'ana yupaywan yaykuy","Ingresa con tu correo, clave o huella digital");
        m.put("Pakasqa rimay","Contraseña");
        m.put("¿Pakasqa rimayta qunqarqankichu?","¿Olvidaste tu contraseña?");
        m.put("Mana manchaywan yaykuy","Ingresar seguro");
        m.put("utqay yaykuy","acceso rápido");
        m.put("🔐  Ruk'anawan yaykuy","🔐  Entrar con huella");
        m.put("G  Googlewan qatipay","G  Continuar con Google");
        m.put("Musuq yupayta ruway","Crear cuenta nueva");
        m.put("RuralSOS yupayta ruway","Crear cuenta RuralSOS");
        m.put("Utqay yanapaypaq kikin willakuykuna hunt'ay","Datos obligatorios para activar tu perfil de emergencia");
        m.put("Rimanakuy hinallataq seguridad","Contacto y seguridad");
        m.put("Sasa mana hampi willakuy","Datos médicos básicos");
        m.put("Hatun SOS rimanakuypa sutinta qillqay","Ingresa el nombre del contacto SOS principal");
        m.put("Hatun SOS rimanakuypa yupaynin *","Número del contacto principal *");
        m.put("Hatun SOS rimanakuypa sutin *","Nombre del contacto principal *");
        m.put("Hatun SOS rimanakuy","Contacto principal SOS");
        m.put("¿Órganokunata donayta munankichu? *","¿Desea donar órganos? *");
        m.put("* Hunt'ana willakuykuna. Willakuyniyki kay celularpi waqaychasqa kanqa mana internet kaptinpas.","* Campos obligatorios. Tus datos se guardan localmente para funcionar sin internet.");
        m.put("Mana manchaywan yupayta ruway","Crear cuenta segura");
        m.put("¿Yupayniyki kanchu? Yaykuy","¿Ya tienes cuenta? Inicia sesión");
        m.put("Maypi kasqay","Mi ubicación");
        m.put("Kunan maypi kasqayki","Tu ubicación actual");
        m.put("GPS kunan maypi kasqaykita maskachkan...","GPS preparando ubicación en tiempo real...");
        m.put("📤 Maypi kasqayta apachiy","📤 Compartir ubicación");
        m.put("🧭 Google Maps ñanta kichay","🧭 Abrir ruta en Google Maps");
        m.put("🗺️\nMapa mana internetwan kachkan\nGoogle Maps kunan pacha rikunaykipaq internettam hap'ichiy","🗺️\nMapa offline disponible\nActiva internet para ver Google Maps en tiempo real");
        m.put("Hampina wasikuna","Centros de salud");
        m.put("Maypi kasqaykiman qaylla","Cercanos a tu ubicación");
        m.put("🔎 Posta, hampina wasi utaq hospital maskay","🔎 Buscar posta, centro u hospital");
        m.put("SOS rimanakuykuna","Contactos SOS");
        m.put("Iñiy rimanakuykunata yapay. Sapa tarjetapi waqyay, allichay utaq qulluy atinki.","Agrega contactos de confianza. Cada tarjeta permite llamar, editar o eliminar.");
        m.put("📲  Agendamanta apamuy","📲  Importar desde agenda");
        m.put("🔒 Yuyachiy: iskay rimanakuyta churay aswan seguridadpaq.","🔒 Consejo: registra mínimo 2 contactos para mayor seguridad.");
        m.put("SOS rimanakuy","Contacto SOS");
        m.put("Waqyay","Llamar");
        m.put("Allichay","Editar");
        m.put("Qulluy","Eliminar");
        m.put("Ñawpaq yanapay","Primeros auxilios");
        m.put("Utqay yanapay yachachiy","Guía rápida de emergencia");
        m.put("Imapas kaqtin akllay. Sapa panelmi rikuchin imayna rurana, imata mana rurana, hinallataq hayk'aq hampiqta mañana.","Selecciona una situación. Cada panel muestra pasos claros, qué hacer, qué evitar y cuándo pedir ayuda profesional.");
        m.put("Yachachiyta apachiy","Compartir guía");
        m.put("Sut'ichasqa","Detalle");
        m.put("🩺  Ñawpaq yanapay\nÑawpaq qhawariy, seguridad hinallataq utqay waqyay","🩺  Primeros auxilios\nEvaluación inicial, seguridad y llamada de emergencia");
        m.put("❤️  RCP / Kawsachiy\nÑit'iy, samay hinallataq utqay yanapay","❤️  RCP / Reanimación\nCompresiones, respiración y ayuda inmediata");
        m.put("🩸  Yawar puriy\nYawarta hark'ay mana unquqta waqllispalla","🩸  Hemorragias\nControlar sangrado sin poner en riesgo al paciente");
        m.put("🦴  Tullu p'akiy\nMana kuyuchiy, waqaychay, allinta apay","🦴  Fracturas\nInmovilizar, proteger y trasladar con cuidado");
        m.put("🔥  Ruphachisqa\nChiriyachiy, qatay, wasipi hampikunata ama churaychu","🔥  Quemaduras\nEnfriar, cubrir y evitar remedios caseros");
        m.put("☠️  Miyuchasqa\nMana allin sustancia, gas utaq mikhuy","☠️  Intoxicación\nSustancias peligrosas, gases o alimentos");
        m.put("😮‍💨  Simipi hark'asqa\nAllin ch'uyay hinallataq Heimlich","😮‍💨  Atragantamiento\nTos efectiva y maniobra de Heimlich");
        m.put("⚡  Convulsiones\nWaqaychay, pachata yupay, ama hap'iychu","⚡  Convulsiones\nProteger, controlar tiempo y no sujetar");
        m.put("🐍  K'anisqa hinallataq t'ipsisqa\nAñaskuna, mach'aqway, kurukuna, alergia","🐍  Picaduras y mordeduras\nAbejas, serpientes, insectos y alergias");
        m.put("🚗  Ñan accidente\nAllin k'iti, yawar puriy, responsable apay","🚗  Accidente de tránsito\nZona segura, sangrados y traslado responsable");
        m.put("Utqay yanapay","Emergencia");
        m.put("¿Yanapayta munankichu?","¿Necesitas ayuda?");
        m.put("¿Yanapayta munanki?","¿Necesitas ayuda?");
        m.put("Sistema semáforo","Semáforo del sistema");
        m.put("Internet: mana tinkisqachu","Internet: Sin conexión");
        m.put("Internet: pisillam","Internet: Limitado");
        m.put("Internet: tinkisqa","Internet: Conectado");
        m.put("Celular red: permiso suyaykan","Red móvil: Permiso pendiente");
        m.put("Celular red: mana señal kanchu","Red móvil: Sin señal");
        m.put("Celular red: señal kan","Red móvil: Con señal");
        m.put("Satélite: kay celular mana qhawanchu","Satélite: Detección no compatible");
        m.put("Satélite: mana kanchu","Satélite: No disponible");
        m.put("Satélite: permiso suyaykan","Satélite: Permiso pendiente");
        m.put("Satélite: mana tinkisqachu","Satélite: No conectado");
        m.put("Satélite: tinkisqa","Satélite: Conectado");
        m.put("Satélite: qhawachkan","Satélite: Verificando");
        m.put("Celular red: allin datos","Red móvil: Datos full");
        m.put("Celular red: pisillam datos","Red móvil: Datos limitados");
        m.put("Celular red: mana red kanchu","Red móvil: Sin red");
        m.put("GPS: llamkan","GPS: Activo");
        m.put("GPS: permiso suyaykan","GPS: Permiso pendiente");
        m.put("GPS: wañuchishka","GPS: Desactivado");
        m.put("SOS offline modo: listo","Modo offline SOS: Listo");
        m.put("SOS offline modo: contactos faltan","Modo offline SOS: Faltan contactos SOS");
        m.put("SOS offline modo: SMS permiso faltan","Modo offline SOS: Permiso SMS faltante");
        m.put("Q'omer = allin, q'illu-anaranjado = pisi, puka = mana serviciu kanchu.","Verde = estable, naranja = limitado, rojo = desactivado o sin servicio.");
        m.put("HANAQMAN LLUCHKACHIY HAP'ICHINAPAQ","DESLIZA HACIA ARRIBA PARA ACTIVAR");
        m.put("ⓘ  Maypi kasqayki hinallataq willakuy SOS rimanakuykunaman apachisqa kanqa.","ⓘ  Se enviará tu ubicación y notificación a tus contactos de emergencia.");
        m.put("Willakuyta apachichkan...","Enviando alerta...");
        m.put("Willakuyniyki apachisqa kachkan","Tu información se está compartiendo");
        m.put("✅  Maypi kasqayta hap'ichkan\n✅  Rimanakuykunaman willakuyta apachichkan\n✅  Utqay yanapaykunaman willachkan","✅  Obteniendo ubicación\n✅  Enviando alerta a contactos\n✅  Notificando servicios de emergencia");
        m.put("Saqiy","Cancelar");
        m.put("¡Willakuy apachisqa!","¡Alerta enviada!");
        m.put("Rimanakuykuna willasqa kachkan.","Tus contactos han sido notificados.");
        m.put("Maypi kasqayki allinta apachisqa.","Tu ubicación fue compartida correctamente.");
        m.put("Qallariyman kutiy","Volver al inicio");
        m.put("🔐 Ruk'ana seguridad hap'ichisqa","🔐 Seguridad con huella habilitada");
        m.put("🌐  Simi: Español                               ›","🌐  Idioma: Español                               ›");
        m.put("🌐  Simi: Qichwa Cajamarca                 ›","🌐  Idioma: Quechua Cajamarca                 ›");
        m.put("Simita akllay","Seleccionar idioma");
        m.put("Aplicación simin","Idioma de la aplicación");
        m.put("Qichwa Cajamarca","Quechua Cajamarca");
        m.put("Kikin willakuyta allichay","Editar información personal");
        m.put("SOS willakuyniyki allin kananpaq hunt'ana willakuykunata junt'ay.","Completa los campos obligatorios para que tu alerta SOS tenga información útil.");
        m.put("Sutikuna apillidu *","Nombres y apellidos *");
        m.put("Paqarisqa p'unchay *","Fecha de nacimiento *");
        m.put("Wasiyki / ayllu *","Dirección / comunidad *");
        m.put("Yawar rikch'ay *","Grupo sanguíneo *");
        m.put("Alergias / unquykuna *","Alergias / enfermedades *");
        m.put("Hatun SOS rimanakuy *","Contacto principal SOS *");
        m.put("Waqaychay","Guardar");
        m.put("Hunt'anapaq","Obligatorio");
        m.put("DNI 8 yupayniyuq","DNI de 8 dígitos");
        m.put("Celular mana allinchu","Celular inválido");
        m.put("Correo mana allinchu","Correo incorrecto");
        m.put("Rimanakuy mana allinchu","Contacto inválido");
        m.put("Rikch'ay allinta musuqchasqa","Perfil actualizado correctamente");
        m.put("Wakichiy","Configuración");
        m.put("RuralSOS-ta llaqta, utqay yanapay hinallataq llapa runapaq wakichiy.","Personaliza RuralSOS para uso rural, emergencia y accesibilidad.");
        m.put("🌐 Simi","🌐 Idioma");
        m.put("♿ Llapa runapaq","♿ Accesibilidad");
        m.put("📴 Mana internetwan","📴 Modo sin internet");
        m.put("🔔 Willakuykuna","🔔 Notificaciones");
        m.put("Hamutarqani","Entendido");
        m.put("☎️ Utqay yanapay yupaykuna","☎️ Números de emergencia");
        m.put("Utqay waqyay, internet pisilla kaptinpas mana datos kaptinpas.","Llama rápido incluso con internet lento o sin datos.");
        // Reversos exactos de los textos del inicio. Evitan mezclas como
        // "Internet sin kaptinpis ayuda" al volver desde Quechua.
        m.put("Internet mana kaptinpis yanapay","Ayuda sin internet");
        m.put("Celular señal kan","Señal móvil disponible");
        m.put("GPS llamkan","GPS activo");
        m.put("Internet mana kaptinpis llamkan","Funciona sin internet");
        m.put("Internet mana kaptinpis SMSwan llamkan","Funciona sin Internet mediante SMS");
        m.put("Internet mana kaptinpis SOS willakuyta SMSwan kaĉachiyta puydinki.","Puedes enviar alertas SOS por SMS, aunque no haya Internet.");
        m.put("●  ▥  Celular señal kan\n●  ◎  GPS llamkan\n●  ◉  Internet mana kaptinpis llamkan","●  ▥  Señal móvil disponible\n●  ◎  GPS activo\n●  ◉  Funciona sin internet");
        m.put("👨‍👩‍👧 Ayllu waqaychasqa","👨‍👩‍👧 Familia segura");
        m.put("🌧️ Pacha willakuykuna","🌧️ Alertas climáticas");
        String out=m.get(raw);
        if(out!=null)return out;
        // Reverso para textos dinámicos o traducciones parciales
        if(raw.startsWith("Imaynalla,")) return raw.replace("Imaynalla,","Hola,").replace("Imata munanki kunan?","¿Qué necesitas ahora?");
        if(raw.startsWith("🌐  Simi:")) return raw.replace("Simi:","Idioma:").replace("Qichwa Cajamarca","Quechua Cajamarca");
        out=raw;
        String[][] rep={
            {"Rimanakuykuna","Contactos"},{"Hampina wasikuna","Centros de salud"},{"Maypi kasqay","Mi ubicación"},{"Yanapakuq yachachiy","Orientación"},{"Ñawpaq yanapay","Primeros auxilios"},
            {"Waqyay:","Llamar:"},{"Ñan","Ruta"},{"Apachiy","Compartir"},{"Maskay","Buscar"},{"Kichasqa","Abierto"},{"Utqay yanapay","Emergencia"},
            {"Wakichiy","Configuración"},{"Simi","Idioma"},{"Willakuykuna","Notificaciones"},{"Saqiy","Cancelar"},{"Waqaychay","Guardar"},{"Ñit'ispa hap'iy","Mantén presionado"},{"kimsa segundu","3 segundos"},
            {"Lloqsiy","Cerrar sesión"},{"Kikin willakuy","Información personal"},{"Rikch'ay","Perfil"},{"Yuyay qillqa","Historial"},{"Qallariy","Inicio"},
            {"Correo mana allinchu","Correo incorrecto"},{"Pakasqa rimay","Contraseña"},{"IMA RURANA","QUÉ HACER"},{"IMA MANA RURANA","QUÉ NO HACER"},{"RURANAKUNA","PASOS"},
            {"Qhawariy","Verifica"},{"Utqay yanapayman waqyay","Llama a emergencias"},{"Waqyay","Llama"},{"Hap'iy","Mantén"},
            {"runa","persona"},{"runakuna","personas"},{"kutichin","responde"},{"saman","respira"},{"samay","respiración"},
            {"yanapay","ayuda"},{"utqay yanapaykuna","emergencias"},{"mana manchay","seguro"},
            {"Ñit'iy","Presiona"},{"k'irisqa","herida"},{"yawar puriy","sangrado"},{"tullu p'akiy","fractura"},
            {"k'iti","zona"},{"yaku","agua"},{"hampi","médica"},{"hampiq","médico"},{"hampina wasi","centro de salud"},
            {"Ama ","No "},{"ama ","no "},{"wan ","con "},{"mana ","sin "},{"sichus ","si "}
        };
        out=replacePairsSafely(out,rep);
        return out;
    }

    /**
     * Reemplaza primero las frases más largas y protege conectores cortos de
     * coincidencias dentro de otras palabras. Ej.: "ama " ya no convierte
     * "Llama a emergencias" en "Llno a emergencias".
     */
    String replacePairsSafely(String input,String[][] pairs){
        if(input==null)return "";
        String out=input;
        String[][] ordered=pairs.clone();
        java.util.Arrays.sort(ordered,(a,b)->Integer.compare(b[0].length(),a[0].length()));
        for(String[] r:ordered){
            String from=r[0], to=r[1];
            if(from.equals("Ama ") || from.equals("ama ") || from.equals("wan ") || from.equals("mana ") || from.equals("sichus ") || from.equals("No ") || from.equals("no ")){
                String word=from.trim();
                out=out.replaceAll("(?<![\\p{L}\\p{N}_])"+java.util.regex.Pattern.quote(word)+"\\s", java.util.regex.Matcher.quoteReplacement(to));
            }else{
                out=out.replace(from,to);
            }
        }
        return out;
    }

    String translateEnglish(String s){
        if(s==null)return "";
        Map<String,String> e=new HashMap<>();
        String[][] pairs={
            {"Inicio","Home"},{"Historial","History"},{"Perfil","Profile"},{"Mi perfil","My profile"},{"Cerrar sesión","Log out"},
            {"Información personal","Personal information"},{"Configuración de cuenta","Account settings"},{"Notificaciones SOS","SOS notifications"},{"Acerca de RuralSOS","About RuralSOS"},
            {"Bienvenido","Welcome"},{"Contraseña","Password"},{"Contraseña *","Password *"},{"Confirmar contraseña *","Confirm password *"},{"Ingresar seguro","Secure login"},
            {"Crear cuenta nueva","Create new account"},{"Crear cuenta RuralSOS","Create RuralSOS account"},{"Crear cuenta segura","Create secure account"},
            {"Datos obligatorios para activar tu perfil de emergencia","Required information to activate your emergency profile"},{"DNI *","DNI *"},{"Consultar DNI","Look up DNI"},
            {"Con Internet puedes completar nombres automáticamente. Sin Internet, escríbelos manualmente.","With Internet, names can be filled in automatically. Without Internet, enter them manually."},
            {"Nombres *","First names *"},{"Apellido paterno *","Father's surname *"},{"Apellido materno *","Mother's surname *"},
            {"Fecha de nacimiento *  Toca para seleccionar","Date of birth *  Tap to select"},{"Contacto y seguridad","Contact and security"},{"Correo electrónico *","Email *"},
            {"Número de celular *","Mobile number *"},{"Dirección / comunidad *","Address / community *"},{"Datos médicos básicos","Basic medical information"},
            {"Grupo sanguíneo *  Ej: O+","Blood type *  Example: O+"},{"¿Tiene alergia clínica? *","Do you have a clinical allergy? *"},{"Sí","Yes"},{"No","No"},
            {"¿A qué es alérgico?","What are you allergic to?"},{"Medicamentos (opcional)","Medications (optional)"},{"Enfermedades / antecedentes (opcional)","Conditions / medical history (optional)"},
            {"Contacto principal SOS *","Primary SOS contact *"},{"🔐 Consentimiento y permisos","🔐 Consent and permissions"},{"Ver más","See more"},
            {"Mi ubicación","My location"},{"Centros de salud","Health centers"},{"Centros de salud cercanos","Nearby health centers"},{"Primeros auxilios","First aid"},{"Contactos SOS","SOS contacts"},
            {"Guardar","Save"},{"Cancelar","Cancel"},{"Configuración","Settings"},{"Idioma","Language"},{"Notificaciones","Notifications"},{"Seguridad","Security"},{"Permisos","Permissions"},
            {"Ayuda sin internet","Offline help"},{"Presiona una vez para solicitar ayuda","Press once to request help"},{"Toca un dibujo para recibir ayuda.","Tap an icon to get help."},
            {"Guía rápida de emergencia","Quick emergency guide"},{"Compartir guía","Share guide"},{"Escuchar guía","Listen to guide"},{"Emergencia, ubicación y ayuda rápida","Emergency, location and quick help"},
            {"Historial de emergencias","Emergency history"},{"Buscar centro de salud...","Search health center..."},{"Tu ubicación actual","Your current location"},{"Compartir ubicación","Share location"},
            {"Llamar","Call"},{"Editar","Edit"},{"Detalle","Details"},{"Comenzar","Start"},{"Más tarde","Later"},{"Volver al inicio","Back to home"},
            {"DNI encontrado. Nombres y apellidos completados automáticamente.","DNI found. First names and surnames filled in automatically."},
            {"Consultando DNI...","Looking up DNI..."},{"DNI de 8 dígitos","8-digit DNI"},{"Sin Internet. Ingresa nombres y apellidos manualmente.","No Internet. Enter first names and surnames manually."},
            {"No se pudo consultar el DNI. Puedes continuar manualmente.","DNI lookup failed. You can continue manually."},{"Puedes continuar manualmente.","You can continue manually."},
            {"Ingresa tus nombres","Enter your first names"},{"Ingresa apellido paterno","Enter your father's surname"},{"Ingresa apellido materno","Enter your mother's surname"},
            {"Obligatorio","Required"},{"Correo incorrecto","Invalid email"},{"Contacto inválido","Invalid contact"},{"DNI incorrecto","Invalid DNI"},{"Celular inválido","Invalid mobile number"},
            {"Ingresa tu correo","Enter your email"},{"Ingresa tu contraseña","Enter your password"},{"Clave incorrecta","Incorrect password"},{"No coincide","Does not match"},{"Correo ya registrado","Email already registered"},
            {"Autenticación con huella","Fingerprint authentication"},{"Confirma tu identidad para ingresar","Confirm your identity to log in"},{"Acceso cancelado","Login canceled"},{"Huella no disponible:","Fingerprint unavailable:"},{"Huella no configurada. Ingresa con clave.","Fingerprint is not configured. Log in with your password."},{"Huella disponible desde Android 9. Usa correo y clave.","Fingerprint login is available from Android 9. Use email and password."},
            {"Editar contacto","Edit contact"},{"Eliminar contacto","Delete contact"},{"Enviar alerta de prueba","Send test alert"},{"Prueba RuralSOS: este contacto recibirá alertas SOS con ubicación.","RuralSOS test: this contact will receive SOS alerts with location."},
            {"Donar órganos","Organ donation"},{"Donante de órganos","Organ donor"},{"Datos médicos","Medical information"},{"Historia clínica de emergencia","Emergency medical record"},
            {"Alertas y recordatorios","Alerts and reminders"},{"Bloqueo y privacidad","Lock and privacy"},{"Preferencias de la aplicación","App preferences"},{"Personaliza RuralSOS v1","Customize RuralSOS v1"},
            {"Estado de permisos del sistema","System permission status"},{"Familia y contactos de emergencia","Family and emergency contacts"},{"Datos de emergencia","Emergency information"},
            {"Datos básicos y dirección","Basic information and address"},{"Historia y condiciones de salud","Medical history and conditions"},{"Editar / completar historia clínica","Edit / complete medical record"},
            {"Guardado en el teléfono, sin Internet","Saved on the phone, offline"},{"Lista guardada en el teléfono","List saved on the phone"},{"Funciona sin Internet mediante SMS","Works without Internet via SMS"},
            {"GPS preparando ubicación en tiempo real...","GPS is preparing real-time location..."},{"Mapa en tiempo real","Real-time map"},{"Abrir ruta en Google Maps","Open route in Google Maps"},
            {"Alerta SOS","SOS alert"},{"Alerta enviada","Alert sent"},{"¡Alerta enviada!","Alert sent!"},{"Tus contactos han sido notificados.","Your contacts have been notified."},{"Tu ubicación fue compartida correctamente.","Your location was shared successfully."},
            {"SANGRADO","BLEEDING"},{"QUEMADURA","BURN"},{"FRACTURA","FRACTURE"},{"ATRAGANTAMIENTO","CHOKING"},{"CONVULSIÓN","SEIZURE"},{"INTOXICACIÓN","POISONING"},{"PICADURA","BITE / STING"},{"ACCIDENTE","ACCIDENT"},
            {"RCP / Reanimación","CPR / Resuscitation"},{"Hemorragias","Bleeding"},{"Fracturas","Fractures"},{"Quemaduras","Burns"},{"Intoxicación","Poisoning"},{"Atragantamiento","Choking"},{"Convulsiones","Seizures"},{"Picaduras y mordeduras","Bites and stings"},{"Accidente de tránsito","Traffic accident"},
            {"QUÉ HACER","WHAT TO DO"},{"QUÉ NO HACER","WHAT NOT TO DO"},{"NO HACER","DO NOT"},{"PASOS","STEPS"},
            {"Verifica que el lugar sea seguro.","Make sure the area is safe."},{"Revisa si responde y respira.","Check whether the person responds and is breathing."},{"Llama a emergencias.","Call emergency services."},{"Mantén a la persona tranquila y abrigada.","Keep the person calm and warm."},
            {"No muevas a una persona con golpe fuerte.","Do not move a person with a serious injury."},{"No des agua si está inconsciente.","Do not give water to an unconscious person."},
            {"Verifica si responde.","Check for a response."},{"Coloca las manos en el centro del pecho.","Place your hands in the center of the chest."},{"Realiza 30 compresiones fuertes y rápidas.","Give 30 firm, fast chest compressions."},{"Da 2 respiraciones si estás capacitado.","Give 2 rescue breaths if you are trained."},{"No interrumpas las compresiones por mucho tiempo.","Do not interrupt compressions for long."},
            {"Presiona la herida con tela limpia.","Press the wound with a clean cloth."},{"Mantén presión constante.","Keep steady pressure."},{"Eleva la zona si no hay fractura.","Raise the area if there is no fracture."},{"Busca ayuda urgente si el sangrado no para.","Seek urgent help if the bleeding does not stop."},{"No retires objetos incrustados.","Do not remove embedded objects."},{"No uses tierra, café ni remedios caseros.","Do not use soil, coffee, or home remedies."},
            {"Inmoviliza la zona.","Immobilize the area."},{"Aplica frío envuelto en tela.","Apply a cold pack wrapped in cloth."},{"Evita movimientos bruscos.","Avoid sudden movements."},{"Acude al centro de salud.","Go to a health center."},{"No intentes acomodar el hueso.","Do not try to realign the bone."},{"No masajees la zona lesionada.","Do not massage the injured area."},
            {"Enfría con agua corriente 10 a 20 minutos.","Cool under running water for 10 to 20 minutes."},{"Retira anillos o ropa ajustada alrededor.","Remove rings or tight clothing around the area."},{"Cubre con gasa limpia.","Cover with clean gauze."},{"No uses pasta dental, aceite o mantequilla.","Do not use toothpaste, oil, or butter."},{"No revientes ampollas.","Do not burst blisters."},
            {"Aleja a la persona de la sustancia.","Move the person away from the substance."},{"Ventila el ambiente.","Ventilate the area."},{"Guarda el envase para mostrar al médico.","Keep the container to show medical staff."},{"No provoques vómito sin indicación médica.","Do not induce vomiting unless instructed by medical staff."},
            {"Si tose, deja que siga tosiendo.","If the person is coughing, let them keep coughing."},{"Si no respira, realiza maniobra de Heimlich.","If the person cannot breathe, perform the Heimlich maneuver."},{"No metas los dedos a ciegas en la boca.","Do not blindly put your fingers in the mouth."},
            {"Retira objetos cercanos.","Remove nearby objects."},{"Coloca algo suave bajo la cabeza.","Place something soft under the head."},{"Ponlo de lado cuando termine.","Turn the person onto their side when it stops."},{"Controla el tiempo.","Time the seizure."},{"No sujetes a la persona.","Do not restrain the person."},{"No pongas objetos en su boca.","Do not put objects in the person's mouth."},
            {"Lava la zona con agua y jabón si es posible.","Wash the area with soap and water if possible."},{"Mantén a la persona en reposo.","Keep the person resting."},{"Acude al centro de salud si hay dolor, hinchazón, fiebre o dificultad para respirar.","Go to a health center if there is pain, swelling, fever, or difficulty breathing."},{"No cortes la herida.","Do not cut the wound."},{"No succiones veneno.","Do not suck out venom."},{"No apliques torniquetes fuertes.","Do not apply tight tourniquets."},{"No ignores señales de alergia.","Do not ignore signs of an allergic reaction."},
            {"Asegura la zona.","Make the area safe."},{"No retires casco si sospechas lesión cervical.","Do not remove a helmet if a neck injury is suspected."},{"Controla sangrados visibles.","Control visible bleeding."},{"No muevas heridos graves salvo peligro inmediato.","Do not move seriously injured people unless there is immediate danger."},
            {"No hay datos médicos registrados.","No medical information is registered."},{"Sangre:","Blood type:"},{"Alergia:","Allergy:"},{"Medicamentos:","Medications:"},{"Antecedentes:","Medical history:"},{"Contacto SOS:","SOS contact:"},{"Donante de órganos:","Organ donor:"},
            {"Ninguno","None"},{"Ninguna","None"},{"No especificado","Not specified"},{"SÍ","YES"},{"SI -","YES -"},
            {"Ubicación registrada","Location recorded"},{"Ubicación pendiente","Location pending"},{"Abrir ubicación en Google Maps","Open location in Google Maps"},{"Sin alertas recientes","No recent alerts"},{"RuralSOS listo para emergencia","RuralSOS ready for emergencies"},{"ENVIADA","SENT"},{"FALLIDA","FAILED"},{"PROCESANDO","PROCESSING"},
            {"Tu ubicación actual del celular","Your phone's current location"},{"Preparando GPS...","Preparing GPS..."},{"Última ubicación del celular","Last phone location"},{"Ubicación guardada del celular","Saved phone location"},{"GPS activo: leyendo tu ubicación en tiempo real desde el celular.","GPS active: reading your real-time phone location."},{"Permiso GPS pendiente.","GPS permission pending."},{"GPS no disponible. Activa ubicación del celular.","GPS unavailable. Turn on phone location."},{"Permiso de ubicación no concedido. Se usa ubicación guardada/offline.","Location permission not granted. Using saved/offline location."},{"Activa el GPS para mayor precisión.","Turn on GPS for better accuracy."},
            {"Internet activo: mapa en vivo.","Internet active: live map."},{"Sin internet: modo offline con GPS/local.","No Internet: offline mode with GPS/local data."},{"Latitud:","Latitude:"},{"Longitud:","Longitude:"},{"precisión aprox.","approx. accuracy"},{"GPS tiempo real activo","Real-time GPS active"},{"Proveedor activo:","Active provider:"},
            {"Google Maps no está instalado. Puedes compartir tu ubicación.","Google Maps is not installed. You can share your location."},{"Mi ubicación RuralSOS GPS","My RuralSOS GPS location"},{"Necesito ayuda. Mi ubicación GPS en tiempo real:","I need help. My real-time GPS location:"},
            {"Información guardada en tu teléfono. Se incluirá en la alerta SOS para ayudar al personal de salud.","Information is saved on your phone. It will be included in the SOS alert to help health personnel."},
            {"Mostrar QR médico offline","Show offline medical QR"},{"Estos datos se envían por SMS junto con el nombre, GPS y URL de Google Maps.","This information is sent by SMS together with the name, GPS and Google Maps URL."},
            {"Contacto SOS","SOS contact"},{"Nombre del contacto","Contact name"},{"Teléfono","Phone"},{"Volver","Back"},{"Mínimo 6 caracteres","At least 6 characters"},{"QR MÉDICO OFFLINE","OFFLINE MEDICAL QR"},
            {"Tiene alergia clínica","Has a clinical allergy"},{"Medicamentos","Medications"},{"Enfermedades / antecedentes","Conditions / medical history"},{"Soy donante de órganos","I am an organ donor"},{"Datos médicos guardados offline","Medical information saved offline"},{"Indica la alergia","Enter the allergy"},
            {"Historial de emergencias","Emergency history"},{"Guardado en el teléfono, sin Internet","Saved on the phone, offline"},{"Buscar en el historial...","Search history..."},{"Ya estás en historial","You are already in history"},{"Ya estás en inicio","You are already on Home"},{"Ya estás en perfil","You are already on Profile"},
            {"Activar SOS","Activate SOS"},{"Mi ubicación GPS","My GPS location"},{"Idioma / Quechua","Language / Quechua"},{"GPS listo","GPS ready"},{"Modo offline activo","Offline mode active"},{"Quechua disponible","Quechua available"},{"No tienes alertas nuevas.","You have no new alerts."},
            {"Modo sin internet","Offline mode"},{"La app mantiene contactos, historial y guías de primeros auxilios guardadas localmente. Para mapas reales y centros actualizados se necesita conexión.","The app keeps contacts, history, and first-aid guides stored locally. A connection is required for live maps and updated health centers."},
            {"Alertas SOS activas con sonido y vibración.","SOS alerts are active with sound and vibration."},{"Modo fácil","Easy mode"},{"Linterna SOS","SOS flashlight"},{"activado","enabled"},{"desactivado","disabled"},
            {"Centros guardados • ordenados por cercanía","Saved health centers • sorted by distance"},{"No se encontró en la lista local. Pulsa 'Buscar en Google Maps' para ver resultados reales cercanos.","Not found in the local list. Tap 'Search in Google Maps' to see nearby live results."},{"Tu ubicación GPS","Your GPS location"},{"El mapa visual se mostrará cuando exista Internet.","The visual map will appear when Internet is available."},{"Atención primaria rural","Rural primary care"},{"Atención primaria","Primary care"},{"Atención diaria","Daily care"},{"24 horas","24 hours"},{"A %.1f km aprox.","Approx. %.1f km away"},{"Buscar más centros de salud de Cajamarca en Google Maps","Search for more Cajamarca health centers in Google Maps"},
            {"ALERTA CRÍTICA RURALSOS","CRITICAL RURALSOS ALERT"},{"Firma HMAC válida","Valid HMAC signature"},{"Origen","Source"},{"IR A RURALSOS","OPEN RURALSOS"},{"MARCAR COMO VISTA","MARK AS SEEN"},
            {"Agrega contactos de confianza. Cada tarjeta permite llamar, editar o eliminar.","Add trusted contacts. Each card lets you call, edit, or delete."},{"Consejo: registra mínimo 2 contactos para mayor seguridad.","Tip: register at least 2 contacts for greater safety."},
            {"Se enviará nombre, ubicación, URL del mapa e historia clínica por SMS.","Your name, location, map URL, and medical record will be sent by SMS."},{"La historia clínica crítica se incluye automáticamente en la alerta.","Critical medical information is automatically included in the alert."},
            {"Versión, términos y más","Version, terms, and more"},{"Mapa offline disponible","Offline map available"},{"Activa internet para ver Google Maps en tiempo real","Turn on Internet to view Google Maps in real time"},
            {"Opciones preparadas para uso rural, emergencia y accesibilidad.","Options prepared for rural use, emergencies, and accessibility."},{"Contactos, historial y guías locales","Local contacts, history, and guides"},{"Iconos y botones grandes","Large icons and buttons"},{"Señal visual al activar emergencia","Visual signal when an emergency is activated"},
            {"Modo Alerta Crítica","Critical Alert Mode"},{"Recibir SOS firmado: sonido + vibración + flash","Receive signed SOS: sound + vibration + flash"},{"Código HMAC","HMAC code"},{"Vincular emisor y receptor sin internet","Pair sender and receiver without Internet"},{"Sonido, vibración y alerta SOS","Sound, vibration, and SOS alert"},
            {"* Campos obligatorios. Tus datos se guardan localmente para funcionar sin internet.","* Required fields. Your data is stored locally so the app can work without Internet."},{"RuralSOS solicitará ubicación, contactos, SMS, cámara y notificaciones para las funciones de emergencia. Android te permitirá aceptar o rechazar cada permiso.","RuralSOS will request location, contacts, SMS, camera, and notification permissions for emergency features. Android will let you allow or deny each permission."},{"Doy mi consentimiento para que RuralSOS solicite los permisos necesarios para las funciones SOS. *","I consent to RuralSOS requesting the permissions needed for SOS features. *"},{"¿Ya tienes cuenta? Inicia sesión","Already have an account? Log in"},
            {"Limpiar historial","Clear history"},{"Ingresa con tu correo y contraseña local","Log in with your local email and password"},{"¿Olvidaste tu contraseña?","Forgot your password?"},{"Entrar con huella digital","Log in with fingerprint"},
            {"Información disponible sin Internet.","Information available without Internet."},{"Tu ubicación","Your location"},{"Ubicación GPS disponible","GPS location available"},{"Mapa visual requiere Internet","The visual map requires Internet"},
            {"Configura RuralSOS para emergencias","Set up RuralSOS for emergencies"},{"Configura las funciones necesarias para que una alerta SOS pueda usar ubicación, contactos y notificaciones cuando corresponda.","Set up the features needed so an SOS alert can use location, contacts, and notifications when required."},{"Configurar ahora","Set up now"},{"Datos médicos / Historia clínica","Medical information / Medical record"},{"Ingresa el nombre del contacto SOS principal","Enter the primary SOS contact name"},{"Número del contacto principal *","Primary contact number *"},{"Nombre del contacto principal *","Primary contact name *"},{"Contacto principal SOS","Primary SOS contact"},{"¿Desea donar órganos? *","Do you want to donate organs? *"},
            {"Completa los campos obligatorios para que tu alerta SOS tenga información útil.","Complete the required fields so your SOS alert contains useful information."},{"¿Deseas eliminar a ","Do you want to delete "},{"No disponible","Not available"},{" de 2"," of 2"},
            {"AYUDA","HELP"},{"UBICACIÓN","LOCATION"},{"CONTACTOS","CONTACTS"},{"SALUD","HEALTH"},{"AUXILIOS","FIRST AID"},
            {"El QR contiene los datos críticos directamente. No abre una página web.","The QR contains critical information directly. It does not open a web page."},{"No se pudo generar QR: ","Could not generate QR: "},
            {"Activa GPS para ver cercanos reales.","Turn on GPS to see actual nearby places."},{"Activa ubicación/GPS para ordenar por cercanía.","Turn on location/GPS to sort by distance."},{"Actualizando ubicación GPS...","Updating GPS location..."},{"GPS fuera de Cajamarca. Usando Cajamarca como referencia.","GPS is outside Cajamarca. Using Cajamarca as the reference."},{"Permite GPS para ordenar centros cercanos en tiempo real.","Allow GPS to sort nearby health centers in real time."},
            {"Código HMAC guardado localmente","HMAC code saved locally"},{"Huella activada para tu cuenta registrada","Fingerprint enabled for your registered account"},{"Huella desactivada","Fingerprint disabled"},{"Idioma: ","Language: "},{"Permisos de alerta crítica listos","Critical alert permissions are ready"},{"Permisos listos","Permissions are ready"},{"Primero debes registrarte para activar la huella","You must register first to enable fingerprint login"},
            {"Completa nombre y teléfono","Enter the name and phone number"},{"Contacto eliminado","Contact deleted"},{"Contacto guardado en SQLite","Contact saved in SQLite"},{"Contacto importado y guardado en SQLite","Contact imported and saved in SQLite"},{"El contacto no tiene teléfono válido","The contact does not have a valid phone number"},{"No se pudo abrir la agenda del teléfono","Could not open the phone contacts"},{"No se pudo importar el contacto","Could not import the contact"},{"Permiso denegado. Puedes agregar el contacto manualmente.","Permission denied. You can add the contact manually."},
            {"Ya estás en SOS","You are already on SOS"},{"Activa el permiso SMS para enviar alertas a tus contactos","Enable SMS permission to send alerts to your contacts"},{"Alerta SOS cancelada","SOS alert canceled"},{"No hay contactos SOS registrados","No SOS contacts are registered"},
            {"Bienvenido a RuralSOS v1","Welcome to RuralSOS v1"},{"Contraseña obligatoria","Password is required"},{"Correo o clave incorrecta","Incorrect email or password"},{"Correo obligatorio","Email is required"},{"Huella verificada","Fingerprint verified"},{"Primero debes registrarte e iniciar sesión con tu correo y contraseña","You must register and log in with your email and password first"},{"Primero debes registrarte para usar huella","You must register first to use fingerprint login"},{"Recuperación lista para integrar. Usa tu cuenta local registrada.","Recovery is ready to integrate. Use your registered local account."},{"Usuario local no encontrado. Inicia con correo y clave.","Local user not found. Log in with email and password."},
            {"Idioma actualizado: ","Language updated: "},{"Perfil actualizado en SQLite","Profile updated in SQLite"},{"Cuenta creada. Ahora autoriza los permisos necesarios","Account created. Now allow the required permissions"},{"Debes dar tu consentimiento para crear la cuenta","You must give consent to create the account"},{"Escribe a qué es alérgico","Enter what you are allergic to"},{"Ese correo ya existe en SQLite local","That email already exists in local SQLite"},{"Ingresa apellido materno","Enter your mother's surname"},{"Ingresa apellido paterno","Enter your father's surname"},{"Ingresa contacto SOS principal","Enter the primary SOS contact"},{"Ingresa dirección o comunidad","Enter your address or community"},{"Ingresa fecha de nacimiento","Enter your date of birth"},{"Ingresa grupo sanguíneo","Enter your blood type"},{"Ingresa tus nombres","Enter your first names"},{"Ingresa un celular válido","Enter a valid mobile number"},{"La contraseña debe tener mínimo 6 caracteres","The password must have at least 6 characters"},{"La fecha no puede ser futura","The date cannot be in the future"},{"Las contraseñas no coinciden","Passwords do not match"},{"Registro completado. Ahora inicia sesión","Registration complete. Now log in"},
            {"Tus datos se guardan localmente en el teléfono. RuralSOS no necesita una cuenta en la nube para las funciones de emergencia.","Your data is stored locally on the phone. RuralSOS does not require a cloud account for emergency features."},{"RuralSOS utiliza ubicación para GPS, SMS para alertas y contactos solo cuando decides importarlos.","RuralSOS uses location for GPS, SMS for alerts, and contacts only when you choose to import them."},
            {"¿Necesitas ayuda?","Do you need help?"},{"◉ Probar","◉ Test"},{"Alertas SOS activas","SOS alerts active"},{"Vibración y sonido","Vibration and sound"},{"Envío de ubicación","Location sharing"},{"Contactos guardados para modo offline","Contacts saved for offline mode"},{"RuralSOS v1 está orientado a comunidades rurales: SOS, GPS, centros de salud, contactos, quechua cajamarquino y modo offline.","RuralSOS v1 is designed for rural communities: SOS, GPS, health centers, contacts, Cajamarca Quechua, and offline mode."},
            {"Acceso local","Local access"},{"Primero crea una cuenta local en SQLite. Luego podrás ingresar con correo y contraseña o con huella asociada a esa cuenta registrada.","First create a local account in SQLite. Then you can log in with email and password or with the fingerprint linked to that registered account."},{"La huella no permite entrar si no existe un usuario registrado.","Fingerprint login cannot be used if there is no registered user."},
            {"Si este teléfono recibe un SMS RuralSOS con HMAC válido y comparte el mismo código de vinculación, activa sonido, vibración, flash y una notificación de alta prioridad. No necesita internet.","If this phone receives a RuralSOS SMS with a valid HMAC and the same pairing code, it activates sound, vibration, flashlight, and a high-priority notification. It does not require Internet."},
            {"Emergencia, ubicación y ayuda rápida para comunidades rurales.","Emergency, location, and quick help for rural communities."},{"PRIMEROS AUXILIOS","FIRST AID"},{"SMS disponible","SMS available"},{"km aprox.","km approx."},
            {"Semáforo del sistema","System traffic light"},{"Internet: Sin conexión","Internet: No connection"},{"Internet: Limitado","Internet: Limited"},{"Internet: Conectado","Internet: Connected"},{"Red móvil: Permiso pendiente","Mobile network: Permission pending"},{"Red móvil: Sin señal","Mobile network: No signal"},{"Red móvil: Con señal","Mobile network: Signal available"},{"Satélite: Detección no compatible","Satellite: Detection not supported"},{"Satélite: No disponible","Satellite: Unavailable"},{"Satélite: Permiso pendiente","Satellite: Permission pending"},{"Satélite: No conectado","Satellite: Not connected"},{"Satélite: Conectado","Satellite: Connected"},{"Satélite: Verificando","Satellite: Checking"},{"Red móvil: Datos full","Mobile network: Full data"},{"Red móvil: Datos limitados","Mobile network: Limited data"},{"Red móvil: Sin red","Mobile network: No network"},{"GPS: Activo","GPS: Active"},{"GPS: Permiso pendiente","GPS: Permission pending"},{"GPS: Desactivado","GPS: Disabled"},{"Modo offline SOS: Listo","SOS offline mode: Ready"},{"Modo offline SOS: Faltan contactos SOS","SOS offline mode: SOS contacts missing"},{"Modo offline SOS: Permiso SMS faltante","SOS offline mode: SMS permission missing"},{"Verde = estable, naranja = limitado, rojo = desactivado o sin servicio.","Green = stable, orange = limited, red = disabled or no service."},
            {"Señal móvil disponible","Mobile signal available"},{"GPS activo","GPS active"},{"Funciona sin internet","Works without Internet"},{"Puedes enviar alertas SOS por SMS, aunque no haya Internet.","You can send SOS alerts by SMS even without Internet."}
        };
        for(String[] p:pairs)e.put(p[0],p[1]);
        String out=e.get(s); if(out!=null)return out;
        if(s.startsWith("Hola,")) return s.replaceFirst("Hola,", "Hello,");
        // También traduce bloques de texto completos (por ejemplo las guías de
        // primeros auxilios), no solo cadenas que coinciden exactamente.
        out=s;
        String[][] orderedPairs=pairs.clone();
        java.util.Arrays.sort(orderedPairs,(a,b)->Integer.compare(b[0].length(),a[0].length()));
        for(String[] p:orderedPairs) if(out.contains(p[0])) out=out.replace(p[0],p[1]);
        String[][] rep={
            {"Primeros auxilios","First aid"},{"Centros de salud","Health centers"},{"Mi ubicación","My location"},{"Contactos","Contacts"},{"Historial","History"},{"Perfil","Profile"},
            {"Configuración","Settings"},{"Idioma","Language"},{"Seguridad","Security"},{"Notificaciones","Notifications"},{"Guardar","Save"},{"Cancelar","Cancel"},{"Llamar","Call"},
            {"Emergencia","Emergency"},{"ubicación","location"},{"Ubicación","Location"},{"Sin Internet","No Internet"},{"sin internet","without Internet"},{"Compartir","Share"},
            {"Buscar","Search"},{"Editar","Edit"},{"Eliminar","Delete"},{"Agregar","Add"},{"Nombre","Name"},{"Correo electrónico","Email"},{"Contraseña","Password"}
        };
        for(String[] r:rep)out=out.replace(r[0],r[1]); return out;
    }
}
