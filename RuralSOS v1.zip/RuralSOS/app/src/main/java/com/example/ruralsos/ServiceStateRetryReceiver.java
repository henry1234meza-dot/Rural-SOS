package com.example.ruralsos;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class ServiceStateRetryReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        if (SosRetryManager.hayPendientes(context) && SosUtils.hayServicioMovil(context)) {
            SosRetryManager.reintentarAhoraAsync(context);
        }
    }
}
