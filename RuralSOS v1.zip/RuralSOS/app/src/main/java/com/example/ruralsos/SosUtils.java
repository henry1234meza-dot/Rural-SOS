package com.example.ruralsos;

import android.content.Context;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraManager;
import android.os.*;
import android.telephony.SmsManager;
import android.telephony.TelephonyManager;
import android.telephony.ServiceState;
import android.Manifest;
import android.content.pm.PackageManager;
import java.util.*;

public class SosUtils {
    public static boolean hayServicioMovil(Context ctx) {
        try {
            if (Build.VERSION.SDK_INT >= 23 &&
                    ctx.checkSelfPermission(Manifest.permission.READ_PHONE_STATE) != PackageManager.PERMISSION_GRANTED) {
                return false;
            }
            TelephonyManager tm=(TelephonyManager)ctx.getSystemService(Context.TELEPHONY_SERVICE);
            ServiceState st=tm==null?null:tm.getServiceState();
            return st!=null && st.getState()==ServiceState.STATE_IN_SERVICE;
        } catch(Exception e) {
            return false;
        }
    }

    public static int enviarATodos(Context ctx, DatabaseHelper db, String mensaje, long historialId) {
        // Importante: SmsManager puede aceptar una solicitud aun estando en modo avión.
        // Primero confirmamos que realmente exista servicio celular.
        if(!hayServicioMovil(ctx)) return 0;

        int ok=0; SmsManager sm=SmsManager.getDefault();
        for(String[] c: db.listarContactos()) {
            String tel=c[2]==null?"":c[2].replace(" ","").replace("-",""); if(tel.isEmpty()) continue;
            try {
                ArrayList<String> partes=sm.divideMessage(mensaje);
                sm.sendMultipartTextMessage(tel,null,partes,null,null);
                ok++;
                db.guardarDetalleEnvio(historialId,c[1],tel,"SOLICITADO");
            } catch(Exception e) {
                db.guardarDetalleEnvio(historialId,c[1],tel,"FALLIDO");
            }
        }
        return ok;
    }
    public static void linternaSos(Context ctx) {
        if(!ctx.getSharedPreferences("data",0).getBoolean("flash_sos",true)) return;
        try { CameraManager cm=(CameraManager)ctx.getSystemService(Context.CAMERA_SERVICE); String id=null;
            for(String x:cm.getCameraIdList()){ Boolean f=cm.getCameraCharacteristics(x).get(CameraCharacteristics.FLASH_INFO_AVAILABLE); if(Boolean.TRUE.equals(f)){id=x;break;} }
            if(id==null)return; final String cid=id; Handler h=new Handler(Looper.getMainLooper()); long t=0;
            long[] pulses={180,180,180,500,500,500,180,180,180};
            for(int i=0;i<pulses.length;i++){ final boolean on=i%2==0; h.postDelayed(()->{try{cm.setTorchMode(cid,on);}catch(Exception ignored){}},t); t+=pulses[i]; }
            h.postDelayed(()->{try{cm.setTorchMode(cid,false);}catch(Exception ignored){}},t+100);
        } catch(Exception ignored){}
    }
}
