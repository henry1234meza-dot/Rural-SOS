package com.example.ruralsos;

import android.Manifest;
import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.os.*;
import android.view.*;
import android.widget.*;
import java.util.*;

public class ConsentimientoActivity extends ActividadBase {
    private LinearLayout content; private Button primary; private TextView secondary, progress;
    private int page=0; private SharedPreferences sp; private boolean previewOnly=false;

    @Override protected void onCreate(Bundle b){
        super.onCreate(b);
        sp=getSharedPreferences("data",0);
        previewOnly=getIntent().getBooleanExtra("preview_only", false);
        build(); showPage();
    }

    private TextView tv(String text,int size,boolean bold){
        TextView v=new TextView(this); v.setText(text); v.setTextSize(size);
        v.setTextColor(android.graphics.Color.rgb(25,38,35));
        if(bold)v.setTypeface(null,1); v.setPadding(0,dp(8),0,dp(8)); return v;
    }

    private void build(){
        LinearLayout root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(24),dp(24),dp(24),dp(20));
        root.setBackgroundColor(android.graphics.Color.rgb(248,253,250));
        progress=tv("1 de 2",13,true); progress.setGravity(Gravity.END); root.addView(progress);
        ScrollView sv=new ScrollView(this); content=new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL); content.setGravity(Gravity.CENTER_VERTICAL);
        sv.addView(content,new ScrollView.LayoutParams(-1,-2));
        root.addView(sv,new LinearLayout.LayoutParams(-1,0,1));
        primary=new Button(this); primary.setTextColor(android.graphics.Color.WHITE);
        primary.setTextSize(17); primary.setAllCaps(false); primary.setBackgroundResource(R.drawable.bg_green_button);
        root.addView(primary,new LinearLayout.LayoutParams(-1,dp(58)));
        secondary=tv("",14,false); secondary.setGravity(Gravity.CENTER); root.addView(secondary);
        setContentView(root);
        primary.setOnClickListener(v->{
            if(page==0){ page=1; showPage(); }
            else if(previewOnly){ finish(); }
            else { finishConsent(); }
        });
        secondary.setOnClickListener(v->{
            if(page==1) new AlertDialog.Builder(this)
                    .setTitle(tr("Política de privacidad"))
                    .setMessage(tr("Tus datos personales y médicos se guardan localmente en este dispositivo y se usan para funciones de emergencia. Puedes retirar permisos desde Configuración de Android."))
                    .setPositiveButton(tr("Entendido"),null).show();
        });
    }

    private void add(String text,int size,boolean bold){content.addView(tv(tr(text),size,bold));}

    private void showPage(){
        content.removeAllViews(); secondary.setText(""); progress.setText((page+1)+tr(" de 2"));
        if(page==0){
            add("Permisos que solicita RuralSOS",26,true);
            add("📍 Ubicación",19,true); add("Para enviar tu ubicación durante una emergencia.",15,false);
            add("💬 SMS",19,true); add("Para enviar alertas por mensaje cuando corresponda.",15,false);
            add("👥 Contactos",19,true); add("Para elegir tus contactos de emergencia.",15,false);
            add("📷 Cámara",19,true); add("Para agregar fotos cuando sea necesario. Opcional.",15,false);
            add("🔔 Notificaciones",19,true); add("Para avisarte cuando recibas una alerta.",15,false);
            add("📡 Estado de red / satélite",19,true); add("Para detectar disponibilidad de red móvil y conexión satelital compatible. No realiza llamadas.",15,false);
            primary.setText(tr("Entendido, continuar"));
        } else {
            add("Tu consentimiento",27,true);
            add("RuralSOS necesita estos permisos para ayudarte en una emergencia.",17,false);
            add("✓ Usaremos tu ubicación para enviar tu posición.",16,false);
            add("✓ Podremos usar SMS y contactos para enviar alertas.",16,false);
            add("✓ Puedes quitar los permisos cuando quieras.",16,false);
            primary.setText(tr(previewOnly ? "Cerrar" : "Entendido, continuar"));
            secondary.setText(tr("Ver política de privacidad"));
        }
        applyLanguage();
    }

    private void finishConsent(){
        String email=sp.getString("email","");
        sp.edit().putBoolean("consent_"+email.toLowerCase(),true)
                .putLong("consent_time_"+email.toLowerCase(),System.currentTimeMillis()).apply();
        requestNeeded();
    }

    @Override public void onBackPressed(){ if(page>0){page--;showPage();}else super.onBackPressed(); }
    private void requestNeeded(){
        ArrayList<String> p=new ArrayList<>();
        addIf(p,Manifest.permission.ACCESS_FINE_LOCATION);
        addIf(p,Manifest.permission.SEND_SMS);
        addIf(p,Manifest.permission.RECEIVE_SMS);
        addIf(p,Manifest.permission.READ_CONTACTS);
        addIf(p,Manifest.permission.CAMERA);
        if(Build.VERSION.SDK_INT>=33) addIf(p,Manifest.permission.POST_NOTIFICATIONS);
        addIf(p,Manifest.permission.READ_PHONE_STATE);
        if(p.isEmpty()) done(); else requestPermissions(p.toArray(new String[0]),77);
    }
    private void addIf(ArrayList<String> p,String x){if(checkSelfPermission(x)!=PackageManager.PERMISSION_GRANTED)p.add(x);}
    @Override public void onRequestPermissionsResult(int r,String[] p,int[] g){super.onRequestPermissionsResult(r,p,g);if(r==77)done();}
    private void done(){go(PrincipalActivity.class);finish();}
}
