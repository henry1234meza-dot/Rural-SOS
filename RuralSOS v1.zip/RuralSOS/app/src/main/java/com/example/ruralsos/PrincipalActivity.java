package com.example.ruralsos;

import android.Manifest;
import android.app.AlertDialog;
import android.content.Context;
import android.content.BroadcastReceiver;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.location.LocationManager;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.telephony.ServiceState;
import android.telephony.PhoneStateListener;
import android.telephony.TelephonyManager;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.util.ArrayList;

public class PrincipalActivity extends ActividadBase {

    private ConnectivityManager connectivityManager;
    private ConnectivityManager.NetworkCallback networkCallback;
    private BroadcastReceiver legacyConnectivityReceiver;
    private boolean connectivityListenerRegistered = false;
    private TelephonyManager telephonyManager;
    private PhoneStateListener phoneStateListener;
    private boolean phoneStateListenerRegistered = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.pantalla_principal);
        new Thread(() -> SosRetryManager.reintentar(this)).start();
        if (SosRetryManager.hayPendientes(this)) {
            SosRetryManager.programarReintento(this);
        }

        String user = getSharedPreferences("data", 0).getString("user", "admin");
        TextView txtWelcome = findViewById(R.id.txtWelcome);
        txtWelcome.setText(tr("Hola, ") + user);

        setupMainButtons();
        setupBottomNavigation();
        setupTopBar();
        setupEmergencyConfiguration();
        updateTrafficLightIndicators();
    }

    @Override
    protected void onResume() {
        super.onResume();
        updateTrafficLightIndicators();
    }

    @Override
    protected void onStart() {
        super.onStart();
        registerConnectivityListener();
        registerMobileSignalListener();
        updateTrafficLightIndicators();
    }

    @Override
    protected void onStop() {
        unregisterConnectivityListener();
        unregisterMobileSignalListener();
        super.onStop();
    }

    private void setupEmergencyConfiguration() {
        android.content.SharedPreferences sp = getSharedPreferences("data", 0);
        String email = sp.getString("email", "").toLowerCase();
        boolean accepted = sp.getBoolean("consent_" + email, false);
        View card = findViewById(R.id.cardEmergencySetup);
        card.setVisibility(accepted ? View.GONE : View.VISIBLE);
        findViewById(R.id.btnSetupNow).setOnClickListener(v -> go(ConsentimientoActivity.class));
        findViewById(R.id.btnSetupLater).setOnClickListener(v -> card.setVisibility(View.GONE));
    }

    private void setupMainButtons() {
        findViewById(R.id.btnSOS).setOnClickListener(v -> go(EnviandoAlertaActivity.class));
        findViewById(R.id.btnLocation).setOnClickListener(v -> go(UbicacionActivity.class));
        findViewById(R.id.btnContacts).setOnClickListener(v -> go(ContactosEmergenciaActivity.class));
        findViewById(R.id.btnHealth).setOnClickListener(v -> go(CentrosSaludActivity.class));
        findViewById(R.id.btnMedicalData).setOnClickListener(v -> go(DatosMedicosActivity.class));
        findViewById(R.id.btnGuide).setOnClickListener(v -> go(OrientacionActivity.class));
        if (getSharedPreferences("data",0).getBoolean("easy_mode",false)) {
            Button sos = findViewById(R.id.btnSOS); sos.setText(tr("🆘\nAYUDA")); sos.setTextSize(42);
            ((Button)findViewById(R.id.btnLocation)).setText(tr("📍\nUBICACIÓN"));
            ((Button)findViewById(R.id.btnContacts)).setText(tr("📞\nCONTACTOS"));
            ((Button)findViewById(R.id.btnHealth)).setText(tr("🏥\nSALUD"));
            ((Button)findViewById(R.id.btnGuide)).setText(tr("❤️\nAUXILIOS"));
        }
    }

    private void setupBottomNavigation() {
        findViewById(R.id.navHome).setOnClickListener(v -> toast("Ya estás en inicio"));
        findViewById(R.id.navEmergency).setOnClickListener(v -> go(EmergenciaActivity.class));
        findViewById(R.id.navHistory).setOnClickListener(v -> go(HistorialActivity.class));
        findViewById(R.id.btnProfile).setOnClickListener(v -> go(PerfilUsuarioActivity.class));
    }

    private void setupTopBar() {
        findViewById(R.id.btnMenu).setOnClickListener(v -> openSmartMenu());
        findViewById(R.id.btnNotify).setOnClickListener(v -> showNotifications());
    }

    private void updateTrafficLightIndicators() {
        setMobileNetworkTrafficLight();
        setInternetTrafficLight();
        setGpsTrafficLight();
        setOfflineTrafficLight();
        setSatelliteTrafficLight();
    }

    private void setMobileNetworkTrafficLight() {
        String status;
        int color;

        if (Build.VERSION.SDK_INT >= 23
                && checkSelfPermission(Manifest.permission.READ_PHONE_STATE) != PackageManager.PERMISSION_GRANTED) {
            status = tr("Red móvil: Permiso pendiente");
            color = Color.parseColor("#FB8C00");
        } else {
            try {
                TelephonyManager tm = (TelephonyManager) getSystemService(Context.TELEPHONY_SERVICE);
                ServiceState state = tm == null ? null : tm.getServiceState();

                if (state != null && state.getState() == ServiceState.STATE_IN_SERVICE) {
                    status = tr("Red móvil: Con señal");
                    color = Color.parseColor("#2E7D32");
                } else {
                    status = tr("Red móvil: Sin señal");
                    color = Color.parseColor("#E53935");
                }
            } catch (SecurityException e) {
                status = tr("Red móvil: Permiso pendiente");
                color = Color.parseColor("#FB8C00");
            } catch (Exception e) {
                status = tr("Red móvil: Sin señal");
                color = Color.parseColor("#E53935");
            }
        }

        ((TextView) findViewById(R.id.txtNetwork)).setText(status);
        colorDot(R.id.dotNetwork, color);
    }

    private void setInternetTrafficLight() {
        String status;
        int color;
        ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);

        try {
            Network network = cm == null ? null : cm.getActiveNetwork();
            NetworkCapabilities caps = (cm == null || network == null)
                    ? null : cm.getNetworkCapabilities(network);

            if (caps == null || !caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)) {
                status = tr("Internet: Sin conexión");
                color = Color.parseColor("#E53935");
            } else if (!caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)) {
                status = tr("Internet: Limitado");
                color = Color.parseColor("#FB8C00");
            } else {
                status = tr("Internet: Conectado");
                color = Color.parseColor("#2E7D32");
            }
        } catch (Exception e) {
            status = tr("Internet: Sin conexión");
            color = Color.parseColor("#E53935");
        }

        ((TextView) findViewById(R.id.txtInternet)).setText(status);
        colorDot(R.id.dotInternet, color);
    }

    private void registerMobileSignalListener() {
        if (phoneStateListenerRegistered) return;
        if (Build.VERSION.SDK_INT >= 23
                && checkSelfPermission(Manifest.permission.READ_PHONE_STATE) != PackageManager.PERMISSION_GRANTED) {
            return;
        }

        try {
            telephonyManager = (TelephonyManager) getSystemService(Context.TELEPHONY_SERVICE);
            if (telephonyManager == null) return;

            phoneStateListener = new PhoneStateListener() {
                @Override
                public void onServiceStateChanged(ServiceState serviceState) {
                    super.onServiceStateChanged(serviceState);
                    runOnUiThread(() -> updateTrafficLightIndicators());
                    if (serviceState != null && serviceState.getState() == ServiceState.STATE_IN_SERVICE) {
                        SosRetryManager.reintentarAhoraAsync(PrincipalActivity.this);
                    }
                }
            };
            telephonyManager.listen(phoneStateListener, PhoneStateListener.LISTEN_SERVICE_STATE);
            phoneStateListenerRegistered = true;
        } catch (Exception ignored) {
            phoneStateListenerRegistered = false;
        }
    }

    private void unregisterMobileSignalListener() {
        if (!phoneStateListenerRegistered) return;
        try {
            if (telephonyManager != null && phoneStateListener != null) {
                telephonyManager.listen(phoneStateListener, PhoneStateListener.LISTEN_NONE);
            }
        } catch (Exception ignored) {
        }
        phoneStateListenerRegistered = false;
        phoneStateListener = null;
    }

    private void registerConnectivityListener() {
        if (connectivityListenerRegistered) return;
        connectivityManager = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        if (connectivityManager == null) return;

        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                networkCallback = new ConnectivityManager.NetworkCallback() {
                    @Override
                    public void onAvailable(Network network) {
                        runOnUiThread(() -> updateTrafficLightIndicators());
                        SosRetryManager.reintentarAhoraAsync(PrincipalActivity.this);
                    }

                    @Override
                    public void onLost(Network network) {
                        runOnUiThread(() -> updateTrafficLightIndicators());
                    }

                    @Override
                    public void onCapabilitiesChanged(Network network, NetworkCapabilities networkCapabilities) {
                        runOnUiThread(() -> updateTrafficLightIndicators());
                        if (networkCapabilities != null &&
                                networkCapabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)) {
                            SosRetryManager.reintentarAhoraAsync(PrincipalActivity.this);
                        }
                    }
                };
                connectivityManager.registerDefaultNetworkCallback(networkCallback);
            } else {
                legacyConnectivityReceiver = new BroadcastReceiver() {
                    @Override
                    public void onReceive(Context context, Intent intent) {
                        updateTrafficLightIndicators();
                        SosRetryManager.reintentarAhoraAsync(PrincipalActivity.this);
                    }
                };
                registerReceiver(legacyConnectivityReceiver,
                        new IntentFilter(ConnectivityManager.CONNECTIVITY_ACTION));
            }
            connectivityListenerRegistered = true;
        } catch (Exception ignored) {
            connectivityListenerRegistered = false;
        }
    }

    private void unregisterConnectivityListener() {
        if (!connectivityListenerRegistered) return;
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N && networkCallback != null && connectivityManager != null) {
                connectivityManager.unregisterNetworkCallback(networkCallback);
                networkCallback = null;
            } else if (legacyConnectivityReceiver != null) {
                unregisterReceiver(legacyConnectivityReceiver);
                legacyConnectivityReceiver = null;
            }
        } catch (Exception ignored) {
        }
        connectivityListenerRegistered = false;
    }

    private void setSatelliteTrafficLight() {
        TextView label = findViewById(R.id.txtSatellite);
        if (label == null) return;

        String status;
        int color;

        if (Build.VERSION.SDK_INT < 35) {
            status = tr("Satélite: Detección no compatible");
            color = Color.parseColor("#E53935");
        } else if (checkSelfPermission(Manifest.permission.READ_PHONE_STATE) != PackageManager.PERMISSION_GRANTED) {
            status = tr("Satélite: Permiso pendiente");
            color = Color.parseColor("#FB8C00");
        } else {
            try {
                TelephonyManager tm = (TelephonyManager) getSystemService(Context.TELEPHONY_SERVICE);
                ServiceState state = tm == null ? null : tm.getServiceState();

                boolean usingSatellite = false;
                if (state != null) {
                    // Reflexión: evita errores de compilación si el SDK instalado en Android Studio
                    // todavía no expone directamente isUsingNonTerrestrialNetwork().
                    java.lang.reflect.Method method =
                            ServiceState.class.getMethod("isUsingNonTerrestrialNetwork");
                    Object result = method.invoke(state);
                    usingSatellite = result instanceof Boolean && (Boolean) result;
                }

                if (usingSatellite) {
                    status = tr("Satélite: Conectado");
                    color = Color.parseColor("#2E7D32");
                } else {
                    status = tr("Satélite: No conectado");
                    color = Color.parseColor("#E53935");
                }
            } catch (NoSuchMethodException e) {
                status = tr("Satélite: Detección no compatible");
                color = Color.parseColor("#E53935");
            } catch (Exception e) {
                status = tr("Satélite: No disponible");
                color = Color.parseColor("#E53935");
            }
        }

        label.setText(status);
        colorDot(R.id.dotSatellite, color);
    }

    private void setGpsTrafficLight() {
        String status;
        int color;
        boolean fine = Build.VERSION.SDK_INT < 23 || checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED;
        boolean coarse = Build.VERSION.SDK_INT < 23 || checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED;
        LocationManager lm = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        boolean gpsOn = false;
        boolean netOn = false;
        try {
            if (lm != null) {
                gpsOn = lm.isProviderEnabled(LocationManager.GPS_PROVIDER);
                netOn = lm.isProviderEnabled(LocationManager.NETWORK_PROVIDER);
            }
        } catch (Exception ignored) {}

        if ((gpsOn || netOn) && (fine || coarse)) {
            status = tr("GPS: Activo");
            color = Color.parseColor("#2E7D32");
        } else if (gpsOn || netOn) {
            status = tr("GPS: Permiso pendiente");
            color = Color.parseColor("#FB8C00");
        } else {
            status = tr("GPS: Desactivado");
            color = Color.parseColor("#E53935");
        }

        ((TextView)findViewById(R.id.txtGps)).setText(status);
        colorDot(R.id.dotGps, color);
    }

    private void setOfflineTrafficLight() {
        String status;
        int color;
        boolean smsGranted = Build.VERSION.SDK_INT < 23 || checkSelfPermission(Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED;
        int contactsCount = countSosContacts();
        if (smsGranted && contactsCount > 0) {
            status = tr("Modo offline SOS: Listo");
            color = Color.parseColor("#2E7D32");
        } else if (smsGranted) {
            status = tr("Modo offline SOS: Faltan contactos SOS");
            color = Color.parseColor("#FB8C00");
        } else {
            status = tr("Modo offline SOS: Permiso SMS faltante");
            color = Color.parseColor("#E53935");
        }
        ((TextView)findViewById(R.id.txtOffline)).setText(status);
        colorDot(R.id.dotOffline, color);
    }

    private int countSosContacts() {
        try {
            DatabaseHelper db = new DatabaseHelper(this);
            Cursor c = db.getReadableDatabase().rawQuery("SELECT COUNT(*) FROM contactos_sos", null);
            int total = 0;
            if (c.moveToFirst()) total = c.getInt(0);
            c.close();
            return total;
        } catch (Exception ignored) {
            return 0;
        }
    }

    private void colorDot(int viewId, int color) {
        View dot = findViewById(viewId);
        GradientDrawable d = new GradientDrawable();
        d.setShape(GradientDrawable.OVAL);
        d.setColor(color);
        d.setSize(dp(16), dp(16));
        dot.setBackground(d);
    }

    private void openSmartMenu() {
        String[] opciones = {
                tr("🚨 Activar SOS"),
                tr("📍 Mi ubicación GPS"),
                tr("🏥 Centros de salud cercanos"),
                tr("📘 Primeros auxilios"),
                tr("🌐 Idioma / Quechua"),
                tr("⚙️ Configuración"),
                tr("🚪 Cerrar sesión")
        };

        new AlertDialog.Builder(this)
                .setTitle(tr("RuralSOS v1"))
                .setItems(opciones, (dialog, which) -> {
                    switch (which) {
                        case 0: go(EnviandoAlertaActivity.class); break;
                        case 1: go(UbicacionActivity.class); break;
                        case 2: go(CentrosSaludActivity.class); break;
                        case 3: go(OrientacionActivity.class); break;
                        case 4:
                        case 5: go(ConfiguracionActivity.class); break;
                        case 6:
                            getSharedPreferences("data", 0).edit().putBoolean("logged_in", false).remove("user").apply();
                            go(InicioSesionActivity.class);
                            finish();
                            break;
                    }
                })
                .setNegativeButton(tr("Cerrar"), null)
                .show();
    }

    private void showNotifications() {
        new AlertDialog.Builder(this)
                .setTitle(tr("Notificaciones RuralSOS v1"))
                .setMessage(tr("✅ GPS listo\n\n✅ Modo offline activo\n\n✅ Quechua disponible\n\nNo tienes alertas nuevas."))
                .setPositiveButton(tr("Entendido"), null)
                .show();
    }

}
