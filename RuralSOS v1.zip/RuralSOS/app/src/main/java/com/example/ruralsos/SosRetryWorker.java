package com.example.ruralsos;

import android.content.Context;

import androidx.annotation.NonNull;
import androidx.work.Worker;
import androidx.work.WorkerParameters;

public class SosRetryWorker extends Worker {

    public SosRetryWorker(@NonNull Context appContext, @NonNull WorkerParameters params) {
        super(appContext, params);
    }

    @NonNull
    @Override
    public Result doWork() {
        Context ctx = getApplicationContext();
        SosRetryManager.reintentar(ctx);

        // Si el SMS todavía no pudo salir, WorkManager vuelve a intentar
        // automáticamente aplicando backoff para no consumir batería.
        if (SosRetryManager.hayPendientes(ctx)) {
            return Result.retry();
        }
        return Result.success();
    }
}
