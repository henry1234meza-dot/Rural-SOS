package com.example.ruralsos;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class SosBootReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        if (SosRetryManager.hayPendientes(context)) {
            SosRetryManager.programarReintento(context);
        }
    }
}
